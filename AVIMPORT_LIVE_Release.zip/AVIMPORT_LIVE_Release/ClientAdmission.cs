#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: ClientAdmission.cs
//   VERSION: 0.5.0-beta
//     BUILD: 200911
//   AUTHORS: development@aprettycoolprogram.com, 
//            updates for larry/mbhp alpha char in client id: priley@aspirehealthalliance.org
//            wsse wsdl impl: ckennedy@aspirehealthalliance.org
// COPYRIGHT: 2020 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region CLASS_DESCRIPTION
/*  Contains all of the logic for working with the WEBSVC.ClientAdmission Web Service.
 */
#endregion

#region USING
using Du;
using myAvimport.ClientAdmission_LIVE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;
using System.Drawing;//using System;
//using System.Collections.Generic;
//using System.Drawing;
#endregion

namespace myAvimport
{
    public class ClientAdmission
    {
        public string   ClientName                  { get; set; }
        public string   ClientLastName              { get; set; }
        public string   ClientFirstName             { get; set; }
        public string   ClientMiddleName            { get; set; }
        public string   Sex                         { get; set; }
        public string   SocialSecurityNumber        { get; set; }
        public string   EthnicOrigin                { get; set; }
        public string   MaritalStatus               { get; set; }
        public string   DateOfBirth                 { get; set; }
        public string   ClientAddressStreet         { get; set; }
        public string   ClientAddressStreet2        { get; set; }
        public string   ClientAddressCity           { get; set; }
        public string   ClientAddressState          { get; set; }
        public string   ClientAddressZipcode        { get; set; }
        public string   ClientHomePhone             { get; set; }
        public string   ClientWorkPhone             { get; set; }
        public string   ClientCellPhone             { get; set; }
        public string   Veteran                     { get; set; }
        public string   ClientRace                  { get; set; }
        public string   PrimaryLanguage             { get; set; }
        public string   Smoker                      { get; set; }
        public string   SmokingStatusAssessmentDate { get; set; }
        public string   EpisodeNumber               { get; set; }
        public string   Program                     { get; set; }
        public string   AdmissionDate               { get; set; }
        public string   AdmissionTime               { get; set; }
        public string   AttendingPractitioner       { get; set; }
        public string   TypeOfAdmission             { get; set; }
        public string   SSDemographicsFreeText201   { get; set; }
        public DateTime UTCTimestamp                { get; set; } 
        /// <summary>
        /// Creates a dictionary containing all ClientAdmissionObjects.
        /// </summary>
        /// <param name = "clients"> The converted data </param>
        /// <returns> A dictionary of ClientAdmissionObjects tied to ClientIDs. </returns>
        /// <remarks>
        /// Creates ClientAdmissionObjects from the data retrieved from an external file, then 
        /// puts those objects in a dictionary that ties the ClientID to the 
        /// ClientAdmissionObject.
        /// </remarks>
        public static Dictionary<string, 
            ClientAdmissionObject> CreateObjects(List<string>[] clients)
        {
            var clientAdmissionObjects = new Dictionary<string, ClientAdmissionObject>();
            //var clientCounter          = 0; // REMOVE THIS

            foreach (var client in clients)
            {
                var clientAdmissionObject = new ClientAdmissionObject
                {
                    ClientName                  = client[1] + "," + client[2],
                    ClientLastName              = client[1],
                    ClientFirstName             = client[2],
                    ClientMiddleName            = client[3],
                    Sex                         = client[4],
                    SocialSecurityNumber        = client[5],
                    EthnicOrigin                = client[6],
                    MaritalStatus               = client[7],
                    DateOfBirth                 = client[8],
                    ClientAddressStreet         = client[9],
                    ClientAddressStreet2        = client[10],
                    ClientAddressCity           = client[11],
                    ClientAddressState          = client[12],
                    ClientAddressZipcode        = client[13],
                    ClientHomePhone             = client[14],
                    ClientWorkPhone             = client[15],
                    ClientCellPhone             = client[16],
                    Veteran                     = client[17],
                    ClientRace                  = client[18],
                    PrimaryLanguage             = client[19],
                    Smoker                      = client[20],
                    SmokingStatusAssessmentDate = client[21],
                    EpisodeNumber               = client[22],
                    Program                     = client[23],
                    AdmissionDate               = client[24],
                    AttendingPractitioner       = client[25],
                    AdmissionTime               = "10:10:10",
                    TypeOfAdmission             = client[26],
                    SSDemographicsFreeText201   = client[27],
                    UTCTimestamp = System.DateTime.Now.ToUniversalTime()
                };

                /*  Dictionary format is { ClientID, ClientAdmissionObject }
                 */
                clientAdmissionObjects.Add(client[0], clientAdmissionObject);
            }

            return clientAdmissionObjects;
        }

        /// <summary>
        /// Check imported data for errors.
        /// </summary>
        /// <param name = "clientAdmissionObjects"> The data that will be imported </param>
        /// <returns> A list of errors. </returns>
        /// <remarks>
        /// Checks the loaded data for the following errors:
        ///     1. AdmissionDate predates the DOB
        /// </remarks>
        public static List<string> CheckForErrors(Dictionary<string, 
            ClientAdmissionObject> clientAdmissionObjects)
        {
            /* TODO This needs to be tested.
             */
            var errorList = new List<string>();
            //var clientNumber = 0; // DELETE

            foreach (var clientAdmissionObject in clientAdmissionObjects)
            {
                //DuMessageBox.Display(clientAdmissionObject.Value.AdmissionDate, "AdmissionDate");
                //DuMessageBox.Display(clientAdmissionObject.Value.DateOfBirth, "DateOfBirth");

                if (Convert.ToDateTime(clientAdmissionObject.Value.AdmissionDate) < 
                    Convert.ToDateTime(clientAdmissionObject.Value.DateOfBirth))
                {
                    errorList.Add("ClientID: " + clientAdmissionObject.Key + " - " 
                        + clientAdmissionObject.Value.ClientName + " - Admission date < DOB");
                }
            }

            if (errorList.Count == 0)
            {
                errorList.Add("No errors found!");
            }

            return errorList;
        }

        /// <summary>
        /// Imports client demographics data into myAvatar.
        /// </summary>
        /// <param name = "clientAdmissionObjects"> Dictionary contianing the 
        /// ClientAdmissionObjects </param>
        /// <param name = "systemCode">             Avatar system code [SBOX/UAT/LIVE] </param>
        /// <param name = "username">               Avatar username </param>
        /// <param name = "password">               Avatar password </param>
        /// <param name = "testMode">               Mode flag for myAvimport </param>
        /// <param name = "tbxUserSecurityToken">   WSSE security token ...- # where # is a number 1 to N.
        ///                                         and N is likely the maximum number of users.
        ///                                         I'm using 240 for now, because I think the instance
        ///                                         supports up to 250?</param>
        /// <param name = "throttleImport">         Throttle or not </param>
        /// <remarks>
        /// Manages the data import process.
        /// </remarks>
        public static void Import(Dictionary<string, 
            ClientAdmissionObject> clientAdmissionObjects, 
            string AvatarEnv, string AvatarUser, string AvatarPassword,
            string tbxUserSecurityToken, bool testMode, bool throttleImport)
        {
            string addAdmissionResponse = "";
            var statusBox = new frmDuStatusBox();
            statusBox.Show();
            UpdateStatusBox(statusBox, Color.Black, Color.LightBlue, 
                "Client Demographics data import in progress...", "Starting...", false, "Done");

            var importCounter = 0;
            var totalImports  = clientAdmissionObjects.Count;

            foreach (var clientAdmissionObject in clientAdmissionObjects)
            {
                /*if (String.IsNullOrEmpty(clientAdmissionObject.Value.ClientHomePhone))
                {
                    clientAdmissionObject.Value.ClientHomePhone = " ";
                }*/

                addAdmissionResponse = AddAdmission(AvatarEnv, AvatarUser, AvatarPassword, 
                    tbxUserSecurityToken, clientAdmissionObject.Value, clientAdmissionObject.Key, 
                    testMode);
                if (addAdmissionResponse.Contains("ERROR"))
                {
                    return;
                }
                ++importCounter;
                
                UpdateStatusBox(statusBox, Color.Black, Color.LightBlue,
                "Client Admission WS import in progress...", importCounter + " of " 
                + totalImports + ": " + addAdmissionResponse.Replace("Client", "[" + 
                clientAdmissionObject.Key
                + "]").Replace(" : ",":").Replace("Ep#  ", "Ep#").Replace("  "," ").ToLower()
               // + " throttle: " + throttleImport, true, "Don't touch!");
               + "throttle: " + throttleImport, true, "Don't touch!");

                /* UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, 
                     "Client Demographics data import in progress...", "Imported record " 
                     + (importCounter + 1) + " of " + totalImports, true, "Continue");
                 importCounter++;
                */

                /*  Throttling is enabled by default, and is recommended when importing a large 
                 *  number of records.
                 */
                if (throttleImport)
                {
                    DuSystem.Pause(5000);
                }
                else
                {
                    DuSystem.Pause(500);
                }
                if (importCounter == totalImports)
                {
                    UpdateStatusBox(statusBox, Color.Black, Color.LightGreen,
                     "Client Demographics data import complete!", "Click \"Continue\"", true,
                     "Continue");
                }

            }

            UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, 
                "Client Demographics data import complete!", "Click \"Continue\"", true, 
                "Continue");

            //return "[DEFAULT] Import complete."; // DELETE
        }

        /// <summary> Adds client(s) demographic data to Avatar. </summary>
        /// <param name = "AvatarEnv"> Avatar system code [SBOX/UAT/LIVE]</param>
        /// <param name = "AvatarUsername"> Avatar username              </param>
        /// <param name = "AvatarPassword"> Avatar password              </param>
        /// <param name = "clientAdmissionObject"> The object that contains the client data.
        /// </param>
        /// <param name = "clientID">       The Client ID                </param>
        /// <returns> The web service response. </returns>
        /// <remarks>
        /// Does the actual import into the specified Avatar environment.
        /// Here we also implement Alpha numeric THOM patient id's
        /// for MBHP.  These are handled by the ClientAdmission.addAdmission 
        /// method as SSDemographicsFreeText201. 
        /// </remarks>
        public static string AddAdmission(string SystemCode, string UserName,
            string Password, string tbxUserSecurityToken, ClientAdmissionObject clientAdmissionObject, 
            string clientID, bool testMode)
        {
            switch (SystemCode)
            {
                case "LIVE":
                    var SoapClient =
                        new ClientAdmission_LIVE.ClientAdmissionSoapClient();
                    var Response =
                        new ClientAdmission_LIVE.WebServiceResponse();
                    if (!testMode)
                    {
                        using (new OperationContextScope(SoapClient.InnerChannel))
                        {
                           OperationContext.Current.OutgoingMessageHeaders.Add(new SecurityHeader(
                                tbxUserSecurityToken, SystemCode + ":" + UserName, Password));
                           Response = SoapClient.AddAdmission(SystemCode, UserName, Password,
                           clientAdmissionObject, clientID);
                        }
                    }
                    // The following proved usefull for debugging changes to the web service for Cache 2017
                    // e.g. now a value is required for SubscriberAddress2
                    //DuMessageBox.Display(Response.Message,
                    //   "Env: " + SystemCode + "CrossEpisodeFinancialEligibility.AddCrossEpFinancialElig Message Response");
                    return Response.Message;
                default:
                    return "[ERROR] ClientAdmission.AddAdmission: Invalid Avatar "
                        + "Environment System Code \"" + SystemCode + "\"";
            }
        }

        /// <summary>
        /// Updates the statusBox
        /// </summary>
        /// <param name="statusBox">     The statusBox object </param>
        /// <param name="borderColor">   Background color (i.e. Color.Black) </param>
        /// <param name="backColor">     Background color (i.e. Color.White) </param>
        /// <param name="header">        Header text </param>
        /// <param name="status">        Status text </param>
        /// <param name="buttonEnabled"> Determines if the button is enabled [true/false]
        /// </param>
        /// <param name="buttonText">    Button text </param>
        /// <remarks>
        /// A nice, organized place to do all of the statusBox upating.
        /// </remarks>
        private static void UpdateStatusBox(frmDuStatusBox statusBox, Color borderColor, 
            Color backColor, string header, string status, bool buttonEnabled, 
            string buttonText)
        {
            statusBox.SetBorder(borderColor);
            statusBox.SetBackground(backColor);
            statusBox.SetHeader(header);
            statusBox.SetStatus(status);
            statusBox.ButtonEnabled(buttonEnabled);
            statusBox.ButtonText(buttonText);
            statusBox.Refresh();
        }
    }
}







