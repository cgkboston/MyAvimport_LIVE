#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: UserManagement.cs
//   VERSION: x.y.z[-stage]
//     BUILD: 200911
//   AUTHORS: development@aprettycoolprogram.com, 
//            updates for larry/mbhp alpha char in client id: priley@aspirehealthalliance.org
//            wsse wsdl impl: ckennedy@aspirehealthalliance.org
// COPYRIGHT: 2020 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport, http://github.com/myAvimport
#endregion

#region CLASS_DESCRIPTION
/* User Management logic.
 */
#endregion

#region USING
using Du;
using myAvimport.UserManagement_LIVE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;
using System.Drawing;
#endregion

namespace myAvimport
{
    internal class UserManagement
    {
        /// <returns> The web service response. </returns>
        public static string DoesUserExist(String SystemCode, String UserName, 
            String Password, String User, String UserSecurityToken)
        {
            switch (SystemCode)
            {
                case "LIVE":
                    var SoapClient = 
                        new UserManagement_LIVE.WebServicesSoapClient();
                    var Response =
                        new UserManagement_LIVE.WebServiceResponse();
                    using (new OperationContextScope(SoapClient.InnerChannel))
                    {
                        OperationContext.Current.OutgoingMessageHeaders.Add(new SecurityHeader(
                            UserSecurityToken, SystemCode + ":" + UserName, Password));
                        Response = SoapClient.DoesUserExist(SystemCode, UserName, Password, User);
                        return Response.Message;
                    }
                default:
                    return "ERROR";
            }
        }
    }
}
 







