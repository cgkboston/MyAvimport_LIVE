#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: CrossEpisodeFinancialEligibility.cs
//   VERSION: 0.5.0-beta
//     BUILD: 200911
//   AUTHORS: development@aprettycoolprogram.com, 
//            updates for larry/mbhp alpha char in client id: priley@aspirehealthalliance.org
//            wsse wsdl impl: ckennedy@aspirehealthalliance.org
// COPYRIGHT: 2020 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region CLASS_DESCRIPTION
/*  Contains all of the logic for working with the WEBSVC.CrossEpFinancialElig Web Service.
 */
#endregion

#region USING
using Du;
using myAvimport.CrossEpFinancialElig_LIVE;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;
using System.Drawing;//using System;
//using System.Collections.Generic;
//using System.Drawing;
#endregion

namespace myAvimport
{
    public class CrossEpisodeFinancialEligibility
    {
        //public string PatientID { get; set; } // TODO - needed?
        //public string clientID { get; set; } // TODO - needed?
        public string GuarantorNumber { get; set; }
        public string GuarantorName { get; set; }
        public string CoverageEffectiveDate { get; set; }
        public string ClientsRelationship { get; set; }
        public string SubscriberPolicyNumber { get; set; }
        public string SubscriberName { get; set; }
        public string SubscriberAddress1 { get; set; }
        public string SubscriberAddress2 { get; set; }
        public string SubscriberCity { get; set; }
        public string SubscriberState { get; set; }
        public string SubscriberZip { get; set; }
        public string SubscribersSex { get; set; }
        public string SubscribersSSNumber { get; set; }
        public string SubscriberEmployerName { get; set; }
        public string SubscribersBirthDate { get; set; }
        public string SubscriberMedicaidNumber { get; set; }
        public string EligibilityVerified { get; set; }
        public string GuarantorPlan { get; set; }
        public string SubscriberAssignOfBenefits { get; set; }
        public string CoordinationOfBenefits { get; set; }
        public string SubscribersCoveredDays { get; set; }
        public string MaximumCoveredDollars { get; set; }
        public string SubscriberReleaseOfInfo { get; set; }
        public string CustomizeGuarantorPlan { get; set; }
        public string GuarantorOrderNumber { get; set; }
        public DateTime UTCTimestamp { get; set; }
        /// <summary>
        /// Creates a dictionary containing all GuarantorSelectionObjects.
        /// </summary>
        /// <param name = "clients"> The converted data </param>
        /// <returns> A dictionary of GuarantorSelectionObjects tied to ClientIDs. </returns>
        /// <remarks>
        /// Creates GuarantorSelectionObjects from the data retrieved from an external file, then 
        /// puts those objects in a dictionary that ties the ClientID to the 
        /// GuarantorSelectionObject.
        /// </remarks>
        public static Dictionary<string, 
            GuarantorSelectionObject> CreateObjects(List<string>[] clients)
        {
            var guarantorSelectionObjects = new Dictionary<string, GuarantorSelectionObject>();
            //var clientCounter          = 0; // REMOVE THIS

            foreach (var client in clients)
            {
                var guarantorSelectionObject = new GuarantorSelectionObject
                {
                    //PatientID = client[0],
                    GuarantorNumber = client[1],
                    GuarantorName = client[2],
                    CoverageEffectiveDate = client[3],
                    ClientsRelationship = client[4],    // when the client relation sheep is set to 1, this indicates the Thom client is
                                                        // self insured, a tall order for these 2 year olds.  Consider changing this...
                    SubscriberPolicyNumber = client[5],
                    SubscribersName = client[6],
                    SubscriberAddress1 = client[7],
                    SubscriberAddress2 = client[8],
                    SubscriberCity = client[9],
                    SubscriberState = client[10],
                    SubscriberZip = client[11],
                    SubscribersSex = client[12],
                    SubscribersSSNumber = client[13],
                    //SubscriberEmployerName = client[14], // Thoms clients do not have employeers
                    SubscribersBirthDate = client[15],
                    //SubscriberMedicaidNumber = client[16], // Thom clients don't have medicaid numbers
                    EligibilityVerified = client[17],
                    GuarantorPlan = client[18],
                    SubscriberAssignOfBenefits = client[19],
                    CoordinationOfBenefits = client[20],
                    SubscribersCoveredDays = client[21],
                    MaximumCoveredDollars = client[22],
                    SubscriberReleaseOfInfo = client[23],  // here the Thom client provides informed consent to release medical information 
							                               // on their behalf...recall these a 2 year old clients.  Consider changing this...
                    CustomizeGuarantorPlan = client[24],
                    GuarantorOrderNumber = client[25]
                };
                /*  Dictionary format is { ClientID, GuarantorSelectionObject }
                 */
                guarantorSelectionObjects.Add(client[0], guarantorSelectionObject);
            }
            return guarantorSelectionObjects;
        }

        /// <summary>
        /// Check imported data for errors.
        /// </summary>
        /// <param name = "guarantorSelectionObjects"> The data that will be imported </param>
        /// <returns> A list of errors. </returns>
        /// <remarks>
        /// no data checks on the guarantor selection.
        /// </remarks>
         public static List<string> CheckForErrors(Dictionary<string,
            GuarantorSelectionObject> guarantorObjects)
        {
            /* TODO This needs to be tested.
             */
            var errorList = new List<string>();
            //var clientNumber = 0; // DELETE

            if (errorList.Count == 0)
            {
                errorList.Add("No errors found!");
            }

            return errorList;
        }

        /// <summary>
        /// Imports client demographics data into myAvatar.
        /// </summary>
        /// <param name = "guarantorSelectionObjects"> Dictionary contianing the 
        /// GuarantorSelectionObjects </param>
        /// <param name = "systemCode">             Avatar system code [SBOX/UAT/LIVE] </param>
        /// <param name = "username">               Avatar username </param>
        /// <param name = "password">               Avatar password </param>
        /// <param name = "testMode">               Mode flag for myAvimport </param>
        /// <param name = "throttleImport">         Throttle or not </param>
        /// <remarks>
        /// Manages the data import process.
        /// </remarks>
        public static void Import(Dictionary<string, 
            GuarantorSelectionObject> guarantorSelectionObjects, 
            string AvatarEnv, string AvatarUser, string AvatarPassword, 
            string tbxUserSecurityToken, 
            bool testMode, bool throttleImport)
        {
            string addGuarantorResponse = "";
            var statusBox = new frmDuStatusBox();
            statusBox.Show();
            UpdateStatusBox(statusBox, Color.Black, Color.LightBlue, 
                "Guarantor data import in progress...", "Starting...", false, "Done");

            var importCounter = 0;
            var totalImports  = guarantorSelectionObjects.Count;

            foreach (var guarantorSelectionObject in guarantorSelectionObjects)
            {
                if (String.IsNullOrEmpty(guarantorSelectionObject.Value.SubscriberAddress2))
                {
                    guarantorSelectionObject.Value.SubscriberAddress2 = " ";
                }
                /*if (String.IsNullOrEmpty(guarantorSelectionObject.Value.SubscriberEmployerName))
                {
                    guarantorSelectionObject.Value.SubscriberEmployerName = " ";
                }*/
                addGuarantorResponse = AddGuarantor(AvatarEnv, AvatarUser, AvatarPassword, tbxUserSecurityToken,
                    guarantorSelectionObject.Value, guarantorSelectionObject.Key, testMode);
                if (addGuarantorResponse.Contains("ERROR"))
                {
                    return;
                }
                if (addGuarantorResponse.Contains("Client ID not found"))
                {
                    addGuarantorResponse = addGuarantorResponse + " [" + guarantorSelectionObject.Key + "]";
                }
                ++importCounter;
                UpdateStatusBox(statusBox, Color.Black, Color.LightBlue,
                "Cross Ep Financial Elig WS import in progress..." , importCounter + " of " 
                + totalImports + ": " + addGuarantorResponse.ToLower() + " throttle: " 
                + throttleImport, true, "Don't touch!");

                /*UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, 
                    "Client Demographics data import in progress...", "Imported record " 
                    + (importCounter + 1) + " of " + totalImports, true, "Continue");
                */

                /*  Throttling is enabled by default, and is recommended when importing a large 
                 *  number of records.
                 *  Cgk: Throttling is also useful when debugging the web service response messages.
                 *       I upped the .5 second delay to 3 seconds so I could read the various web 
                 *       service responses.  Regarding the recommendation above, I'm thinking 
                 *       Cache 2017 and Nutanix HCI likely reduces/elmiinates the need to throttle.
                 *       Note that for Larry's Thom throttling is a viable option because the 
                 *       volume is so low compared to the old CMHC import volumes.  Larry sends
                 *       us at most a couple hundred clients a month.
                 */
                if (throttleImport.Equals(true))
                {
                    DuSystem.Pause(5000);
                }
                else
                {
                    DuSystem.Pause(500);
                }

                if (importCounter == totalImports)
                {
                    UpdateStatusBox(statusBox, Color.Black, Color.LightGreen,
                     "Cross Ep Financial Elig data import complete!", "Click \"Continue\"", true,
                     "Continue");
                }

            }

            UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, 
                "Cross Ep Financial Elig data import complete!", "Click \"Continue\"", true, 
                "Continue");

            //return "[DEFAULT] Import complete."; // DELETE
        }

        /// <summary> Adds client(s) demographic data to Avatar. </summary>
        /// <param name = "AvatarEnv"> Avatar system code [SBOX/UAT/LIVE]</param>
        /// <param name = "AvatarUsername"> Avatar username              </param>
        /// <param name = "AvatarPassword"> Avatar password              </param>
        /// <param name = "guarantorSelectionObject"> The object that contains the guarantor data.
        /// </param>
        /// <param name = "clientID">       The Client ID                </param>
        /// <returns> The web service response. </returns>
        /// <remarks>
        /// Does the actual import into the specified Avatar environment.
        /// </remarks>
        public static string AddGuarantor(string SystemCode, string UserName, 
            string Password, string tbxUserSecurityToken, 
            GuarantorSelectionObject guarantorSelectionObject, string clientID, bool testMode)
        {
            switch (SystemCode)
            {
                /* Sample Security header ntst web service response from ProofOfConcept app. 
                  * OperationContext.Current.OutgoingMessageHeaders.Add(
                       new SecurityHeader("UsernameToken-12", AvatarEnv+":"+AvatarUser, 
                         AvatarPassword));
                       resp1 = client.AddGuarantor(AvatarEnv, AvatarUser, AvatarPassword, 
                         guarantorSelectionObject, ClientID);
                */
                case "LIVE":
                    var SoapClient =
                        new CrossEpFinancialElig_LIVE.CrossEpisodeFinancialEligibilitySoapClient();
                    var Response =
                        new CrossEpFinancialElig_LIVE.WebServiceResponse();
                    if (!testMode)
                    {
                        DateTime utcTimeStamp = System.DateTime.Now.ToUniversalTime();

                        // This is some interesting code here.  The deal is the avatool always processed 
                        // the whole shebang as an array list, but now the web service takes an array list
                        // of guarantors per client.  Therefore we take the indexed object in the current array list
                        // and generate a new array list with one element to hold the web service guarantor
                        // array list.  For our purposes we only add one guarantor per client (i.e. the self 
                        // pay non contract guarantor) because this is Thom and THOM clients are all too 
                        // young to have secondary insurance policies for which the web service guarantor 
                        // list would have and could have been useful.

                        // We like to say for Thom we push partial shebangs to the web server, where a partial
                        // shebang is a list of one guarantor per client, and sent as a list per the web 
                        // service requirement.  We used to send the whole shebang to the web service.
                        // First create an array list with dimension one object then copy the current 
                        // guarantor selection object in.

                        // Other data sources may require a variable dimension guarantor object array list
                        // but for Thom clients we're safe to state the youngsters do not have more than one
                        // guarantor.  Note that the file indicates that each Thom client is the insured, that
                        // would be the ClientRelation integer (column 27 in Larry's input files) which 
                        // corresponds to Self Insured in the drop down for the Cross Episode Financial 
                        // Eligibility form in Avatar.  Refer to the Guarantor Information page, under 
                        // the section labeled as Subscriber.  The field in the top left corner is 
                        // Client's Relationship to Subscriber.  For our 2 year old Thom clients, 
                        // Larry sets the ClientRelationship Integer to 1 which corresponds to "Self" 
                        // somewhere in the Avatar dictionary values.  Sample files from Larry are 
                        // in \\ssmh-qdata\mis\Files for Import to Avatar\Thom.

                        GuarantorSelectionObject[] partialShebang = 
                            new GuarantorSelectionObject[1];
                        partialShebang[0] = guarantorSelectionObject;

                        using (new OperationContextScope(SoapClient.InnerChannel))
                        {
                            OperationContext.Current.OutgoingMessageHeaders.Add(new SecurityHeader(
                                tbxUserSecurityToken, SystemCode + ":" + UserName, Password));
                            Response = SoapClient.AddCrossEpFinancialElig(SystemCode,
                               UserName, Password, partialShebang,
                               clientID, null, utcTimeStamp);
                          }
                    }
                    // The following proved usefull for debugging changes to the web service for Cache 2017
                    // e.g. now a value is required for SubscriberAddress2
                    //DuMessageBox.Display(Response.Message, 
                    //   "Env: "+SystemCode+"CrossEpisodeFinancialEligibility.AddCrossEpFinancialElig Message Response");
                    return Response.Message;
                default:
                    DuMessageBox.Display("[ERROR]: CrossEpisodeFinancialEligibility.AddGuarantorSelection: Invalide System Code \""
                        + SystemCode, "**** ==== >>>>    INVALID SYSTEM CODE    <<<< ===== ****");
                    return "[ERROR] CrossEpisodeFinancialEligibility.AddGuarantorSelection: Invalid System Code \"" + SystemCode + 
                        "\" tbxUserSecurityToken: \"" + tbxUserSecurityToken + "\"";
            }
        }

        /// <summary>
        /// Updates the statusBox
        /// </summary>
        /// <param name="statusBox">     The statusBox object </param>
        /// <param name="borderColor">   Background color (i.e. Color.Black) </param>
        /// <param name="backColor">     Background color (i.e. Color.White) </param>
        /// <param name="header">        Header text </param>
        /// <param name="status">        Status text </param>
        /// <param name="buttonEnabled"> Determines if the button is enabled [true/false]
        /// </param>
        /// <param name="buttonText">    Button text </param>
        /// <remarks>
        /// A nice, organized place to do all of the statusBox upating.
        /// </remarks>
        private static void UpdateStatusBox(frmDuStatusBox statusBox, Color borderColor, 
            Color backColor, string header, string status, bool buttonEnabled, 
            string buttonText)
        {
            statusBox.SetBorder(borderColor);
            statusBox.SetBackground(backColor);
            statusBox.SetHeader(header);
            statusBox.SetStatus(status);
            statusBox.ButtonEnabled(buttonEnabled);
            statusBox.ButtonText(buttonText);
            statusBox.Refresh();
        }
    }
}







