#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: Program.cs
//   VERSION: 0.5.1-beta
//     BUILD: 180212
//   AUTHORS: development@aprettycoolprogram.com, updates priley@aspirehealthalliance.org
// COPYRIGHT: 2020 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region PROJECT_DESCRIPTION
/*  myAvimport: Data import utility for Netsmart's Avatar EHR.
 *
 *  >>> NOTE: THIS VERSION ONLY IMPORTS INTO SBOX <<<
 *            Please see additional information in PROJECT_NOTES section of Program.cs
 *
 *  Currently supports importing the following types of data:
 *      - Client demographics (via the ClientAdmission Web Service)
 *      - Financial eligability (via the CrossEpisodeFinancialEligability Web Service)
 *
 *  Requirements:
 *      - Du: A class library for C# .NET [http://aprettycoolprogram.com/du]
 */
#endregion

#region PROJECT_ACKNOWLEDGEMENTS
/*  All icons are from icons8.com [https://www.icons8.com]
 */
#endregion

#region PROJECT_NOTES
/*  This code is beta!
 *
 *  >>> NOTE: THIS VERSION ONLY IMPORTS INTO SBOX <<<
 *
 *      Due to time contraints, myAvimport is split into three versions, one of each Avatar environment. Eventually
 *      myAvimport will work with all environments. The current versions have the original monolythic code, and it is
 *      commented as necessary.
 *
 *  It's probably over commented, but I want to make sure it's absolutely clear as to what's going on. Any comments that
 *  are contained in "slash-asterix" (like this comment) are ancillary and can be removed.
 */
#endregion

#region USING
using System;
using System.Windows.Forms;
#endregion

namespace myAvimport
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MyAvimport());
        }
    }
}







