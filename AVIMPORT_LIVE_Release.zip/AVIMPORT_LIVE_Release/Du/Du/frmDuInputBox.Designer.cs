namespace Du
{
    partial class frmDuInputBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlInputBox = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.tbxUserResponse = new System.Windows.Forms.TextBox();
            this.pnlInputBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlInputBox
            // 
            this.pnlInputBox.BackColor = System.Drawing.Color.White;
            this.pnlInputBox.Controls.Add(this.btnCancel);
            this.pnlInputBox.Controls.Add(this.lblMessage);
            this.pnlInputBox.Controls.Add(this.btnOK);
            this.pnlInputBox.Controls.Add(this.tbxUserResponse);
            this.pnlInputBox.Location = new System.Drawing.Point(3, 3);
            this.pnlInputBox.Name = "pnlInputBox";
            this.pnlInputBox.Size = new System.Drawing.Size(394, 194);
            this.pnlInputBox.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(289, 162);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.Location = new System.Drawing.Point(28, 22);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(336, 83);
            this.lblMessage.TabIndex = 0;
            this.lblMessage.Text = "<message>";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // btnOK
            // 
            this.btnOK.Enabled = false;
            this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOK.Location = new System.Drawing.Point(31, 162);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 2;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // tbxUserResponse
            // 
            this.tbxUserResponse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbxUserResponse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxUserResponse.Location = new System.Drawing.Point(31, 108);
            this.tbxUserResponse.Multiline = true;
            this.tbxUserResponse.Name = "tbxUserResponse";
            this.tbxUserResponse.Size = new System.Drawing.Size(333, 21);
            this.tbxUserResponse.TabIndex = 1;
            this.tbxUserResponse.Text = "<user_input>";
            this.tbxUserResponse.TextChanged += new System.EventHandler(this.tbxUserResponse_TextChanged);
            // 
            // DuInputBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(400, 200);
            this.Controls.Add(this.pnlInputBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DuInputBox";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DuInputBox";
            this.pnlInputBox.ResumeLayout(false);
            this.pnlInputBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlInputBox;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TextBox tbxUserResponse;
    }
}
