//  PROJECT: Du
// FILENAME: DuDirectory.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//
using System;
using System.Collections.Generic;
using System.IO;

namespace Du
{
    /*  This class does various things with directories.
     */

    public class DuDirectory
    {
        public class Check
        {
            public static bool Exist(string directoryName)
            {
                return Directory.Exists(directoryName);
            }
        }

        public class Create
        {
            public static void New(string directoryName, bool addTrailingSlash)
            {
                if (addTrailingSlash)
                    directoryName = directoryName + @"\";

                if (!Directory.Exists(directoryName))
                    Directory.CreateDirectory(directoryName);
            }

            public static void New(string rootPath, List<string> directoryNames, bool addTrailingSlash)
            {
                foreach (var directoryName in directoryNames)
                    New(directoryName, addTrailingSlash);
            }
        }

        public class Retrieve
        {
            public static string[] FileNames(string directory)
            {
                return Directory.GetFiles(directory);
            }

            /// <summary>Gets the location of a special Windows directory.</summary>
            /// <param name="directory">The directory name.</param>
            /// <returns>The full path of the directory.</returns>
            public static string SystemSpecialDirectoryLocation(string directory)
            {
                // [1]
                switch (directory.ToLower())
                {
                    case "admintools":
                        return Environment.GetFolderPath(Environment.SpecialFolder.AdminTools);

                    case "applicationdata":
                    case "appdata":
                        return Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

                    case "cdburning":
                        return Environment.GetFolderPath(Environment.SpecialFolder.CDBurning);

                    case "desktop":
                    case "mydesktop":
                        return Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                    case "documents":
                    case "mydocuments":
                        return Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

                    case "favorites":
                    case "myfavorites":
                        return Environment.GetFolderPath(Environment.SpecialFolder.Favorites);

                    case "fonts":
                        return Environment.GetFolderPath(Environment.SpecialFolder.Fonts);

                    case "music":
                    case "myMusic":
                        return Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);

                    case "pictures":
                    case "photos":
                    case "mypictures":
                    case "myphotos":
                        return Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

                    case "programfiles":
                        return Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);

                    case "startup":
                        return Environment.GetFolderPath(Environment.SpecialFolder.Startup);

                    case "user":
                    case "userprofile":
                    case "myuserprofile":
                        return Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);

                    case "Windows":
                        return Environment.GetFolderPath(Environment.SpecialFolder.Windows);

                    case "videos":
                    case "myvideos":
                        return Environment.GetFolderPath(Environment.SpecialFolder.MyVideos);

                    default:
                        return "ERROR: Directory does not exist.";
                }
            }
        }
    }
}
