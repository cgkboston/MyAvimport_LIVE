using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Du
{
    class DuList
    {

        public static List<string> Remove(List<string> toFilter, bool empty, char commentChar)
        {
            var wrkList = new List<string>();

            foreach (var item in toFilter)
            {
                if (!AOString.Check(item, empty, commentChar))
                {
                    wrkList.Add(item);
                }
            }

            return wrkList;
        }



    }
}
