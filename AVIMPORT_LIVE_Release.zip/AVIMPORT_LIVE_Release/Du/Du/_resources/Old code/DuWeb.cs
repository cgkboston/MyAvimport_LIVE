using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Du
{
    class DuWeb
    {
    }
}


/*
  /* AOWeb.cs - Web things.
 * v00.01.170116
 * http://www.aprettycoolprogram.com/andor
 */

namespace Andor
{
    public class AOWeb
    {
    }
}

using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace AO
{
    public class AOWeb
    {
        public static void DownloadFile(string URL, string fileName)
        {
            using (WebClient webClient = new WebClient())
            {
                webClient.DownloadProgressChanged += WebClient_DownloadProgressChanged;
                webClient.DownloadFile(URL, fileName);
            }
        }

        private static void WebClient_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            throw new NotImplementedException();
        }

    }
}

//WebClient client = new WebClient();
//Uri ur = new Uri("http://remoteserver.do/images/img.jpg");
//client.Credentials = new NetworkCredential("username", "password");
//client.DownloadProgressChanged += WebClientDownloadProgressChanged;
//client.DownloadDataCompleted += WebClientDownloadCompleted;
//client.DownloadFileAsync(ur, @"C:\path\newImage.jpg");

 //And her it is the implementation of the callbacks:
 //void WebClientDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
 //{
 //    Console.WriteLine("Download status: {0}%.", e.ProgressPercentage);
 //}

 //void WebClientDownloadCompleted(object sender, DownloadDataCompletedEventArgs e)
 //{
 //    Console.WriteLine("Download finished!");
 //}


##### AO

    using System;
using System.Collections.Generic;
using System.ComponentModel;
/* A class for AO.cs that interacts with the web in a variety of ways.
 * v00.52.04.161113
 * http://aprettycoolprogram.com/ao
 */

using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace AO
{
    public class AOWeb
    {
        public static void DownloadFile(string URL, string fileName)
        {
            using (WebClient webClient = new WebClient())
            {
                webClient.DownloadProgressChanged += WebClient_DownloadProgressChanged;
                webClient.DownloadFile(URL, fileName);
            }
        }

        private static void WebClient_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            throw new NotImplementedException();
        }




    }
}





//WebClient client = new WebClient();
//Uri ur = new Uri("http://remoteserver.do/images/img.jpg");
//client.Credentials = new NetworkCredential("username", "password");
//client.DownloadProgressChanged += WebClientDownloadProgressChanged;
//client.DownloadDataCompleted += WebClientDownloadCompleted;
//client.DownloadFileAsync(ur, @"C:\path\newImage.jpg");

//And her it is the implementation of the callbacks:
//void WebClientDownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
//{
//    Console.WriteLine("Download status: {0}%.", e.ProgressPercentage);
//}

//void WebClientDownloadCompleted(object sender, DownloadDataCompletedEventArgs e)
//{
//    Console.WriteLine("Download finished!");
//}



#### AO 12-21-16

// ---------------------------------------------------------------------------------------------------------------------
// Name: DoFont.cs
// Version: 00.90.01.160731
// Author: Christopher Banwarth (development@aprettycoolprogram.com)
// Description: A class for AO that does various things with fonts.
// More: ao.aprettycoolprogram.com OR aprettycoolprogram.github.com
// ---------------------------------------------------------------------------------------------------------------------

namespace AO
{
    public class DoFont
    {
        public static void Load(string fontName)
        {
            // This doesn't do anything yet.

            //string filename = @"C:\lady.gaga";
            //File.WriteAllBytes(filename, Resources.KBREINDEERGAMES);
            //PrivateFontCollection pfc = new PrivateFontCollection();
            //pfc.AddFontFile(filename);

            //Label label = new Label();
            //label.AutoSize = true;
            //label.Font = new Font(pfc.Families[0], 16);
            //label.Text = "hello world";
            //Controls.Add(label);
        }
    }
}

// CHANGELOG
// =========
// 00.90.01.160731: Initial release

// ROADMAP
// =======
// * Proper error handling

// NOTES
// =====


 */
