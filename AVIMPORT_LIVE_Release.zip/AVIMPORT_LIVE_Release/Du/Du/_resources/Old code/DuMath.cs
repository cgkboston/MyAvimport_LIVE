//  PROJECT: Du
// FILENAME: DuMath.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//

using System;

namespace Du
{
    /*  This class does various things with math.
     */
    public class DuMath
    {
        public class Calculate
        {
            /// <summary>Convert an integer to a percentage.</summary>
            /// <param name="number">The raw data.</param>
            /// <returns>A number between 1.00 and 0.00</returns>
            public static double Percentage(int number)
            {
                return (double)number / 100;
            }
        }

        public class Create
        {


            /// <summary></summary>
            /// <param name="numberOfSides">The number of sides.</param>
            /// <param name="numberOfRolls">The number of rolls.</param>
            /// <returns></returns>
            public static int[] DieRoll(int numberOfSides, int numberOfRolls)
            {
                var results = new int[numberOfRolls];

                /* For each of the rolls, generate a number that's between 1 and the number of sides the die has,
                 * then add the result to the array that contains the roll values.
                 * */
                for (var rollNumber = 0; rollNumber < numberOfRolls; rollNumber++)
                    results[rollNumber] = RandomNumber(1, numberOfSides, false);

                return results;
            }
        }

    }
}
