//  PROJECT: Du
// FILENAME: DuButton.cs
//    BUILD: 170324
// 
// Copyright 2017 A Pretty Cool Program
// 
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
// 
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
// 
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;


/*
 * 
 *              WORK IN PROGRESS
 * 
 */


namespace Du
{
    public class DuButton
    {
        public int  IncrementX { get; set; }
        public int  IncrementY { get; set; }
        public bool IgnoreIncrements { get; set; }
        public bool IgnoreIncrementX { get; set; }
        public bool IgnoreIncrementY { get; set; }
        public int  PaddingX { get; set; }
        public int  PaddingY { get; set; }
        public bool IgnorePadding { get; set; }
        public bool IgnorePaddingX { get; set; }
        public bool IgnorePaddingY { get; set; }
        public bool IgnoreSize { get; set; }
        public bool IgnoreWidth { get; set; }
        public bool IgnoreHeight { get; set; }
        public bool IgnoreCoordinates { get; set; }
        public bool IgnoreCoordinateX { get; set; }
        public bool IgnoreCoordinateY { get; set; }
        public bool IgnoreVectors { get; set; }
        public bool IgnoreRow { get; set; }
        public bool IgnoreColumn { get; set; }

        /// <summary>Creates a new button.</summary>
        /// <param name="name">The name.</param>
        /// <param name="height">The height.</param>
        /// <param name="width">The width.</param>
        /// <param name="coordinateX">The x coordinate.</param>
        /// <param name="coordinateY">The y coordinate.</param>
        /// <param name="background">Color of the background.</param>
        /// <param name="foreground">Color of the foreground.</param>
        /// <param name="package"></param>
        /// <returns></returns>
        public static Button Create(string name, int height, int width, int coordinateX, int coordinateY, Color background, Color foreground, DuButton package)
        {
            return new Button
            {
                Name      = name,
                Height    = height,
                Width     = width,
                Location  = new Point(coordinateX, coordinateY),
                BackColor = background,
                ForeColor = foreground,
                Tag       = package
            };
        }

        /// <summary>Defines a button package.</summary>
        /// <returns>A button package.</returns>
        public static DuButton DefinePackage()
        {
            return new DuButton();
        }

        /// <summary>Creates a new button collection.</summary>
        /// <param name="buttonTemplate">The button template.</param>
        /// <param name="listOfButtonNames">The list of buttons.</param>
        /// <returns></returns>
        public static Button[] CreateCollection(Button buttonTemplate, List<string> listOfButtonNames)
        {
            var buttonNumber    = 0;
            var finalButtonName = string.Empty;
            var coordinateX     = buttonTemplate.Location.X;
            var coordinateY     = buttonTemplate.Location.Y;
            var buttonArray     = new Button[listOfButtonNames.Count];

            foreach (var buttonName in listOfButtonNames)
            {
                finalButtonName           = buttonTemplate.Name + buttonName.Replace(" ","");
                buttonArray[buttonNumber] = Create(finalButtonName, buttonTemplate.Height, buttonTemplate.Width, coordinateX, coordinateY, buttonTemplate.BackColor, buttonTemplate.ForeColor, null);
                var buttonPackage         = (Dictionary<string, string>)buttonTemplate.Tag;

                switch (buttonPackage["buildDirection"])
                {
                    case "vertical":
                        coordinateY += Convert.ToInt32(buttonPackage["IncrementY"]);
                        break;
                    case "horizontal":
                        coordinateX += Convert.ToInt32(buttonPackage["IncrementX"]);
                        break;
                    default:
                        break;
                }
                buttonNumber++;
            }

            return buttonArray;
        }




    }
}


/* 
 
CHANGELOG
=========
b170324  - Initial release
    
ROADMAP
=======
   
OLD CODE SNIPPITS
=================
 
 */
