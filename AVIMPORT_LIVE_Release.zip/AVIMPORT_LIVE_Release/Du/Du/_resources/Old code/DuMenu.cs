using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Du
{
    class DuMenu
    {
    }
}


/*
        public class Create
        {
            public static ContextMenu ContextMenu(Dictionary<string,string> menuItems )
            {
                var contextMenu = new ContextMenu();
                var itemCounter = 0;

                foreach (var menuItem in menuItems)
                {
                    MenuItem mnuItem = new MenuItem();                                                                      // New menu item object
                    mnuItem.Name.Insert(mnuItem.Name.Length, itemCounter.ToString());                                       // Add the counter to the name (i.e. "mnuItem1", "mnuItem2"...)
                    contextMenu.MenuItems.AddRange(new MenuItem[] { mnuItem });                                             // Add this item to the context menu...
                    mnuItem.Index = itemCounter;                                                                         // ...at this index...
                    mnuItem.Text = menuItem.Key;                                                                        // ...and with this text
                    mnuItem.Click += new EventHandler(menuItem.Value);
                    itemCounter++;                                                                                          // Increment the item counter for the next item
                }
            
                return contextMenu;
            }
        }


 */
