//  PROJECT: Du
// FILENAME: DuXML.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//
namespace Du
{
    internal class DuXML
    {
    }
}

/*

    ##### Du_

    //  PROJECT: Du
// FILENAME: DuXML.cs
//    BUILD: 170221
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//

using System.Collections.Generic;
using System.Xml;

namespace Du
{
    public class DuXML
    {
        public class Morph
        {
            /// <summary>Parses an XML file.</summary>
            /// <param name="fPath"></param>
            /// <param name="assyName"></param>
            /// <param name="element"></param>
            /// <returns></returns>
            public static List<Dictionary<string, string>> ToListOfDictionaries(string filePath, string assembly, string element)
            {
                //List<Dictionary<string, string>> wrkDictionary = new List<Dictionary<string, string>>();
                //Dictionary<string, string> tmpDictionary;
                //var fileLine = string.Empty;

                //if (assyName == "")
                //{
                //    XmlDocument xmlDoc = new XmlDocument();                             // xmlDoc is the new xml document.
                //    xmlDoc.Load(fPath);                                                 // load the file. FIX
                //    XmlNodeList elementNodeList = xmlDoc.GetElementsByTagName(element); // array of the level nodes.

                //    foreach (XmlNode masterNode in elementNodeList)
                //    {
                //        XmlNodeList dataNode = masterNode.ChildNodes;
                //        tmpDictionary = new Dictionary<string, string>();               // Create a object(Dictionary) to colect the both nodes inside the level node and then put into levels[] array.

                //        foreach (XmlNode subNode in dataNode)
                //        {
                //            XmlNodeList dataSubNode = subNode.ChildNodes;

                //            if (dataSubNode.Count >= 2)
                //            {
                //                foreach (XmlNode theThings in dataSubNode)
                //                {
                //                    tmpDictionary.Add(subNode.Name + "_" + theThings.Name, theThings.InnerText);
                //                }
                //            }
                //            else
                //            {
                //                tmpDictionary.Add(subNode.Name, subNode.InnerText);
                //            }
                //        }
                //        wrkDictionary.Add(tmpDictionary);
                //    }
                //}
                //else
                //{ // Embedded data
                //  //TODO Embedded code will go here
                //}

                //return wrkDictionary;
                return new List<Dictionary<string, string>>();

            }
        }

    }
}



 */
