//  PROJECT: Du
// FILENAME: DuSystem.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//
using System;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;

namespace Du
{
    /*  This class does various things the system.
     */
    public class DuSystem
    {
        public class Check
        {
            /// <summary>Gets the version of Microsoft Windows.</summary>
            /// <returns>The version of Microsoft Windows.</returns>
            public static string Version()
            {
                /* In order for this to work correctly, you'll need to add an app.manifest file to your project, and
                 * uncomment any Operating System versions you want to use. For more information, please refer to the
                 * manuals for Du.
                 */
                if (Environment.OSVersion.ToString().Contains("5.0"))
                    return "Win2000";
                if (Environment.OSVersion.ToString().Contains("5.1"))
                    return "WinXP32";
                if (Environment.OSVersion.ToString().Contains("5.2"))
                    return "WinXP64_Srv2003_Srv2003R2";
                if (Environment.OSVersion.ToString().Contains("6.0"))
                    return "Vis_Srv2008";
                if (Environment.OSVersion.ToString().Contains("6.1"))
                    return "Win7_Srv2008R2";
                if (Environment.OSVersion.ToString().Contains("6.2"))
                    return "Win8_Srv2012";
                if (Environment.OSVersion.ToString().Contains("6.3"))
                    return "Win81_Srv2012R2";
                if (Environment.OSVersion.ToString().Contains("10.0"))
                    return "Win10_Srv2016";
                return "ERROR";
            }

            /// <summary>Determines if an OS is 64-bit.</summary>
            /// <param name="dotNet4Plus">Flag if using .NET 4.0+. (true/false).</param>
            /// <returns>True or false value.</returns>
            public static bool Is64Bit(bool dotNet4Plus)
            {
                /* If your using .NET 4.0 or greater, pass "true" for "dotNet4Plus", otherwise a more primitive (and
                 * potentially less accurate) method will be used.
                 */
                if (dotNet4Plus)
                    return Environment.Is64BitOperatingSystem;
                return Directory.Exists(@"C:\Program Files (x86)") ? true : false;
            }
        }

        public class Execute
        {
            /// <summary>Executes a Microsoft Windows command.</summary>
            /// <param name="process">The process.</param>
            /// <param name="commandArguments">The arguments.</param>
            /// <returns>A string with the command output.</returns>


            /// <summary>Returns the number of successful/unsuccessful results from X ping commands.</summary>
            /// <param name="ipAddress">The IP Address to ping.</param>
            /// <param name="amount">The number of pings to attempt (integer) [4].</param>
            /// <param name="returnSuccesses">Flag to return the number of successes (true/false) [true].</param>
            /// <returns>The number of ping attempts that succeeded or failed.</returns>

        }


    }
}

/* DEVELOPMENT








*/
