//  PROJECT: Du
// FILENAME: DuWindowsGUI.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//
namespace Du
{
    internal class DuWindowsGUI
    {
    }
}

/*
 //  PROJECT: Du
// FILENAME: DuNotificationArea.cs
//    BUILD: 170221
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Du
{
    public partial class DuNotificationArea : Form
    {
        public DuNotificationArea()
        {
            InitializeComponent();
        }

        /// <summary>Overides the OnShown even.</summary>
        /// <param name="e">A <see cref="T:System.EventArgs" /> that contains the event data.</param>
        // This hides the form immediately upon creation.
        // [TODO] Not sure if this is the best way to do this, should look into other options.
        // [TODO] Also, may not want to do this?
        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            Hide();
        }

        public class Create
        {
            /// <summary>Creates an icon in the notification area.</summary>
            /// <param name="iconName">The name.</param>
            /// <param name="iconPath">The icon path.</param>
            /// <returns>A notification icon.</returns>
            // Please note that this forces the icon to be visible.
            // [TODO] Add logic to hide the icon, perhaps in another method.
            public static NotifyIcon CreateNotifyIcon(string iconName, string iconPath)
            {
                return new NotifyIcon()
                {
                    Text = iconName,
                    Icon = new Icon(Path.GetFullPath(iconPath)),
                    Visible = true
                };
            }

        }
        public class Remove
        {
            public static void TaskbarIcon()
            {
                //TaskSender.Icon = TaskSender.Properties.Resources.appiconTaskScheduler_128px;
                //this.ShowInTaskbar = false;bar = false;
            }
        }

    }
}



    #### Andor.cs

            public static void RemoveTaskbarIcon()
        {
            //TaskSender.Icon = TaskSender.Properties.Resources.appiconTaskScheduler_128px;
            //this.ShowInTaskbar = false;bar = false;
        }









 */
