using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Du
{
    class DuMessageBox
    {


    }
}

/*


    /* AOMessageBox.cs - MessageBox things.
 * v00.01.170116
 * http://www.aprettycoolprogram.com/andor
 */

namespace Andor
{
    public class AOMessageBox
    {
    }
}

using System.Net;
using System.Windows.Forms;

namespace AO
{
    public class AOMessage
    {
        public static void DownloadProgressBar(object sender, DownloadProgressChangedEventArgs e, Control controlName)
        {
            //controlName.Value = e.ProgressPercentage;

            //controlName = e.ProgressPercentage;
        }

        public static DialogResult MessageWithResult(string message, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return MessageBox.Show(message, caption, buttons, icon);
            //return result;

        }

        public static void JustMessage(string message)
        {
            MessageBox.Show(message);
        }

    }
}


#### AO.cs

/* A class for AO.cs that alert the user in a variey of ways.
 * v00.52.03.161113
 * http://aprettycoolprogram.com/ao
 */

using System.Net;
using System.Windows.Forms;

namespace AO
{
    public class AOMessage
    {
        public static void DownloadProgressBar(object sender, DownloadProgressChangedEventArgs e, Control controlName)
        {
            //controlName.Value = e.ProgressPercentage;

            //controlName = e.ProgressPercentage;
        }

        public static DialogResult MessageWithResult(string message, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return MessageBox.Show(message, caption, buttons, icon);
            //return result;

        }

        public static void JustMessage(string message)
        {
            MessageBox.Show(message);
        }


    }
}


#### AO.cs

/* A class for AO.cs that does various things with message forms.
 * v00.53.04.161220
 * http://aprettycoolprogram.com/ao
 */

/* This class is not yet fucntional */

using System.Windows.Forms;

namespace AO
{
    public partial class AOFormMessage : Form
    {
        //private string _message;

        //public string Message
        //{
        //    get { return _message; }
        //    set { _message = value; }
        //}

        /// <summary>
        /// Initializes a new instance of the <see cref="AOFormMessage"/> class.
        /// </summary>
        /// <remarks>
        /// Not yet functional.
        /// </remarks>
        public AOFormMessage()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Displays the message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <remarks>
        /// Not yet functional.
        /// </remarks>
/        public void DisplayMessage(string message)
        {
            lblMessage.Text = message;
        }
    }
}

##### AO 12-21-16

/* A class for AO.cs that alert the user in a variey of ways.
 * v00.52.03.161113
 * http://aprettycoolprogram.com/ao
 */

using System.Net;
using System.Windows.Forms;

namespace AO
{
    public class AOMessage
    {
        public static void DownloadProgressBar(object sender, DownloadProgressChangedEventArgs e, Control controlName)
        {
            //controlName.Value = e.ProgressPercentage;

            //controlName = e.ProgressPercentage;
        }

        public static DialogResult MessageWithResult(string message, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return MessageBox.Show(message, caption, buttons, icon);
            //return result;

        }

        public static void JustMessage(string message)
        {
            MessageBox.Show(message);
        }


    }
}

##### AO 12-21-16


/* A class for AO.cs that does various things with message forms.
 * v00.53.04.161220
 * http://aprettycoolprogram.com/ao
 */

/* This class is not yet fucntional */

using System.Windows.Forms;

namespace AO
{
    public partial class AOFormMessage : Form
    {
        //private string _message;

        //public string Message
        //{
        //    get { return _message; }
        //    set { _message = value; }
        //}

        /// <summary>
        /// Initializes a new instance of the <see cref="AOFormMessage"/> class.
        /// </summary>
        /// <remarks>
        /// Not yet functional.
        /// </remarks>
        public AOFormMessage()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Displays the message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <remarks>
        /// Not yet functional.
        /// </remarks>
/        public void DisplayMessage(string message)
        {
            lblMessage.Text = message;
        }
    }
}

 */
