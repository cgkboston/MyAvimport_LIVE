//  PROJECT: Du
// FILENAME: DuList.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//
using System.Collections.Generic;

namespace Du
{
    /*  This class does various things with lists.
     */
    public class DuList
    {
        public class Merge
        {
            public static List<string> StringLists(List<string> firstList, List<string> secondList)
            {
                foreach (var item in secondList)
                    firstList.Add(item);

                return firstList;
            }
        }

        public class Retrieve
        {
            /// <summary>Returns a random item from a list.</summary>
            /// <param name="listToUse">The list to use.</param>
            /// <param name="itemToGet">The item to get.</param>
            /// <returns>A random item from a list.</returns>
            public static string RandomItem(List<string> listToUse, int itemToGet)
            {
                return listToUse[itemToGet];
            }
        }

        public class Transmorgify
        {
            public static void ToFile(List<string> listToUse, string fileName)
            {
                using (var file =
                    new System.IO.StreamWriter(fileName))
                {
                    foreach (var line in listToUse)
                        file.WriteLine(line);
                }
            }
        }
    }
}

/* DEVELOPMENT

    ##### Andor.cs

    /* AOList.cs - List things.
  * v00.01.170116
 * http://www.aprettycoolprogram.com/andor
 */

namespace Andor
{
    public class AOList
    {
    }
}

/* A class for AO.cs that does various things with lists.
 * v00.53.04.161220
 * http://aprettycoolprogram.com/ao
 */

using System.Collections.Generic;

namespace AO
{
    public class AOList
    {
        /* Convert a list to an array.
         * ---
         * toConvert - the list to convert                                                                            */

        /// <summary>
        /// To the array.
        /// </summary>
        /// <param name="toConvert">To convert.</param>
        /// <returns></returns>
        public static string[] ToArray(List<string> toConvert)
        {
            var element = 0;
            var wrkArray = new string[toConvert.Count];

            /* Loop through the list and add each item to the wrkArray, incrementing the element each time.           */
            foreach (var item in toConvert)
            {
                wrkArray[element] = item;
                element++;
            }

            return wrkArray;
        }

        /* Extracts a dictionary from a list of dictionaries.
         * You'll need to know the location of the dictionary you want to extract.
         * ---
         * extractFrom      - the list of dictionaries to extract from
         * dictionaryNumber - the dictionary to extract                                                               */

        public static Dictionary<string, string> ExtractDictionary(List<Dictionary<string, string>> extractFrom, int dictionaryNumber)
        {
            Dictionary<string, string> wrkDictionary = new Dictionary<string, string>();

            // Loop through each key/value pair in the specific dictionary, and add them to the wrkDictionary.        */
            foreach (var keyValuePair in extractFrom[dictionaryNumber])
            {
                wrkDictionary.Add(keyValuePair.Key, keyValuePair.Value);
            }

            return wrkDictionary;
        }



        /* Remove something from a list.
         * ---
         * toClean     - the list to clean
         * checkEmpty  - flag to check if the item is empty
         * commentChar - the character that starts a comment line                                                     */
        public static List<string> Clean(List<string> toClean, bool checkEmpty, char commentChar)                       // TODO - Maybe combine this with below?
        {                                                                                                               // TODO - Fix to use CleaningRules
            var wrkList = new List<string>();

            foreach (var item in toClean)
            {
                if ((checkEmpty && !AOString.CheckEmpty(item, null)) || (commentChar != ' ' && !AOString.CheckComment(item, commentChar)))
                {
                    wrkList.Add(item);
                }
            }

            return wrkList;
        }



        /* Returns a specific section of a list.
         * ---
         * toWork       -
         * sectionChar  -
         * sectionDelim -                                                                                             */
        public static List<string> SectionAsList(List<string> toWork, string sectionChar, string sectionDelim)          // TODO - Additional comments
        {
            List<string> sectionList = new List<string>();
            bool record = false;

            foreach (var item in toWork)
            {
                if (record && item.StartsWith(sectionChar))
                {
                    record = false;
                    break;
                }

                if (record)
                {
                    sectionList.Add(item);
                }

                if (!record && item == sectionDelim)
                {
                    record = true;
                }
            }

            return sectionList;
        }

        /* Splits a list into multiple sections.
         * ---
         * toConvert    -
         * sectionChar  -
         * sectionDelim -                                                                                             */
        public static List<List<string>> SectionsAsLists(List<string> toConvert, string sectionChar, string sectionDelim) // TODO - Additional comments
        {
            var innerList = new List<string>();
            var outerList = new List<List<string>>();
            var record = false;

            foreach (var item in toConvert)
            {
                if (record && !item.StartsWith(sectionChar))
                {
                    innerList.Add(item);
                }

                if (item.StartsWith(sectionChar))
                {
                    if (record)
                    {
                        outerList.Add(innerList);
                        innerList = new List<string>();
                    }
                    else
                    {
                        record = true;
                    }
                }
            }

            return outerList;
        }
    }
}



#### AO.cs

/* A class for AO.cs that does various things with lists.
 * v00.53.04.161220
 * http://aprettycoolprogram.com/ao
 */

using System.Collections.Generic;

namespace AO
{
    public class AOList
    {
        /* Convert a list to an array.
         * ---
         * toConvert - the list to convert                                                                            */

        /// <summary>
        /// To the array.
        /// </summary>
        /// <param name="toConvert">To convert.</param>
        /// <returns></returns>
        public static string[] ToArray(List<string> toConvert)
        {
            var element = 0;
            var wrkArray = new string[toConvert.Count];

            /* Loop through the list and add each item to the wrkArray, incrementing the element each time.           */
            foreach (var item in toConvert)
            {
                wrkArray[element] = item;
                element++;
            }

            return wrkArray;
        }

        /* Extracts a dictionary from a list of dictionaries.
         * You'll need to know the location of the dictionary you want to extract.
         * ---
         * extractFrom      - the list of dictionaries to extract from
         * dictionaryNumber - the dictionary to extract                                                               */

        public static Dictionary<string, string> ExtractDictionary(List<Dictionary<string, string>> extractFrom, int dictionaryNumber)
        {
            Dictionary<string, string> wrkDictionary = new Dictionary<string, string>();

            // Loop through each key/value pair in the specific dictionary, and add them to the wrkDictionary.        */
            foreach (var keyValuePair in extractFrom[dictionaryNumber])
            {
                wrkDictionary.Add(keyValuePair.Key, keyValuePair.Value);
            }

            return wrkDictionary;
        }

        /* Merge two lists.
         * ---
         * firstList  - the first list
         * secondList - the second list                                                                               */
        public static List<string> Merge(List<string> firstList, List<string> secondList)
        {
            /* Loop through the items in the second list, and add it to the first list.                               */
            foreach (var item in secondList)
            {
                firstList.Add(item);
            }

            return firstList;
        }

        /* Remove something from a list.
         * ---
         * toClean     - the list to clean
         * checkEmpty  - flag to check if the item is empty
         * commentChar - the character that starts a comment line                                                     */
        public static List<string> Clean(List<string> toClean, bool checkEmpty, char commentChar)                       // TODO - Maybe combine this with below?
        {                                                                                                               // TODO - Fix to use CleaningRules
            var wrkList = new List<string>();

            foreach (var item in toClean)
            {
                if ((checkEmpty && !AOString.CheckEmpty(item, null)) || (commentChar != ' ' && !AOString.CheckComment(item, commentChar)))
                {
                    wrkList.Add(item);
                }
            }

            return wrkList;
        }

        /* Remove null values from an list.
         * ---
         * removeFrom - the string to remove nulls from                                                               */
        public static List<string> RemoveNulls(List<string> removeFrom)                                                 // TODO - Additional comments
        {
            var wrkList = new List<string>();

            foreach (var item in removeFrom)
            {
                if (item != null)
                {
                    wrkList.Add(item);
                }
            }

            return wrkList;
        }

        /* Returns a specific section of a list.
         * ---
         * toWork       -
         * sectionChar  -
         * sectionDelim -                                                                                             */
        public static List<string> SectionAsList(List<string> toWork, string sectionChar, string sectionDelim)          // TODO - Additional comments
        {
            List<string> sectionList = new List<string>();
            bool record = false;

            foreach (var item in toWork)
            {
                if (record && item.StartsWith(sectionChar))
                {
                    record = false;
                    break;
                }

                if (record)
                {
                    sectionList.Add(item);
                }

                if (!record && item == sectionDelim)
                {
                    record = true;
                }
            }

            return sectionList;
        }

        /* Splits a list into multiple sections.
         * ---
         * toConvert    -
         * sectionChar  -
         * sectionDelim -                                                                                             */
        public static List<List<string>> SectionsAsLists(List<string> toConvert, string sectionChar, string sectionDelim) // TODO - Additional comments
        {
            var innerList = new List<string>();
            var outerList = new List<List<string>>();
            var record = false;

            foreach (var item in toConvert)
            {
                if (record && !item.StartsWith(sectionChar))
                {
                    innerList.Add(item);
                }

                if (item.StartsWith(sectionChar))
                {
                    if (record)
                    {
                        outerList.Add(innerList);
                        innerList = new List<string>();
                    }
                    else
                    {
                        record = true;
                    }
                }
            }

            return outerList;
        }
    }
}


###### AO.51.160926

/* A class for AO.cs that does various things with lists.
 * v00.51.160926
 * http://aprettycoolprogram.com/ao
 */

using System.Collections.Generic;

namespace AO
{
    public class AOList
    {
        /// <summary>Convert list to array</summary>
        /// <param name="toConvert">The list to convert.</param>
        /// <returns>The list as an array.</returns>
        public static string[] ToArray(List<string> toConvert)
        {
            var element = 0;
            var wrkArray = new string[toConvert.Count];

            foreach (var item in toConvert)
            {
                wrkArray[element] = item;
                element++;
            }

            return wrkArray;
        }

        /// <summary>Converts a list to a dictionary.</summary>
        /// <param name="toConvert">The list to convert.</param>
        /// <param name="delimiter">The delimiter to use.</param>
        /// <returns>The list as a dictionary.</returns>
        public static Dictionary<string, string> ToDictionary(List<string> toConvert, char delimiter)
        {
            return AOArray.AsDictionary(ToArray(toConvert), delimiter);
        }

        /// <summary>Extracts a dictionary from a list of dictionaries.</summary>
        /// <param name="extractFrom">The list of dictionaries to extract from.</param>
        /// <param name="dictionaryNumber">The dictionary to extract.</param>
        /// <returns>The extracted dictionary.</returns>
        public static Dictionary<string, string> ExtractDictionary(List<Dictionary<string, string>> extractFrom, int dictionaryNumber)
        {
            Dictionary<string, string> wrkDictionary = new Dictionary<string, string>();

            foreach (var keyValuePair in extractFrom[dictionaryNumber])
            {
                wrkDictionary.Add(keyValuePair.Key, keyValuePair.Value);
            }

            return wrkDictionary;
        }

        /// <summary>Merge two lists.</summary>
        /// <param name="firstList">The first list.</param>
        /// <param name="secondList">The second list.</param>
        /// <returns>The two lists merged as one.</returns>
        public static List<string> Merge(List<string> firstList, List<string> secondList)
        {
            foreach (var item in secondList)
            {
                firstList.Add(item);
            }

            return firstList;
        }

        /// <summary>Remove something from a list.</summary>
        /// <param name="toFilter"></param>
        /// <param name="action"></param>
        /// <param name="empty"></param>
        /// <param name="commentChar"></param>
        /// <returns></returns>
        public static List<string> Remove(List<string> toFilter, bool empty, char commentChar)
        {
            var wrkList = new List<string>();

            foreach (var item in toFilter)
            {
                if (!AOString.Check(item, empty, commentChar))
                {
                    wrkList.Add(item);
                }
            }

            return wrkList;
        }

        /// <summary>Remove null values from an list</summary>
        /// <param name="removeFrom">The list to remove nulls from</param>
        /// <returns>An array without null values</returns>
        public static List<string> RemoveNulls(List<string> removeFrom) // Add to "Remove"?
        {
            var wrkList = new List<string>();

            foreach (var item in removeFrom)
            {
                if (item != null)
                {
                    wrkList.Add(item);
                }
            }

            return wrkList;
        }

        /// <summary>Returns a specific section of a list.</summary>
        /// <param name="toWork">The list to work with</param>
        /// <param name="sectionChar">The character that indicates a section ["%"]</param>
        /// <param name="sectionDelim">The section we are looking for ["%SECTION"] "</param>
        /// <returns>The section of a list, as a list.</returns>
        public static List<string> SectionAsList(List<string> toWork, string sectionChar, string sectionDelim)
        {
            List<string> sectionList = new List<string>();
            bool record = false;

            foreach (var item in toWork)
            {
                if (record && item.StartsWith(sectionChar))
                {
                    record = false;
                    break;
                }

                if (record)
                {
                    sectionList.Add(item);
                }

                if (!record && item == sectionDelim)
                {
                    record = true;
                }
            }

            return sectionList;
        }

        /// <summary>Splits a list into multiple sections.</summary>
        /// <param name="toConvert">The list to split.</param>
        /// <param name="sectionChar">The character to split at ["%"]</param>
        /// <param name="sectionDelim">The string to split at ["%"]</param>
        /// <returns>A list of lists of sections.</returns>
        public static List<List<string>> SectionsAsLists(List<string> toConvert, string sectionChar, string sectionDelim)
        {
            var innerList = new List<string>();
            var outerList = new List<List<string>>();
            var record = false;

            foreach (var item in toConvert)
            {
                if (record && !item.StartsWith(sectionChar))
                {
                    innerList.Add(item);
                }

                if (item.StartsWith(sectionChar))
                {
                    if (record)
                    {
                        outerList.Add(innerList);
                        innerList = new List<string>();
                    }
                    else
                    {
                        record = true;
                    }
                }
            }

            return outerList;
        }
    }
}


######## AO ss 8-2-16

// ---------------------------------------------------------------------------------------------------------------------
// Name: DoList.cs
// Version: 00.90.01.160731
// Author: Christopher Banwarth (development@aprettycoolprogram.com)
// Description: A class for AO that does various things with lists.
// More: ao.aprettycoolprogram.com OR aprettycoolprogram.github.com
// ---------------------------------------------------------------------------------------------------------------------

using System.Collections.Generic;

namespace AO
{
    public class DoList
    {
        /// <summary>Convert list to array</summary>
        /// <param name="toConvert"></param>
        /// <returns></returns>
        /// <remarks>None</remarks>
        /// <build>160713</build>
        public static string[] ContentAsArray(List<string> toConvert)
        {
            var elementCount = 0;
            var stringArray = new string[toConvert.Count];

            foreach (var item in toConvert)
            {
                stringArray[elementCount] = item;
                elementCount++;
            }
            return stringArray;
        }

        public static Dictionary<string, string> ContentAsDictionary(List<string> toConvert, char delim)
        {
            return DoArray.ContentAsDictionary(ContentAsArray(toConvert), delim);
        }

        /// <summary>Extracts a dictionary from a list of dictionaries.</summary>
        /// <param name="extractFrom">The list of dictionaries to extract from.</param>
        /// <param name="dictionaryToExtract">The dictionary to extract.</param>
        /// <returns>The extracted dictionary.</returns>
        /// <remarks>None</remarks>
        /// <build>160719</build>
        public static Dictionary<string, string> ExtractDictionary(List<Dictionary<string, string>> extractFrom, int dictionaryToExtract)
        {
            Dictionary<string, string> wrkDictionary = new Dictionary<string, string>();

            foreach (var item in extractFrom[dictionaryToExtract])
            {
                wrkDictionary.Add(item.Key, item.Value);
            }

            return wrkDictionary;
        }

        /// <summary>QUICK</summary>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        /// <remarks>None</remarks>
        /// <build>160713</build>
        public static List<string> Merge(List<string> first, List<string> second)
        {
            foreach (var item in second)
            {
                first.Add(item);
            }
            return first;
        }

        /// <summary> </summary>
        /// <param name="listToFilter"></param>
        /// <param name="rmEmpty"></param>
        /// <param name="rmComment"></param>
        /// <param name="commentChar"></param>
        /// <returns></returns>
        /// <remarks>None</remarks>
        /// <build>160713</build>
        public static List<string> Remove(List<string> toProcess, bool rmEmpty, char commentChar)
        {
            var wrkList = new List<string>(); // List to return

            // Add element to list if it passes audit
            foreach (var element in toProcess)
            {
                if (DoString.Test(element, rmEmpty, commentChar))
                {
                    wrkList.Add(element);
                }
            }
            return wrkList;
        }

        /// <summary>Remove null values from an list</summary>
        /// <param name="removeFrom">The list to remove nulls from</param>
        /// <returns>An array without null values</returns>
        /// <remarks>None</remarks>
        /// <build>160713</build>
        public static List<string> RemoveNulls(List<string> removeFrom)
        {
            var wrkList = new List<string>(); // List to return

            foreach (var item in removeFrom)
            {
                if (item != null)
                {
                    wrkList.Add(item);
                }
            }
            return wrkList;
        }


        public static List<string> SectionAsList(List<string> toWork, string sectionChar, string sectionDelim)
        {
            List<string> sectionList = new List<string>();
            bool recording = false;

            foreach (var item in toWork)
            {
                if (recording && item.StartsWith(sectionChar))
                {
                    recording = false;
                    break;
                }
                if (recording)
                {
                    sectionList.Add(item);
                }
                if (item == sectionDelim)
                {
                    recording = true;
                }
            }
            return sectionList;
        }

        public static List<List<string>> SectionsAsListOfLists(List<string> toWork, string sectionChar, string sectionDelim)
        {
            List<string> sectionList = new List<string>();
            List<List<string>> sectionsListOfLists = new List<List<string>>();
            bool recording = false;

            foreach (var item in toWork)
            {
                if (recording && item.StartsWith(sectionChar))
                {
                    recording = false;
                    //break;
                }
                if (recording)
                {
                    sectionList.Add(item);
                }
                if (item == sectionDelim)
                {
                    recording = true;
                }
            }
            return sectionsListOfLists;
        }

    }
}

// CHANGELOG
// =========
// 00.90.00.160717: Initial release
// 00.90.01.160731: Code and comment cleanup; added "ExtractDictionary" function

// ROADMAP
// =======
// * Proper error handling

// NOTES
// =====


##### AO 12-21-16

    /* A class for AO.cs that does various things with lists.
 * v00.53.04.161220
 * http://aprettycoolprogram.com/ao
 */

using System.Collections.Generic;

namespace AO
{
    public class AOList
    {
        /* Convert a list to an array.
         * ---
         * toConvert - the list to convert                                                                            */

        /// <summary>
        /// To the array.
        /// </summary>
        /// <param name="toConvert">To convert.</param>
        /// <returns></returns>
        public static string[] ToArray(List<string> toConvert)
        {
            var element = 0;
            var wrkArray = new string[toConvert.Count];

            /* Loop through the list and add each item to the wrkArray, incrementing the element each time.           */
            foreach (var item in toConvert)
            {
                wrkArray[element] = item;
                element++;
            }

            return wrkArray;
        }

        /* Extracts a dictionary from a list of dictionaries.
         * You'll need to know the location of the dictionary you want to extract.
         * ---
         * extractFrom      - the list of dictionaries to extract from
         * dictionaryNumber - the dictionary to extract                                                               */

        public static Dictionary<string, string> ExtractDictionary(List<Dictionary<string, string>> extractFrom, int dictionaryNumber)
        {
            Dictionary<string, string> wrkDictionary = new Dictionary<string, string>();

            // Loop through each key/value pair in the specific dictionary, and add them to the wrkDictionary.        */
            foreach (var keyValuePair in extractFrom[dictionaryNumber])
            {
                wrkDictionary.Add(keyValuePair.Key, keyValuePair.Value);
            }

            return wrkDictionary;
        }

        /* Merge two lists.
         * ---
         * firstList  - the first list
         * secondList - the second list                                                                               */
        public static List<string> Merge(List<string> firstList, List<string> secondList)
        {
            /* Loop through the items in the second list, and add it to the first list.                               */
            foreach (var item in secondList)
            {
                firstList.Add(item);
            }

            return firstList;
        }

        /* Remove something from a list.
         * ---
         * toClean     - the list to clean
         * checkEmpty  - flag to check if the item is empty
         * commentChar - the character that starts a comment line                                                     */
        public static List<string> Clean(List<string> toClean, bool checkEmpty, char commentChar)                       // TODO - Maybe combine this with below?
        {                                                                                                               // TODO - Fix to use CleaningRules
            var wrkList = new List<string>();

            foreach (var item in toClean)
            {
                if ((checkEmpty && !AOString.CheckEmpty(item, null)) || (commentChar != ' ' && !AOString.CheckComment(item, commentChar)))
                {
                    wrkList.Add(item);
                }
            }

            return wrkList;
        }

        /* Remove null values from an list.
         * ---
         * removeFrom - the string to remove nulls from                                                               */
        public static List<string> RemoveNulls(List<string> removeFrom)                                                 // TODO - Additional comments
        {
            var wrkList = new List<string>();

            foreach (var item in removeFrom)
            {
                if (item != null)
                {
                    wrkList.Add(item);
                }
            }

            return wrkList;
        }

        /* Returns a specific section of a list.
         * ---
         * toWork       -
         * sectionChar  -
         * sectionDelim -                                                                                             */
        public static List<string> SectionAsList(List<string> toWork, string sectionChar, string sectionDelim)          // TODO - Additional comments
        {
            List<string> sectionList = new List<string>();
            bool record = false;

            foreach (var item in toWork)
            {
                if (record && item.StartsWith(sectionChar))
                {
                    record = false;
                    break;
                }

                if (record)
                {
                    sectionList.Add(item);
                }

                if (!record && item == sectionDelim)
                {
                    record = true;
                }
            }

            return sectionList;
        }

        /* Splits a list into multiple sections.
         * ---
         * toConvert    -
         * sectionChar  -
         * sectionDelim -                                                                                             */
        public static List<List<string>> SectionsAsLists(List<string> toConvert, string sectionChar, string sectionDelim) // TODO - Additional comments
        {
            var innerList = new List<string>();
            var outerList = new List<List<string>>();
            var record = false;

            foreach (var item in toConvert)
            {
                if (record && !item.StartsWith(sectionChar))
                {
                    innerList.Add(item);
                }

                if (item.StartsWith(sectionChar))
                {
                    if (record)
                    {
                        outerList.Add(innerList);
                        innerList = new List<string>();
                    }
                    else
                    {
                        record = true;
                    }
                }
            }

            return outerList;
        }
    }
}

##### From DuDictionary

public class DuDictionary
{
    /// <summary>Creates a string dictionary from a string list.</summary>
    /// <param name="list">The list.</param>
    /// <returns>A dictionary.</returns>
    public static Dictionary<string, string> FromList(List<string> toConvert)
    {
        //  This creates a dictionary from a list, where odd entries are keys, and even entries are values. For instance
        //  the following list:
        //          "cat", "Jonesy", "dog", "Spike"
        //  would be converted to:
        //          cat Jonesy
        //          dog spike
        var wrkDictionary = new Dictionary<string, string>();

        // Each pass increments by 2, so that each key/value (odds/evens) pair can be created.
        for (var key = 0; key < toConvert.Count; key += 2) // [TODO] - Do this with a Lambda expression
            wrkDictionary.Add(toConvert[key], toConvert[key + 1]);

        return wrkDictionary;
    }
}




*/
