//  PROJECT: Du
// FILENAME: DuWindowsFormApp.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//

using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Du
{
    /*  This class does various things with strings.
     */
    public partial class DuWindowsFormApp : Form
    {
        public DuWindowsFormApp()
        {
            InitializeComponent();
        }


        /// <summary>Buttons.</summary>
        public class Btn
        {
            /// <summary>Sets the background image of a button.</summary>
            /// <param name="buttonToSet">The button to set.</param>
            /// <param name="backgroundImageFile">The background image file.</param>
            public static void BackgroundImageSet(Button buttonToSet, string backgroundImageFile, ImageLayout layout)
            {
                buttonToSet.BackgroundImage = Image.FromFile(backgroundImageFile);
                BackgroundImageLayoutSet(buttonToSet, layout);
            }

            /// <summary>Sets the background image layout.</summary>
            /// <param name="buttonToSet">The button to set.</param>
            /// <param name="layout">The layout.</param>
            public static void BackgroundImageLayoutSet(Button buttonToSet, ImageLayout layout)
            {
                buttonToSet.BackgroundImageLayout = layout;
            }

            /// <summary>Sets the background color.</summary>
            /// <param name="buttonToPaint">The button to paint.</param>
            /// <param name="colorToUse">The color to use.</param>
            public static void BackgroundColorSet(Button buttonToPaint, Color colorToUse)
            {
                buttonToPaint.BackColor = colorToUse;
            }

            /// <summary>Toggles the background colors.</summary>
            /// <param name="buttonToToggle">The button to toggle.</param>
            /// <param name="colorOne">The color one.</param>
            /// <param name="colorTwo">The color two.</param>
            public static void BackgroundColorToggle(Button buttonToToggle, Color colorOne, Color colorTwo)
            {
                buttonToToggle.BackColor = buttonToToggle.BackColor == colorOne
                    ? colorTwo
                    : colorOne;
            }

            /// <summary> Sets the color of the border.</summary>
            /// <param name="buttonToSet">The button to set.</param>
            /// <param name="borderColor">Color of the border.</param>
            public static void BorderColorSet(Button buttonToSet, Color borderColor)
            {
                buttonToSet.FlatAppearance.BorderColor = borderColor;
            }

            /// <summary>Toggles the border color.</summary>
            /// <param name="buttonToToggle">The button to toggle.</param>
            /// <param name="colorOne">The color one.</param>
            /// <param name="colorTwo">The color two.</param>
            public static void BorderColorToggle(Button buttonToToggle, Color colorOne, Color colorTwo)
            {
                buttonToToggle.FlatAppearance.BorderColor = buttonToToggle.FlatAppearance.BorderColor == colorOne
                    ? colorTwo
                    : colorOne;
            }

            /// <summary>Sets the border size of a button.</summary>
            /// <param name="buttonToSet">The button to set.</param>
            /// <param name="borderSize">Size of the border.</param>
            public static void BorderSizeSet(Button buttonToSet, int borderSize)
            {
                buttonToSet.FlatAppearance.BorderSize = borderSize;
            }

            /// <summary>Toggles the border size.</summary>
            /// <param name="buttonToSet">The button to set.</param>
            /// <param name="borderSizeOne">The border size one.</param>
            /// <param name="borderSizeTwo">The border size two.</param>
            public static void BorderSizesToggle(Button buttonToSet, int borderSizeOne, int borderSizeTwo)
            {
                buttonToSet.FlatAppearance.BorderSize = buttonToSet.FlatAppearance.BorderSize == borderSizeOne
                    ? borderSizeTwo
                    : borderSizeOne;
            }

            /// <summary>Sets the foreground color.</summary>
            /// <param name="buttonToPaint">The button to paint.</param>
            /// <param name="colorToUse">The color to use.</param>
            public static void ForegroundColorSet(Button buttonToPaint, Color colorToUse)
            {
                buttonToPaint.ForeColor = colorToUse;
            }

            /// <summary>Toggles the foreground color.</summary>
            /// <param name="buttonToToggle">The button to toggle.</param>
            /// <param name="colorOne">The color one.</param>
            /// <param name="colorTwo">The color two.</param>
            public static void ForegroundColorToggle(Button buttonToToggle, Color colorOne, Color colorTwo)
            {
                buttonToToggle.ForeColor = buttonToToggle.ForeColor == colorOne
                    ? colorTwo
                    : colorOne;
            }

            /// <summary>Sets the mouse down background color.</summary>
            /// <param name="buttonToPaint">The button to paint.</param>
            /// <param name="colorToUse">The color to use.</param>
            public static void MouseDownBackColorSet(Button buttonToPaint, Color colorToUse)
            {
                buttonToPaint.FlatAppearance.MouseDownBackColor = colorToUse;
            }

            /// <summary> Sets the mouse over background color.</summary>
            /// <param name="buttonToPaint">The button to paint.</param>
            /// <param name="colorToUse">The color to use.</param>
            public static void MouseOverBackColorSet(Button buttonToPaint, Color colorToUse)
            {
                buttonToPaint.FlatAppearance.MouseOverBackColor = colorToUse;
            }

            /// <summary>Sets the status.</summary>
            /// <param name="buttonToSet">The button to set.</param>
            /// <param name="propertyToSet">The property to set.</param>
            /// <param name="stateIs">if set to <c>true</c> [state is].</param>
            public static void StateSet(Button buttonToSet, string propertyToSet, bool stateIs)
            {
                buttonToSet.GetType().GetProperty(propertyToSet).SetValue(buttonToSet, stateIs);
            }

            /// <summary>Swaps the status.</summary>
            /// <param name="firstButtonToSet">The first button to set.</param>
            /// <param name="secondButtonToSet">The second button to set.</param>
            /// <param name="propertyToSwap">The property to swap.</param>
            public static void StateSwap(Button firstButtonToSet, Button secondButtonToSet, string propertyToSwap)
            {
                /* In order for this to work, we need to store the original value of each controls state prior to
                 * calling this method.The easiest way to do this is to make sure the states are set when the form is
                 * initialized.
                 */
                var originalStateOfFirstControl = Convert.ToBoolean(firstButtonToSet.GetType().GetProperty(propertyToSwap).GetValue(firstButtonToSet));
                var originalStateOfSecondControl = Convert.ToBoolean(secondButtonToSet.GetType().GetProperty(propertyToSwap).GetValue(secondButtonToSet));

                StateSet(firstButtonToSet, propertyToSwap, originalStateOfSecondControl);
                StateSet(secondButtonToSet, propertyToSwap, originalStateOfFirstControl);
            }

            /// <summary>Toggle the state of a control property.</summary>
            /// <param name="buttonToSet">NAme of control.</param>
            /// <param name="propertyToSet">The state to change ("Enabled","Visible").</param>
            public static void StateToggle(Button buttonToSet, string propertyToSet)
            {
                StateSet(buttonToSet, propertyToSet, !Convert.ToBoolean(buttonToSet.GetType().GetProperty(propertyToSet).GetValue(buttonToSet)));
            }
        }

        public class DuGroupBox
        {
            /*  This is a subclass of DuControl that handles GroupBoxes.
                */

            //public static void BackgroundColorSet(Button buttonToPaint, Color colorToUse)
            //{
            //    buttonToPaint.BackColor = colorToUse;
            //}

            //public static void BackgroundColorToggle(Button buttonToToggle, Color colorOne, Color colorTwo)
            //{
            //    buttonToToggle.BackColor = (buttonToToggle.BackColor == colorOne)
            //        ? colorTwo
            //        : colorOne;
            //}

            //public static void ForegroundColorToggle(Button controlToToggle, Color colorOne, Color colorTwo)
            //{
            //    controlToToggle.ForeColor = (controlToToggle.ForeColor == colorOne)
            //        ? colorTwo
            //        : colorOne;
            //}

            //public static void BorderColorSet(Button buttonToSet, Color borderColor)
            //{
            //    buttonToSet.FlatAppearance.BorderColor = borderColor;
            //}

            //public static void ForegroundColorSet(Button buttonToPaint, Color colorToUse)
            //{
            //    buttonToPaint.ForeColor = colorToUse;
            //}

            //public static void BorderSizeToggle(Button buttonToSet, int borderSizeOne, int borderSizeTwo)
            //{
            //    buttonToSet.FlatAppearance.BorderSize = (buttonToSet.FlatAppearance.BorderSize == borderSizeOne)
            //        ? borderSizeTwo
            //        : borderSizeOne;
            //}

            public class Status
            {
                public static void Set(GroupBox groupBoxToSet, string propertyToSet, bool stateIs)
                {
                    groupBoxToSet.GetType().GetProperty(propertyToSet).SetValue(groupBoxToSet, stateIs);
                }
            }

            public class Swap
            {
                public static void Statuses(GroupBox firstGroupBoxToSet, GroupBox secondGroupBoxToSet, string propertyToSwap)
                {
                    /* In order for this to work, we need to store the original value of each controls state prior to
                     * calling this method.The easiest way to do this is to make sure the states are set when the form is
                     * initialized.
                     */
                    var originalStateOfFirstControl = Convert.ToBoolean(firstGroupBoxToSet.GetType().GetProperty(propertyToSwap).GetValue(firstGroupBoxToSet));
                    var originalStateOfSecondControl = Convert.ToBoolean(secondGroupBoxToSet.GetType().GetProperty(propertyToSwap).GetValue(secondGroupBoxToSet));

                    Status.Set(firstGroupBoxToSet, propertyToSwap, originalStateOfSecondControl);
                    Status.Set(secondGroupBoxToSet, propertyToSwap, originalStateOfFirstControl);
                }
            }

            ///// <summary>Toggle the state of a control property.</summary>

            ///// <param name="controlToSet">NAme of control.</param>
            ///// <param name="propertyToSet">The state to change ("Enabled","Visible").</param>
            //public static void StateToggle(Button controlToSet, string propertyToSet)
            //{
            //    StateSet(controlToSet, propertyToSet, !Convert.ToBoolean(controlToSet.GetType().GetProperty(propertyToSet).GetValue(controlToSet)));
            //}
        }

        public class Check
        {
            /// <summary>Check to see if a control exists.</summary>
            /// <param name="containingForm">The containing form.</param>
            /// <param name="controlToCheck">The control to check.</param>
            /// <returns>True/false.</returns>
            public static bool Exists(Form containingForm, string controlToCheck)
            {
                return containingForm.Controls.Find(controlToCheck, false).FirstOrDefault() != null;
            }
        }

        public class Status
        {
            public static void Set(Panel panelToSet, string propertyToSet, bool stateIs)
            {
                panelToSet.GetType().GetProperty(propertyToSet).SetValue(panelToSet, stateIs);
            }
        }

        public class Swap
        {
            public static void Statuses(Panel firstPanelToSet, Panel secondPanelToSet, string propertyToSwap)
            {
                /* In order for this to work, we need to store the original value of each controls state prior to
                 * calling this method.The easiest way to do this is to make sure the states are set when the form is
                 * initialized.
                 */
                var originalStateOfFirstControl = Convert.ToBoolean(firstPanelToSet.GetType().GetProperty(propertyToSwap).GetValue(firstPanelToSet));
                var originalStateOfSecondControl = Convert.ToBoolean(secondPanelToSet.GetType().GetProperty(propertyToSwap).GetValue(secondPanelToSet));

                Status.Set(firstPanelToSet, propertyToSwap, originalStateOfSecondControl);
                Status.Set(secondPanelToSet, propertyToSwap, originalStateOfFirstControl);
            }
        }

        public class Toggle
        {
            /// <summary>Toggle the state of a control property.</summary>
            /// <param name="panelToSet">NAme of control.</param>
            /// <param name="propertyToSet">The state to change ("Enabled","Visible").</param>
            public static void Statuses(Panel panelToSet, string propertyToSet)
            {
                Status.Set(panelToSet, propertyToSet, !Convert.ToBoolean(panelToSet.GetType().GetProperty(propertyToSet).GetValue(panelToSet)));
            }
        }
    }
}

/* DEVELOPMENT

############
Du
############//public class Paint
//{
//    /// <summary>Sets the background color of a control.</summary>
//    /// <param name="controlToPaint">The control name.</param>
//    /// <param name="requestedColor">The requsted background color.</param>
//    public static void Background(Control controlToPaint, Color requestedColor)
//    {
//        controlToPaint.BackColor = requestedColor;
//    }

//    /// <summary>Sets the background colors of a list of controls.</summary>
//    /// <param name="listOfControlsToPaint">The list of controls.</param>
//    /// <param name="requestedColor">The background color.</param>
//    public static void Backgrounds(List<Control> listOfControlsToPaint, Color requestedColor)
//    {
//        foreach (var individualControl in listOfControlsToPaint)
//        {
//            Background(individualControl, requestedColor);
//        }
//    }

//    /// <summary>Sets the foreground color of a control.</summary>
//    /// <param name="controlToPaint">The control name</param>
//    /// <param name="RequestedColor">The foreground folor</param>
//    public static void Foreground(Control controlToPaint, Color RequestedColor)
//    {
//        controlToPaint.ForeColor = RequestedColor;
//    }

//    /// <summary>Sets the text color of a control.</summary>
//    /// <param name="controlToPaint">The control name</param>
//    /// <param name="RequestedColor">The foreground folor</param>
//    public static void Text(Control controlToPaint, Color RequestedColor)
//    {
//        controlToPaint.ForeColor = RequestedColor;
//    }

//    /// <summary>Toggles the background color of a control.</summary>
//    /// <param name="controlToToggle">Name of the control.</param>
//    /// <param name="colorOne">The first color.</param>
//    /// <param name="colorTwo">The second color.</param>
//    public static void ToggleBackground(Control controlToToggle, Color colorOne, Color colorTwo)
//    {
//        controlToToggle.BackColor = (controlToToggle.BackColor == colorOne)
//            ? colorTwo
//            : colorOne;
//    }

//    /// <summary>Toggles the text color of a control.</summary>
//    /// <param name="controlToToggle">Name of the control.</param>
//    /// <param name="colorOne">The first color.</param>
//    /// <param name="colorTwo">The second color.</param>
//    public static void ToggleText(Control controlToToggle, Color colorOne, Color colorTwo)
//    {
//        controlToToggle.ForeColor = (controlToToggle.ForeColor == colorOne)
//            ? colorTwo
//            : colorOne;
//    }

//}

//public class Outline
//{
//    /// <summary>Toggles the outline (Border) of a control.</summary>
//    public static void LabelToggle(Label labelToToggle,BorderStyle borderStyleOne, BorderStyle borderStyleTwo)
//    {
//        labelToToggle.BorderStyle = (labelToToggle.BorderStyle == borderStyleOne)
//            ? borderStyleTwo
//            : borderStyleOne;
//    }

//}

/*  DEVELOPMENT NOTES
 *  =================
 *  [TODO] Btn.MouseDownColor
 *  [TODO] Paint.ControlsOfType()               Gets a list of a control type in a control (i.e. a list of TextBoxes in a panel)
 *  [TODO] Paint.ControlsOfType()               Gets a list of a control type in a form (i.e. a list of TextBoxes)
 *  [TODO] Paint.Foregrounds()                  Paint a list of foreground colors
 *  [TODO] Paint.SwapForeground()               Swap foreground colors betwen two controls
 *  [TODO] Paint.SwapForegroundds()             Swap foreground colors betwen multiple controls
 *  [TODO] Paint.SwapBackground()               Swap background colors betwen two controls
 *  [TODO] Paint.SwapBackgrounds()              Swap background colors betwen multiple controls
 *  [TODO] Paint.ToggleBackgrounds()            Toggle the background color of multiple controls
 *  [TODO] Paint.ToggleForeground()             Swap foreground colors betwen two controls
 *  [TODO] Paint.ToggleForegroundds()           Swap foreground colors betwen multiple controls
 *  [TODO] State.Get()                          Get the state of a boolean control (i.e. visible, enabled, etc)
 *  [TODO] OfType.Get()                         Get the type of control
 *  [TODO] OfType.Set()                         Set the type of control
 */

/*

#####
Du_
#####

    //  PROJECT: Du
// FILENAME: DuControl.cs
//    BUILD: 170221
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Du
{
    public class DuControl
    {
        #region ClassFields
        public int  IncrementX        { get; set; }
        public int  IncrementY        { get; set; }
        public bool IgnoreIncrements  { get; set; }
        public bool IgnoreIncrementX  { get; set; }
        public bool IgnoreIncrementY  { get; set; }
        public int  PaddingX          { get; set; }
        public int  PaddingY          { get; set; }
        public bool IgnorePadding     { get; set; }
        public bool IgnorePaddingX    { get; set; }
        public bool IgnorePaddingY    { get; set; }
        public bool IgnoreSize        { get; set; }
        public bool IgnoreWidth       { get; set; }
        public bool IgnoreHeight      { get; set; }
        public bool IgnoreCoordinates { get; set; }
        public bool IgnoreCoordinateX { get; set; }
        public bool IgnoreCoordinateY { get; set; }
        public bool IgnoreVectors     { get; set; }
        public bool IgnoreRow         { get; set; }
        public bool IgnoreColumn      { get; set; }
        #endregion

        #region PublicMethods
        public class Create
        {
            /// <summary>Creates a new button.</summary>
            /// <param name="name">The name.</param>
            /// <param name="height">The height.</param>
            /// <param name="width">The width.</param>
            /// <param name="coordinateX">The x coordinate.</param>
            /// <param name="coordinateY">The y coordinate.</param>
            /// <param name="background">Color of the background.</param>
            /// <param name="foreground">Color of the foreground.</param>
            /// <param name="manifest"></param>
            /// <returns></returns>
            public static Button AButton(string name, int height, int width, int coordinateX, int coordinateY, Color background, Color foreground, DuControl package)
            {
                return new Button
                {
                    Name = name,
                    Height = height,
                    Width = width,
                    Location = new Point(coordinateX, coordinateY),
                    BackColor = background,
                    ForeColor = foreground,
                    Tag = package
                };
            }

            /// <summary>Creates a new button collection.</summary>
            /// <param name="buttonTemplate">The button template.</param>
            /// <param name="listOfButtonNames">The list of buttons.</param>
            /// <returns></returns>
            public static Button[] AButtonCollection(Button buttonTemplate, List<string> listOfButtonNames)
            {
                var number      = 0;
                //var buttonName  = string.Empty;
                var coordinateX = buttonTemplate.Location.X;
                var coordinateY = buttonTemplate.Location.Y;
                var buttonArray = new Button[listOfButtonNames.Count];

                foreach (var button in listOfButtonNames)
                {
                    var buttonName      = buttonTemplate.Name + DuString.Remove.Content(button, "spaces");
                    buttonArray[number] = AButton(buttonName, buttonTemplate.Height, buttonTemplate.Width, coordinateX, coordinateY, buttonTemplate.BackColor, buttonTemplate.ForeColor, null);
                    var buttonPackage   = (Dictionary<string, string>) buttonTemplate.Tag;

                    switch (buttonPackage["buildDirection"])
                    {
                        case "vertical":
                            coordinateY += Convert.ToInt32(buttonPackage["IncrementY"]);
                            break;
                        case "horizontal":
                            coordinateX += Convert.ToInt32(buttonPackage["IncrementX"]);
                            break;
                        default:
                            break;
                    }
                    number++;
                }

                return buttonArray;
            }

            /// <summary></summary>
            /// <param name="name">The name.</param>
            /// <param name="coordinateX">The x coordinate.</param>
            /// <param name="coordinateY">The y coordinate.</param>
            /// <param name="manifest">The manifest.</param>
            /// <returns></returns>
            public static CheckBox ACheckBox(string name, int coordinateX, int coordinateY, DuControl package)
            {
                return new CheckBox
                {
                    Name     = name,
                    Location = new Point(coordinateX, coordinateY),
                    Tag      = package
                };
            }

            /// <summary></summary>
            /// <param name="checkBoxTemplate">The check box template.</param>
            /// <param name="listOfCheckBoxNames">The list of CheckBox names.</param>
            /// <returns></returns>
            public static CheckBox[] ACheckBoxCollection(CheckBox checkBoxTemplate, List<string> listOfCheckBoxNames)
            {
                var number         = 0;
                //var checkBoxName = string.Empty;
                var coordinateX    = checkBoxTemplate.Location.X;
                var coordinateY    = checkBoxTemplate.Location.Y;
                var checkBoxArray  = new CheckBox[listOfCheckBoxNames.Count];

                foreach (var checkBox in listOfCheckBoxNames)
                {
                    var checkBoxName      = checkBoxTemplate.Name + DuString.Remove.Content(checkBox, "spaces");
                    checkBoxArray[number] = ACheckBox(checkBoxName, coordinateX, coordinateY, null);
                    var checkBoxManifest  = (Dictionary<string, string>) checkBoxTemplate.Tag;

                    switch (checkBoxManifest["buildDirection"])
                    {
                        case "vertical":
                            coordinateY += Convert.ToInt32(checkBoxManifest["IncrementY"]);
                            break;
                        case "horizontal":
                            coordinateX += Convert.ToInt32(checkBoxManifest["IncrementX"]);
                            break;
                    }
                    number++;
                }

                return checkBoxArray;
            }





            /// <summary></summary>
            /// <param name="flowControlPanelName">Name of the flow control panel.</param>
            /// <param name="height">The height.</param>
            /// <param name="width">The width.</param>
            /// <param name="xCoordinate">The x coordinate.</param>
            /// <param name="coordinateY">The y coordinate.</param>
            /// <param name="borderStyle">The border style.</param>
            /// <param name="manifest">The manifest.</param>
            /// <returns></returns>
            public static FlowLayoutPanel AFlowLayoutPanel(string flowControlPanelName, int height, int width, int coordinateX, int coordinateY, BorderStyle borderStyle, DuControl package)
            {
                return new FlowLayoutPanel
                {
                    Name        = flowControlPanelName,
                    Height      = height,
                    Width       = width,
                    Location    = new Point(coordinateX, coordinateY),
                    BorderStyle = borderStyle,
                    Tag         = package
                };
            }

            /// <summary></summary>
            /// <returns></returns>
            public static FlowLayoutPanel[] AFlowLayoutPanelCollection()
            {
                return new FlowLayoutPanel[0];
            }

            /// <summary></summary>
            /// <param name="name">The name.</param>
            /// <param name="height">The height.</param>
            /// <param name="width">The width.</param>
            /// <param name="coordinateX">The x coordinate.</param>
            /// <param name="coordinateY">The y coordinate.</param>
            /// <param name="borderStyle">The border style.</param>
            /// <param name="manifest">The manifest.</param>
            /// <returns></returns>
            public static Panel APanel(string name, int height, int width, int coordinateX, int coordinateY, BorderStyle borderStyle, DuControl package)
            {
                return new Panel
                {
                    Name        = name,
                    Height      = height,
                    Width       = width,
                    Location    = new Point(coordinateX, coordinateY),
                    BorderStyle = borderStyle,
                    Tag         = package
                };
            }

            /// <summary></summary>
            /// <returns></returns>
            public static Panel[] APanelCollection()
            {
                return new Panel[0];
            }

            /// <summary></summary>
            /// <param name="name">The name.</param>
            /// <param name="height">The height.</param>
            /// <param name="width">The width.</param>
            /// <param name="coordinateX">The x coordinate.</param>
            /// <param name="coordinateY">The y coordinate.</param>
            /// <param name="borderStyle">The border style.</param>
            /// <param name="manifest">The manifest.</param>
            /// <returns></returns>
            public static TextBox ATextBox(string name, int height, int width, int coordinateX, int coordinateY, BorderStyle borderStyle, DuControl package)
            {
                return new TextBox
                {
                    Name        = name,
                    Height      = height,
                    Width       = width,
                    Location    = new Point(coordinateX, coordinateY),
                    BorderStyle = borderStyle,
                    Tag         = package
                };
            }

            /// <summary></summary>
            /// <returns></returns>
            public static TextBox[] ATextBoxCollection()
            {
                return new TextBox[0];
            }
        }

        public class Define
        {
            /// <summary></summary>
            /// <param name="containerWidth">Width of the container.</param>
            /// <param name="containerHeight">Height of the container.</param>
            /// <param name="collectionWidth">Width of the collection.</param>
            /// <param name="collectionHeight">Height of the collection.</param>
            /// <param name="collectionRows">The collection rows.</param>
            /// <param name="collectionColumns">The collection columns.</param>
            /// <returns></returns>
            public static Dictionary<string, int> CollectionVectors(int containerWidth, int containerHeight, int collectionWidth, int collectionHeight, int collectionRows, int collectionColumns)
            {
                var possibleRows = containerWidth / collectionWidth;
                if (possibleRows < collectionRows)
                    collectionRows = possibleRows;

                var possibleColumns = containerHeight / collectionHeight;
                if (possibleColumns < collectionColumns)
                    collectionColumns = possibleColumns;

                return new Dictionary<string, int>
                {
                    {"rows", collectionRows},
                    {"columns", collectionColumns}
                };
            }

            /// <summary></summary>
            /// <param name="form">The form.</param>
            /// <param name="controlWidth">Width of the control.</param>
            /// <param name="controlHeight">Height of the control.</param>
            /// <param name="rows">The rows.</param>
            /// <param name="columns">The columns.</param>
            /// <param name="horizontalPadding">The horizontal padding.</param>
            /// <param name="verticalPadding">The vertical padding.</param>
            /// <returns></returns>
            public static Dictionary<string, int> CollectionPaddings(Form form, int controlWidth, int controlHeight, int rows, int columns, int horizontalPadding, int verticalPadding)
            {
                var availableHorizontalPadding = form.Width % controlWidth / rows;
                if (availableHorizontalPadding < horizontalPadding || availableHorizontalPadding < 1)
                {
                    rows--;
                    horizontalPadding = form.Width % controlWidth / rows; // check again
                }

                var availableVerticalPadding = form.Height % controlHeight / columns;
                if (availableVerticalPadding < verticalPadding || availableVerticalPadding < 1)
                {
                    columns--;
                    verticalPadding = form.Height % controlHeight / columns; // check again
                }

                if (availableVerticalPadding < verticalPadding || availableVerticalPadding < 1)
                {
                    columns--;
                    verticalPadding = form.Height % controlHeight / columns; // check again
                }

                return new Dictionary<string, int>
                {
                    {"rows", rows},
                    {"columns", columns},
                    {"horizontalPadding", horizontalPadding},
                    {"verticalPadding", verticalPadding}
                };
            }
        }

        public class Destroy
        {
            // [TODO]
        }

        public class Dimensions
        {
            /// <summary></summary>
            public static void Get()
            {
            }

            /// <summary></summary>
            public static void GetHeight()
            {
            }

            /// <summary></summary>
            public static void GetWidth()
            {
            }

            /// <summary>Sets the dimensions of a control.</summary>
            /// <param name="formName">The form.</param>
            /// <param name="controlName">The control.</param>
            /// <param name="startingLocation">The location.</param>
            /// <param name="verticalPadding">The x pad.</param>
            /// <param name="horizontalPadding">The y pad.</param>
            public static void Set(Form formName, Control controlName, string startingLocation, int verticalPadding, int horizontalPadding)
            {
                var formWidth = formName.ClientRectangle.Width;
                var formHeight = formName.ClientRectangle.Height;
                var newWidth = 0;
                var newHeight = 0;

                switch (startingLocation)
                {
                    case "topLeft":
                        newWidth  = formWidth - verticalPadding * 2;
                        newHeight = formHeight - horizontalPadding * 2;
                        break;

                    case "topMiddle": // [TODO]
                        newWidth = newHeight = 0;
                        break;

                    case "topRight": // [TODO]
                        newWidth = newHeight = 0;
                        break;

                    case "left": // [TODO]
                        newWidth = newHeight = 0;
                        break;

                    case "center": // [TODO]
                        newWidth = newHeight = 0;
                        break;

                    case "right": // [TODO]
                        newWidth = newHeight = 0;
                        break;

                    case "bottomLeft": // [TODO]
                        newWidth = newHeight = 0;
                        break;

                    case "bottomMiddle": // [TODO]
                        newWidth = newHeight = 0;
                        break;

                    case "bottomRight": // [TODO]
                        newWidth = newHeight = 0;
                        break;

                    default: // [TODO]
                        newWidth = newHeight = 0;
                        break;
                }

                controlName.Size = new Size(newWidth, newHeight);
            }

            /// <summary></summary>
            public static void SetHeight()
            {
            }

            /// <summary></summary>
            public static void SetWidth()
            {
            }
        }

        public class Package
        {
            public static DuControl Build(int incrementX, int incrementY, bool ignoreIncrements, bool ignoreIncrementX,
                bool ignoreIncrementY, int paddingX, int paddingY, bool ignorePadding, bool ignorePaddingX, bool ignorePaddingY,
                bool ignoreSize, bool ignoreWidth, bool ignoreHeight, bool ignoreCoordinates, bool ignoreCoordinateX,
                bool ignoreCoordinateY, bool ignoreVectors, bool ignoreRow, bool ignoreColumn)
            {
                return new DuControl
                {
                    IncrementX        = incrementX,
                    IncrementY        = incrementY,
                    IgnoreIncrements  = ignoreIncrements,
                    IgnoreIncrementX  = ignoreIncrementX,
                    IgnoreIncrementY  = ignoreIncrementY,
                    PaddingX          = paddingX,
                    PaddingY          = paddingY,
                    IgnorePadding     = ignorePadding,
                    IgnorePaddingX    = ignorePaddingX,
                    IgnorePaddingY    = ignorePaddingY,
                    IgnoreSize        = ignoreSize,
                    IgnoreWidth       = ignoreWidth,
                    IgnoreHeight      = ignoreHeight,
                    IgnoreCoordinates = ignoreCoordinates,
                    IgnoreCoordinateX = ignoreCoordinateX,
                    IgnoreCoordinateY = ignoreCoordinateY,
                    IgnoreVectors     = ignoreVectors,
                    IgnoreRow         = ignoreRow,
                    IgnoreColumn      = ignoreColumn
                };
            }
        }



        public class Paint
        {
            /// <summary></summary>
            public static void Text()
            {
            }
        }

        public class Coordinates
        {
            /// <summary></summary>
            public static void Get()
            {
            }

            /// <summary></summary>
            public static void GetX()
            {
            }

            /// <summary></summary>
            public static void GetY()
            {
            }

            /// <summary>Sets the location of a location in a form.</summary>
            /// <param name="formName">The form.</param>
            /// <param name="controlName">The control.</param>
            /// <param name="startingLocation">The location.</param>
            public static void Set(Form formName, Control controlName, string startingLocation)
            {
                var formWidth            = formName.ClientRectangle.Width;
                var formHeight           = formName.ClientRectangle.Height;
                var controlWidth         = controlName.Width;
                var controlHeight        = controlName.Height;
                var originalXCoordinate  = 0;
                var origintalYCoordinate = 0;

                switch (startingLocation)
                {
                    case "topLeft": // [TODO]
                        originalXCoordinate = origintalYCoordinate = 0;
                        break;

                    case "topMiddle": // [TODO]
                        originalXCoordinate = origintalYCoordinate = 0;
                        break;

                    case "topRight": // [TODO]
                        originalXCoordinate = origintalYCoordinate = 0;
                        break;

                    case "left": // [TODO]
                        originalXCoordinate = origintalYCoordinate = 0;
                        break;

                    case "center":
                        originalXCoordinate = (formWidth - controlWidth) / 2;
                        origintalYCoordinate = (formHeight - controlHeight) / 2;
                        break;

                    case "right": // [TODO]
                        originalXCoordinate = origintalYCoordinate = 0;
                        break;

                    case "bottomLeft": // [TODO]
                        originalXCoordinate = origintalYCoordinate = 0;
                        break;

                    case "bottomMiddle": // [TODO]
                        originalXCoordinate = origintalYCoordinate = 0;
                        break;

                    case "bottomRight": // [TODO]
                        originalXCoordinate = origintalYCoordinate = 0;
                        break;

                    default: // [TODO]
                        originalXCoordinate = origintalYCoordinate = 0;
                        break;
                }

                controlName.Location = new Point(originalXCoordinate, origintalYCoordinate);
            }

            /// <summary></summary>
            public static void SetX()
            {
            }

            /// <summary></summary>
            public static void SetY()
            {
            }

            /// <summary></summary>
            public static void Swap()
            {
            }
        }



        public class Typeface
        {
            /// <summary></summary>
            public static void SetFont()
            {
            }

            /// <summary>Sets the size of a control font</summary>
            /// <param name="controlName">Name of the control.</param>
            /// <param name="fontSize">Size of the font.</param>
            public static void SetSize(Control controlName, int fontSize)
            {
                controlName.Font = new Font(controlName.Font.FontFamily, fontSize);
            }
        }
        #endregion
    }
}


    //  PROJECT: Du
// FILENAME: DuForm.cs
//    BUILD: 170221
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//

using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Du
{
    public partial class DuForm : Form
    {
        #region ClassFields
        // Class fields go here.
        #endregion

        #region PublicMethods
        public DuForm()
        {
            InitializeComponent();
        }


        public class Destroy
        {


        }

        public class Dimension
        {
            public static int Height(Form form)
            {
                return form.Height;
            }

            public static int Width(Form form)
            {
                return form.Width;
            }

        }



        public class Paint
        {
            public static void Background(Form formToPaint, Color color)
            {
                formToPaint.BackColor = color;
            }

            public static void Foreground(Form formToPaint, Color color)
            {
                formToPaint.ForeColor = color;
            }

            /// <summary></summary>
            public static void Swap()
            {
            }

            /// <summary></summary>
            public static void Text()
            {
            }

            /// <summary></summary>
            public static void Toggle()
            {
            }

        }

        public class State
        {
            public static void DisposeFormShowForm(Form disposeThis, Form showThis)
            {
                disposeThis.Dispose();
                showThis.Show();
            }

            public static void Get()
            {

            }

            public static void HideFormShowDialog(Form hideThis, Form showThis)
            {
                hideThis.Hide();
                showThis.ShowDialog();
            }

            public static void HideFormShowForm(Form hideThis, Form showThis)
            {
                hideThis.Hide();
                showThis.Show();
            }


            public static void Set()
            {

            }

            public static void Swap()
            {

            }

            public static void Toggle()
            {

            }
        }
        #endregion
    }
}






    ##### Du1

    // PROJECT: Du
// FILENAME: DuLabel.cs
// VERSION: 00.0127
// BUILD: 20170127
//
// Copyright 2017 A Pretty Cool Program
//
// Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Du
{
    public class DuLabel
    {
        public string Name { get; set; }
        public string Text { get; set; }
        public bool IgnoreWidth { get; set; }
        public bool IgnoreHeight { get; set; }
        public Size Size { get; set; }
        public bool IgnoreXPos { get; set; }
        public bool IgnoreYPos { get; set; }
        public Point Location { get; set; }
        public bool IgnoreRows { get; set; }
        public bool IgnoreColumns { get; set; }
        public Dictionary<string, int> Vectors { get; set; }
        public bool IgnorePadHorizontal { get; set; }
        public bool IgnorePadVertical { get; set; }
        public Dictionary<string, int> Padding { get; set; }

        /// <summary>Initializes a new Label Package</summary>
        /// <returns>A new, blank Label package.</returns>
        public static DuLabel InitializePackage()
        {
            return new DuLabel
            {
                Name = string.Empty,
                Text = string.Empty,
                IgnoreWidth = false,
                IgnoreHeight = false,
                Size = Size.Empty,
                IgnoreXPos = false,
                IgnoreYPos = false,
                Location = Point.Empty,
                IgnoreRows = false,
                IgnoreColumns = false,
                Vectors = new Dictionary<string, int>(),
                IgnorePadHorizontal = false,
                IgnorePadVertical = false,
                Padding = new Dictionary<string, int>()
            };
        }

        /// <summary>Builds a new Label Package.</summary>
        /// <param name="prefix"></param>
        /// <param name="name"></param>
        /// <param name="postfix"></param>
        /// <param name="text"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <param name="rows"></param>
        /// <param name="columns"></param>
        /// <param name="startXLoc"></param>
        /// <param name="startYLoc"></param>
        /// <param name="padHorizontal"></param>
        /// <param name="padVertical"></param>
        /// <returns>A completed Label Package.</returns>
        public static DuLabel BuildPackage(string prefix, string name, string postfix,
            string text, int? width, int? height, int? rows, int? columns, int? startXLoc, int? startYLoc,
            int? padHorizontal, int? padVertical)
        {
            // Initialize a new package so we have a blank slate.
            var package = InitializePackage();
            // Name
            package.Name = prefix + name + postfix;
            // Size
            package.IgnoreWidth  = width  == null;
            package.IgnoreHeight = height == null;
            package.Size         = new Size
            (
                Convert.ToInt32(width.GetValueOrDefault()),
                Convert.ToInt32(height.GetValueOrDefault())
            );
            // Location
            package.IgnoreXPos = startXLoc == null;
            package.IgnoreYPos = startYLoc == null;
            package.Location   = new Point
            (
                Convert.ToInt32(startXLoc.GetValueOrDefault()),
                Convert.ToInt32(startYLoc.GetValueOrDefault())
            );
            // Vectors
            package.IgnoreRows    = rows    == null;
            package.IgnoreColumns = columns == null;
            package.Vectors       = new Dictionary<string, int>
            {
                {"Rows", rows.GetValueOrDefault()},
                {"Columns", columns.GetValueOrDefault()}
            };
            // Padding
            package.IgnorePadHorizontal = padHorizontal == null;
            package.IgnorePadVertical   = padVertical   == null;
            package.Padding = new Dictionary<string, int>
            {
                {"Horizontal", padHorizontal.GetValueOrDefault()},
                {"Vertical", padVertical.GetValueOrDefault()}
            };

            return package;
        }

        public static DuLabel VerifyPackage(Form form, DuLabel package)
        {
            package = VerifyVectors(form, package);
            package = VerifyPadding(form, package);

            return package;
        }

        public static DuLabel VerifyVectors(Form form, DuLabel package)
        {
            var vectorCheck = DuControl.ModifyPackageVectors(form, package.Size.Width, package.Size.Height,
                package.Vectors["Rows"], package.Vectors["Columns"]);

            if (!package.IgnoreRows)
                if (package.Vectors["Rows"] != vectorCheck["rows"])
                    package.Vectors["Rows"] = vectorCheck["rows"];

            if (!package.IgnoreColumns)
                if (package.Vectors["Columns"] != vectorCheck["columns"])
                    package.Vectors["Columns"] = vectorCheck["columns"];

            return package;
        }

        public static DuLabel FixVectors(Control control, DuLabel package)
        {
            var vectorCheck = DuControl.VerifyPackageVectors(control, package.Size.Width, package.Size.Height,
                package.Vectors["Rows"], package.Vectors["Columns"]);

            if (!package.IgnoreRows)
                if (package.Vectors["Rows"] != vectorCheck["rows"])
                    package.Vectors["Rows"] = vectorCheck["rows"];

            if (!package.IgnoreColumns)
                if (package.Vectors["Columns"] != vectorCheck["columns"])
                    package.Vectors["Columns"] = vectorCheck["columns"];

            return package;
        }

        public static DuLabel VerifyPadding(Form form, DuLabel package)
        {
            var paddingCheck = DuControl.ModifyPackagePadding(form, package.Size.Width, package.Size.Height,
                package.Vectors["Rows"], package.Vectors["Columns"], package.Padding["Horizontal"],
                package.Padding["Vertical"]);

            if (!package.IgnorePadHorizontal)
                if (package.Padding["Horizontal"] != paddingCheck["horizontal"])
                    package.Padding["Horizontal"] = paddingCheck["horizontal"];

            if (!package.IgnorePadVertical)
                if (package.Padding["Vertical"] != paddingCheck["vertical"])
                    package.Padding["Vertical"] = paddingCheck["vertical"];

            if (!package.IgnoreRows && package.Vectors["Rows"] != paddingCheck["rows"])
                package.Vectors["Rows"] = paddingCheck["rows"];

            if (!package.IgnoreColumns && package.Vectors["Columns"] != paddingCheck["columns"])
                package.Vectors["Columns"] = paddingCheck["columns"];

            return package;
        }
    }
}

##### AO ss8-2-16

    // ---------------------------------------------------------------------------------------------------------------------
// Name: DoCheckBox.cs
// Version: 00.90.01.160731
// Author: Christopher Banwarth (development@aprettycoolprogram.com)
// Description: A class for AO that does various things with Checkboxes.
// More: ao.aprettycoolprogram.com OR aprettycoolprogram.github.com
// ---------------------------------------------------------------------------------------------------------------------

using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace AO
{
    public class DoCheckBox
    {
        /// <summary>Does something with checkboxes.</summary>
        /// <param name="contentList"></param>
        /// <param name="startX"></param>
        /// <param name="startY"></param>
        /// <param name="incX"></param>
        /// <param name="incY"></param>
        /// <param name="checkBoxPrefix"></param>
        /// <param name="direction"></param>
        /// <returns></returns>
        public static CheckBox[] BuildArray(List<string> contentList, int startX, int startY, int incX, int incY, string checkBoxPrefix, string direction)
        {
            CheckBox[] checkBoxArray = new CheckBox[contentList.Count];
            var boxNum = 0;
            var LocY = startY;
            var LocX = startX;

            // Build a checkbox for each color
            foreach (var eachItem in contentList)
            {
                checkBoxArray[boxNum] = new CheckBox();
                checkBoxArray[boxNum].Name = checkBoxPrefix + eachItem;
                checkBoxArray[boxNum].Text = eachItem;
                checkBoxArray[boxNum].Location = new Point(LocX, LocY);
                boxNum++;

                if (direction == "vertical")
                {
                    LocY += incY;
                }
                else
                {
                    LocX += incX;
                }
            }

            return checkBoxArray;
        }
    }
}

// CHANGELOG
// =========
// 00.90.01.160731: Initial release

// ROADMAP
// =======
// * Proper error handling

// NOTES
// =====





     */


