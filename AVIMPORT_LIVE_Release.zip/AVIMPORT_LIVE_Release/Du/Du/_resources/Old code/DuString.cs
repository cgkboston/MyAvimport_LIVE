//  PROJECT: Du
// FILENAME: DuString.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Du
{
    /*  This class does various things with strings.
     */
    public class DuString
    {
        public class Add
        {
            /// <summary>Add content to the beginning of a string</summary>
            /// <param name="stringToAddTo">The string to add to.</param>
            /// <param name="contentToAdd">The content to add.</param>
            /// <returns>A new string with the content at the beginning.</returns>
            public static string ToBeginning(string stringToAddTo, string contentToAdd)
            {
                return contentToAdd + stringToAddTo;
            }

            /// <summary>Add content to the end of a string</summary>
            /// <param name="stringToAddTo">The string to add to.</param>
            /// <param name="contentToAdd">The content to add.</param>
            /// <returns>A new string with the content at the end.</returns>
            public static string ToEnd(string stringToAddTo, string contentToAdd)
            {
                return stringToAddTo + contentToAdd;
            }

            /// <summary>Add content to  a string</summary>
            /// <param name="stringToAddTo">The string to add to.</param>
            /// <param name="contentToAdd">The content to add.</param>
            /// <returns>A new string with the added content</returns>
            public static StringBuilder Content(string stringToAddTo, string contentToAdd)
            {
                /*  This should only be used when large amounts of content need to be added.
                 *  Also, this is not tested.
                 */
                var wrkString = new StringBuilder();
                return wrkString.Append(contentToAdd);
            }
        }

        public class Remove
        {
            /// <summary>Removes content from a string.</summary>
            /// <param name="stringToRemoveFrom">The string to remove from.</param>
            /// <param name="contentToRemove">The content to remove.</param>
            /// <returns>The string with the content removed.</returns>
            public static string Content(string stringToRemoveFrom, string contentToRemove)
            {
                var wrkString = string.Empty;
                var currentLine = string.Empty;

                using (var stringToRead = new StringReader(stringToRemoveFrom))
                {
                    while (stringToRead.ReadLine() != null && stringToRead.ReadLine() != contentToRemove)
                        wrkString += currentLine;
                }

                return wrkString;
            }



            /// <summary>Removes a specified number of charactacters from the end of a string.</summary>
            /// <param name="stringToRemoveFrom">The string to remove from.</param>
            /// <param name="contentToRemove">The content to remove.</param>
            /// <returns>The string with the characters removed from the beginning.</returns>
            public static string FromBeginning(string stringToRemoveFrom, int numberOfCharactersToRemove)
            {
                return stringToRemoveFrom.Substring(numberOfCharactersToRemove);
            }

            /// <summary>Removes specified content from the end of a string.</summary>
            /// <param name="stringToRemoveFrom">The string to remove from.</param>
            /// <param name="contentToRemove">The content to remove.</param>
            /// <returns>The string with the content removed from the end.</returns>
            public static string FromEnd(string stringToRemoveFrom, string contentToRemove)
            {
                // [TODO] Code.
                return string.Empty;
            }

            /// <summary>Removes a specified number of charactacters from the end of a string.</summary>
            /// <param name="stringToRemoveFrom">The string to remove from.</param>
            /// <param name="contentToRemove">The content to remove.</param>
            /// <returns>The string with the characters removed from the end.</returns>
            public static string FromEnd(string stringToRemoveFrom, int numberOfCharactersToRemove)
            {
                // [TODO] Code.
                return string.Empty;
            }


			
            /// <summary>Removes newline characters from a string.</summary>
            /// <param name="stringToRemoveFrom">The string to remove from.</param>
            /// <returns>The string without newline characters.</returns>
            public static string NewLines(string stringToRemoveFrom)
            {
                return stringToRemoveFrom.Replace(Environment.NewLine, "");
            }



            /// <summary>Removes spaces characters from a string.</summary>
            /// <param name="stringToRemoveFrom">The string to remove from.</param>
            /// <returns>The string without spaces.</returns>
            public static string Spaces(string stringToRemoveFrom)
            {
                return stringToRemoveFrom.Replace(" ", "");
            }
        }

        public class Split
        {
            /// <summary>Its the specified string to split.</summary>
            /// <param name="stringToSplit">The string to split.</param>
            /// <param name="delimiter">The delimiter.</param>
            /// <returns></returns>
            public static string[] ToKeyValuePair(string stringToSplit, char delimiter)
            {
                return stringToSplit.Split(delimiter); // Combine w/Transmorgify to Array?
            }
        }

        public class Transmorgify
        {


            public static void ToDictionary(string stringToConvert, char delimiter)
            {
            }



            /// <summary></summary>
            /// <param name="fileName">Name of the file.</param>
            /// <param name="stringToWrite">The string to write.</param>
            public static void ToJaggedArray(string fileName, string stringToWrite)
            {
                // [TODO]
            }


        }
    }
}

/* DEVELOPMENT

######
Du_
######

    //  PROJECT: Du
// FILENAME: DuString.cs
//    BUILD: 170217
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Du
{
    public class DuString
    {
        public class Add
        {
            // [TODO]
        }

        public class Check
        {
            /// <summary>Checks to see if a string starts with a comment character.</summary>
            /// <param name="fileName">Name of the file.</param>
            /// <param name="commentCharacter"></param>
            /// <returns>True/false.</returns>
            public static bool Comment(string stringToCheck, char commentCharacter)
            {
                // [TODO] This should handle mulitple character comments (i.e. "//"")
                return (stringToCheck.StartsWith(commentCharacter.ToString()))
                    ? true
                    : false;
            }

            /// <summary>BASIC - Check to see if a string is empty.</summary>
            /// <returns>True/false.</returns>
            public static bool Empty(string stringToCheck) => stringToCheck == string.Empty;

/// <summary>ADVANCED - Check to see if a string is empty.</summary>
/// <returns>True/false.</returns>
public static bool Empty(string stringToCheck, string typeOfCheck)
{
    switch (typeOfCheck)
    {
        case "anyQuotes":
            return (stringToCheck == "" || stringToCheck == " ")
                ? true
                : false;

        case "emptyQuotes":
            return (stringToCheck == "")
                 ? true
                 : false;

        case "length":
            return (stringToCheck.Length == 0)
                ? true
                : false;

        case "spacedQuotes":
            return (stringToCheck == " ")
                ? true
                : false;

        case "all":
            return (stringToCheck == "" || stringToCheck == " " || Empty(stringToCheck));

        default:
            // [TODO] Make this an exception check
            return false;
    }
}

/// <summary>Check to see if a string is null.</summary>
/// <returns>True/false.</returns>
public static bool Null(string stringToCheck) => stringToCheck == null;
        }

        public class Clean
{
    // [TODO]
}



public class Count
{
    /// <summary></summary>
    /// <param name="stringToCount">The string to count.</param>
    /// <param name="character">The character.</param>
    /// <returns></returns>
    public static int Character(string stringToCount, char character)
    {
        // [TODO]
        return 0;
    }

    /// <summary></summary>
    /// <param name="stringToCount">The string to count.</param>
    /// <returns></returns>
    public static int Characters(string stringToCount) => stringToCount.Length;

    /// <summary></summary>
    /// <param name="stringToCount">The string to count.</param>
    /// <returns></returns>
    public static int Lines(string stringToCount) => stringToCount.Split('\n').Length;

}

public class Create
{
    // [TODO]
}

public class Destroy
{
    // [TODO]
}

public class Index
{
    public static int Get(string fileName)
    {
        // [TODO]
        return 0;
    }

    public static int GetRandom(string fileName)
    {
        // [TODO]
        return 0;
    }

    public static int GetLocationOf(string fileName)
    {
        // [TODO]
        return 0;
    }

}

public class Join
{
    // [TODO]
}

public class Remove
{

    public static string AfterCharacter(string stringToModify, char startAt)
    {
        return stringToModify.Trim(startAt);
    }

    public static string FileExtensionDot(string fileName)
    {
        return fileName.Trim('.');
    }


    public static string PriorToCharacter(string stringToModify, char startAt)
    {
        return stringToModify.Trim(startAt);
    }


}

public class Change
{
    public static int Content(string fileName)
    {
        // [TODO]
        return 0;
    }
}
    }
}







*/
