//  PROJECT: Du
// FILENAME: DuFile.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance
// with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//

using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Du
{
    /*  This class does various things with external files.
     */

    public class DuFile
    {
        public class Check
        {
            /// <summary>Check to see if a file exists.</summary>
            /// <param name="filePath">The path of the file ("c:\directory\filename.txt").</param>
            /// <returns>True/false.</returns>
            public static bool Exists(string filePath)
            {
                return File.Exists(filePath);
            }
        }

        public class Destroy
        {
            public static void Delete(string filePath)
            {
                if (File.Exists(filePath))
                    File.Delete(filePath);
            }
        }

        public class Extension
        {
            /// <summary> Gets the next ext number.</summary>
            /// <param name="directoryPath">The path.</param>
            /// <param name="fileNamePattern">The file pattern (i.e. "note", "file").</param>
            /// <param name="startAt">The start at number [0].</param>
            /// <returns>The next extension number.</returns>
            /*
             *  This method is used in a very specific situation, when you have a set of files that all have the same
             *  name, but different number extensions, and you want to find the next number.For instance, if you have
             *  the following files in a directory...
             *
             *      "file.001", "file.002", "file.003"
             *
             *  ...this method will determine the next file should be "file.004".
             */
            public static int GetNextNumber(string directoryPath, string fileNamePattern, int startAt)
            {
                var nextNum = startAt;
                // Initializers
                var fileName = string.Empty;
                var fileExtension = string.Empty;
                var fileExtensionNumber = 0;

                foreach (var item in Directory.GetFiles(directoryPath))
                {
                    fileName = Path.GetFileNameWithoutExtension(item);
                    fileExtension = Path.GetExtension(item);

                    if (fileName == fileNamePattern)
                    {
                        fileExtension = DuString.Remove.FileExtensionDot(fileExtension);
                        if (int.Parse(fileExtension) > nextNum)
                            nextNum = int.Parse(fileExtension);
                    }
                }

                return nextNum++;
            }
        }

        public class ReadInto
        {
            private static List<string> ReadIntoList(StreamReader filePath)
            {
                var fileAsList = new List<string>();
                var fileLine = string.Empty;

                while ((fileLine = filePath.ReadLine()) != null)
                    fileAsList.Add(fileLine);

                return fileAsList;
            }

            /// <summary>
            /// Reads the into string.
            /// </summary>
            /// <param name="filePath"> The file path.</param>
            /// <param name="cleaningRules"> The cleaning rules.</param>
            /// <returns></returns>
            /// <remarks>
            /// [*] As long as the file is passed as a StreamReader type, it doesn't  matter if the file is embedded,
            /// external, or whatever. It's important to note that this function simply returns the contents of a file
            /// as a list, without parsing or cleaning the contents.
            /// [1] Loop through the passed file.With each pass, check the following:
            ///         - Are we checking for empty lines, and is the line empty?
            ///         - Are we checking for null lines, and is the line null?
            ///         - Are we checking for comments, and does the line start with the comment line?
            ///     As long as all three of those statements are false, add to line to the wrkString.If any of them are
            ///     false, then don't add the line to the wrkString.
            /// </remarks>
            private static string ReadIntoString(StreamReader filePath, Dictionary<string, string> cleaningRules)
            {
                var fileAsString = string.Empty;
                var fileLine = string.Empty;
                var emptyPassed = false;
                var nullPassed = false;
                var commentPassed = false;

                while ((fileLine = filePath.ReadLine()) != null)
                {
                    emptyPassed = cleaningRules["empties"] == "true" && AOString.CheckEmpty(fileLine, null) ? false : true;
                    nullPassed = cleaningRules["nulls"] == "true" && AOString.CheckNull(fileLine) ? false : true;
                    commentPassed = cleaningRules["commentChar"] != " " && AOString.CheckComment(fileLine, Convert.ToChar(cleaningRules["commentChar"])) ? false : true;

                    if (emptyPassed && nullPassed && commentPassed)
                        fileAsString = fileAsString + fileLine + " ";
                }

                return fileAsString;
            }
        }

        public class Retrieve
        {
            /// <summary>Gets a random line from a file.</summary>
            /// <param name="filePath">The file path.</param>
            /// <returns>A random line.</returns>
            public static string RandomLine(string filePath, bool pause)
            {
                var fileAsList = Transmorgify.ToStringList(filePath);
                var randomLocation = DuMath.Create.RandomNumber(0, fileAsList.Count, pause);

                return fileAsList[randomLocation];
            }
        }

        public class Tally
        {
            public static long Lines(string fileName, string assemblyName)
            {
                return ToList(fileName, assemblyName).Count;
            }

            public static long Characters(string fileName, string assemblyName)
            {
                return 0
                    ;
            }
        }

        public class Transmorgify
        {
            public static string[] ToArray(string filePath, string assemblyName)
            {
                return
                    assemblyName == null ? ToList(filePath, null).ToArray() : ToList(filePath, assemblyName).ToArray();
            }

            public static List<Dictionary<string, string>> ToDictionaries(List<string> fileNames, string assemblyName, char delimeter)
            {
                var wrkList = new List<Dictionary<string, string>>();

                foreach (var fileName in fileNames)
                    wrkList.Add(ToDictionary(fileName, assemblyName, delimeter));

                return wrkList;
            }

            public static List<string> ToList(string filePath, string assembly)
            {
                var fileAsList = new List<string>();

                if (assembly == null) // [1]
                    using (var fileToRead = new StreamReader(filePath))
                    {
                        fileAsList = ReadIntoList(fileToRead);
                    }
                else
                    using (var fileToRead = new StreamReader(Assembly.Load(assembly).GetManifestResourceStream(assembly + "." + filePath)))
                    {
                        fileAsList = ReadIntoList(fileToRead);
                    }

                return fileAsList;
            }

            public static string ToString(string filePath, string assembly, Dictionary<string, string> cleaningRules)
            {
                var fileAsString = string.Empty;

                if (assembly == null) // [1]
                    using (var fileToRead = new StreamReader(filePath))
                    {
                        fileAsString = ReadIntoString(fileToRead, cleaningRules);
                    }
                else
                    using (var fileToRead = new StreamReader(Assembly.Load(assembly).GetManifestResourceStream(assembly + "." + filePath)))
                    {
                        fileAsString = ReadIntoString(fileToRead, cleaningRules);
                    }

                return fileAsString;
            }

            /// <summary>Converts a file into a string dictionary.</summary>
            /// <param name="fileName">Name of the file.</param>
            /// <param name="delimiter">The delimiter.</param>
            /// <returns></returns>
            public static Dictionary<string, string> ToStringDictionary(string filePath, char delimiter)
            {
                var currentLine = string.Empty;
                var currentKeyValuePair = new string[2];
                var wrkDictionary = new Dictionary<string, string>();

                using (var fileToRead = new StreamReader(filePath))
                {
                    while ((currentLine = fileToRead.ReadLine()) != null)
                    {
                        currentKeyValuePair = DuString.Split.ToKeyValuePair(currentLine, '=');
                        wrkDictionary.Add(currentKeyValuePair[0], currentKeyValuePair[1]);
                    }

                    fileToRead.Close();
                }

                return wrkDictionary;
            }


        }
    }
}

/* DEVELOPMENT
 *
 * This is older code that should be reviewed.

        /// <summary>Counts the lines in a file.</summary>
        /// <param name="file">Name of the file.</param>
        /// <param name="asmb">Name of the assembly.</param>
        /// <returns>The number of lines in the file.</returns>
        /// <remarks>
        /// [V] Make sure thigs works.
        /// </remarks>
        public static long AOFileCntLn(string fName, string asmb)
        {
            return AOFileToList(file, asmb).Count;
        }

        /// <summary>Counts the characters.</summary>
        /// <param name="fNm">Name of the file.</param>
        /// <param name="asmb">Name of the assembly.</param>
        /// <returns>The number of characters in a file.</returns>
        /// <remarks>
        /// [T] Coming soon!
        /// </remarks>
        public static long AOFileCntChar(string fNm, string asmb)
        {
            return 0;
        }

        /// <summary>Convert a file to an array.</summary>
        /// <param name="fPth">The file path.</param>
        /// <param name="asmb">Name of the assembly.</param>
        /// <returns></returns>
        /// <remarks>
        /// None.
        /// </remarks>
        public static string[] AOFileToArr(string fPth, string asmb)
        {
            return asmb == null ? AOFileToList(fPth, null).ToArray() : AOFileToList(fPth, asmb).ToArray();
        }

        /// <summary>Convert a file to a dictionary.</summary>
        /// <param name="fPth">The file path.</param>
        /// <param name="asmb">Name of the assembly.</param>
        /// <param name="dlim">The delimiter.</param>
        /// <returns></returns>
        /// <remarks>
        /// I'm not sure how this works, exactly!
        /// </remarks>
        public static Dictionary<string, string> AOFileToDic(string fPth, string asmb, char dlim)
        {
            return AOFileToArray(fPth, asmb).Select(l => l.Split(dlim)).ToDictionary(a => a[0], a => a[1]);
        }

        /// <summary>To the dictionaries.</summary>
        /// <param name="fNms">The file names.</param>
        /// <param name="asmb">Name of the assembly.</param>
        /// <param name="dlim">The delimeter.</param>
        /// <returns></returns>
        /// <remarks>
        /// None.
        /// </remarks>
        public static List<Dictionary<string, string>> AOFileToDics(List<string> fNms, string asmb, char dlim)
        {
            var wLst = new List<Dictionary<string, string>>();

            foreach (var fNm in fNms)
                wLst.Add(AOFileToDic(fNm, asmb, dlim));

            return wLst;
        }

        /// <summary>To the list.</summary>
        /// <param name="fPth">The file path.</param>
        /// <param name="asmb">The assembly.</param>
        /// <returns></returns>
        /// <remarks>
        /// [1] If the passed assembly name is "null", then the file is external. If an assembly name was passed, the
        ///     file is embedded.Either way, read the file into a list.
        /// </remarks>
        public static List<string> AOFileToList(string fPth, string asmb)
        {
            var fileAsList = new List<string>();

            if (asmb == null) // [1]
                using (var fileToRead = new StreamReader(fPth))
                {
                    fileAsList = AOReadIntoList(fileToRead);
                }
            else
                using (var fileToRead = new StreamReader(Assembly.Load(asmb).GetManifestResourceStream(asmb + "." + fPth)))
                {
                    fileAsList = ReadIntoList(fileToRead);
                }

            return fileAsList;
        }



        /* Convert a file into a string.
         * ---
         * filePath      - the full path of the file. If this is just the file name, we'll look in the local directory.
         * assemeblyName - optional assembly name, or "null" to indicate the file is external.                        */
/*
/// <summary>
/// Returns a <see cref="System.String" /> that represents this instance.
/// </summary>
/// <param name="filePath">The file path.</param>
/// <param name="assembly">The assembly.</param>
/// <param name="cleaningRules">The cleaning rules.</param>
/// <returns>
/// A <see cref="System.String" /> that represents this instance.
/// </returns>
/// <remarks>
/// [1] If the passed assembly name is "null", then the file is external. If an assembly name was passed, the
///     file is embedded.Either way, read the file into a list.
/// </remarks>
public static string ToString(string filePath, string assembly, Dictionary<string, string> cleaningRules)
{
    var fileAsString = string.Empty;

    if (assembly == null)                                                                                       // [1]
    {
        using (StreamReader fileToRead = new StreamReader(filePath))
        {
            fileAsString = ReadIntoString(fileToRead, cleaningRules);
        }
    }
    else
    {
        using (StreamReader fileToRead = new StreamReader(Assembly.Load(assembly).GetManifestResourceStream((string)assembly + "." + filePath)))
        {
            fileAsString = ReadIntoString(fileToRead, cleaningRules);
        }
    }

    return fileAsString;
}

        /// <summary>
        /// Deletes the specified file path.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <remarks>
        /// None.
        /// </remarks>
        /public static void Delete(string filePath)
{
    if (File.Exists(filePath))
    {
        File.Delete(filePath);
    }
}

/* Gets the next number in an extension range.

 *

 * ---
 * directoryName -
 * filePattern   -
 * startAt       -
 */
 /*
/// <summary>
/// Gets the next ext number.
/// </summary>
/// <param name="directoryName">Name of the directory.</param>
/// <param name="filePattern">The file pattern.</param>
/// <param name="startAt">The start at.</param>
/// <returns></returns>
/// <remarks>
/// [*] This method is used in a very specific situation, when file have numeric extensions, and you want to
///     find the next number to use.For instance, if you have the following files in a directory...
///
///         "file.001", "file.002", "file.003"
///
///     ...this method will determine the next file should be "file.004".
/// [1] This is needed to work correctly.
/// </remarks>
public static string GetNextExtNum(string directoryName, string filePattern, int startAt)
{
    var nextNum = startAt;

    foreach (var fName in Directory.GetFiles(directoryName))
    {
        if (Path.GetFileNameWithoutExtension(fName) == filePattern)
        {
            if (int.Parse(Path.GetFileNameWithoutExtension(fName)) > nextNum)
            {
                nextNum = int.Parse(Path.GetFileNameWithoutExtension(fName));
            }
        }
    }
    nextNum++;                                                                                                  // [1]

    return nextNum.ToString();
}

/// <summary>
/// Reads the into list.
/// </summary>
/// <param name="filePath">The file path.</param>
/// <returns></returns>
/// <remarks>
/// [*] As long as the file is passed as a StreamReader type, it doesn't  matter if the file is embedded,
///     external, or whatever. It's important to note that this function simply returns the contents of a
///     file as a list, without parsing or cleaning the contents.
/// [T] Fix this like ReadIntoString
/// </remarks>
private static List<string> ReadIntoList(StreamReader filePath)
{
    var fileAsList = new List<string>();
    var fileLine = string.Empty;

    while ((fileLine = filePath.ReadLine()) != null)
    {
        fileAsList.Add(fileLine);
    }

    return fileAsList;
}

/// <summary>
/// Reads the into string.
/// </summary>
/// <param name="filePath">The file path.</param>
/// <param name="cleaningRules">The cleaning rules.</param>
/// <returns></returns>
/// <remarks>
/// [*] As long as the file is passed as a StreamReader type, it doesn't  matter if the file is embedded,
/// external, or whatever. It's important to note that this function simply returns the contents of a file
/// as a list, without parsing or cleaning the contents.
/// [1] Loop through the passed file. With each pass, check the following:
///         - Are we checking for empty lines, and is the line empty?
///         - Are we checking for null lines, and is the line null?
///         - Are we checking for comments, and does the line start with the comment line?
///     As long as all three of those statements are false, add to line to the wrkString.If any of them are
///     false, then don't add the line to the wrkString.
/// </remarks>
private static string ReadIntoString(StreamReader filePath, Dictionary<string, string> cleaningRules)
{
    var fileAsString = string.Empty;
    var fileLine = string.Empty;
    var emptyPassed = false;
    var nullPassed = false;
    var commentPassed = false;

    while ((fileLine = filePath.ReadLine()) != null)
    {
        emptyPassed = (cleaningRules["empties"] == "true" && AOString.CheckEmpty(fileLine, null)) ? false : true;
        nullPassed = (cleaningRules["nulls"] == "true" && AOString.CheckNull(fileLine)) ? false : true;
        commentPassed = (cleaningRules["commentChar"] != " " && AOString.CheckComment(fileLine, Convert.ToChar(cleaningRules["commentChar"]))) ? false : true;

        if (emptyPassed && nullPassed && commentPassed)
        {
            fileAsString = fileAsString + fileLine + " ";
        }
    }

    return fileAsString;
}
    }
}

/// <summary>Convert a file to an array.</summary>
/// <param name = "fPth" > The file path.</param>
/// <param name = "asmb" > Name of the assembly.</param>
/// <returns></returns>
/// <remarks>
/// None.
/// </remarks>
//public static string[] AOFileToArr(string fPth, string asmb)
//{
//return (asmb == null) ? AOFileToList(fPth, null).ToArray() : AOFileToList(fPth, asmb).ToArray();
//}

/// <summary>Convert a file to a dictionary.</summary>
/// <param name = "fPth" > The file path.</param>
/// <param name = "asmb" > Name of the assembly.</param>
/// <param name = "dlim" > The delimiter.</param>
/// <returns></returns>
/// <remarks>
/// I'm not sure how this works, exactly!
/// </remarks>
//public static Dictionary<string, string> AOFileToDic(string fPth, string asmb, char dlim)
//{
//return AOFileToArray(fPth, asmb).Select(l => l.Split(dlim)).ToDictionary(a => a[0], a => a[1]);
//}

/// <summary>To the dictionaries.</summary>
/// <param name = "fNms" > The file names.</param>
/// <param name = "asmb" > Name of the assembly.</param>
/// <param name = "dlim" > The delimeter.</param>
/// <returns></returns>
/// <remarks>
/// None.
/// </remarks>
//public static List<Dictionary<string, string>> AOFileToDics(List<string> fNms, string asmb, char dlim)
//{
//var wLst = new List<Dictionary<string, string>>();

//foreach (var fNm in fNms)
//{
//wLst.Add(AOFileToDic(fNm, asmb, dlim));
//}

//return wLst;
//}

/// <summary>To the list.</summary>
/// <param name = "fPth" > The file path.</param>
/// <param name = "asmb" > The assembly.</param>
/// <returns></returns>
/// <remarks>
/// [1] If the passed assembly name is "null", then the file is external.If an assembly name was passed, the
///     file is embedded.Either way, read the file into a list.
/// </remarks>
//public static List<string> AOFileToList(string fPth, string asmb)
//{
//var fileAsList = new List<string>();

//if (asmb == null) // [1]
//{
//using (StreamReader fileToRead = new StreamReader(fPth))
//{
//fileAsList = AOReadIntoList(fileToRead);
//}
//}
//else
//{
//using (StreamReader fileToRead = new StreamReader(Assembly.Load(asmb).GetManifestResourceStream((string)asmb + "." + fPth)))
//{
//fileAsList = ReadIntoList(fileToRead);
//}
//}

//return fileAsList;
//}

//}
//}

///* Convert a file into a string.
// * ---
// * filePath      - the full path of the file. If this is just the file name, we'll look in the local directory.
// * assemeblyName - optional assembly name, or "null" to indicate the file is external.                        */

///// <summary>
///// Returns a <see cref="System.String" /> that represents this instance.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="assembly">The assembly.</param>
///// <param name="cleaningRules">The cleaning rules.</param>
///// <returns>
///// A <see cref="System.String" /> that represents this instance.
///// </returns>
///// <remarks>
///// [1] If the passed assembly name is "null", then the file is external. If an assembly name was passed, the
/////     file is embedded.Either way, read the file into a list.
///// </remarks>
//public static string ToString(string filePath, string assembly, Dictionary<string, string> cleaningRules)
//{
//var fileAsString = string.Empty;

//if (assembly == null) // [1]
//{
//using (StreamReader fileToRead = new StreamReader(filePath))
//{
//fileAsString = ReadIntoString(fileToRead, cleaningRules);
//}
//}
//else
//{
//using (StreamReader fileToRead = new StreamReader(Assembly.Load(assembly).GetManifestResourceStream((string)assembly + "." + filePath)))
//{
//fileAsString = ReadIntoString(fileToRead, cleaningRules);
//}
//}

//return fileAsString;
//}

///// <summary>
///// Deletes the specified file path.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <remarks>
///// None.
///// </remarks>
///public static void Delete(string filePath)
//{
//if (File.Exists(filePath))
//{
//File.Delete(filePath);
//}
//}

///* Gets the next number in an extension range.

// *

// * ---
// * directoryName -
// * filePattern   -
// * startAt       -
// */

///// <summary>
///// Gets the next ext number.
///// </summary>
///// <param name="directoryName">Name of the directory.</param>
///// <param name="filePattern">The file pattern.</param>
///// <param name="startAt">The start at.</param>
///// <returns></returns>
///// <remarks>
///// [*] This method is used in a very specific situation, when file have numeric extensions, and you want to
/////     find the next number to use.For instance, if you have the following files in a directory...
/////
/////         "file.001", "file.002", "file.003"
/////
/////     ...this method will determine the next file should be "file.004".
///// [1] This is needed to work correctly.
///// </remarks>
//public static string GetNextExtNum(string directoryName, string filePattern, int startAt)
//{
//var nextNum = startAt;

//foreach (var fName in Directory.GetFiles(directoryName))
//{
//if (Path.GetFileNameWithoutExtension(fName) == filePattern)
//{
//if (int.Parse(Path.GetFileNameWithoutExtension(fName)) > nextNum)
//{
//nextNum = int.Parse(Path.GetFileNameWithoutExtension(fName));
//}
//}
//}
//nextNum++; // [1]

//return nextNum.ToString();
//}

///// <summary>
///// Reads the into list.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <returns></returns>
///// <remarks>
///// [*] As long as the file is passed as a StreamReader type, it doesn't  matter if the file is embedded,
/////     external, or whatever. It's important to note that this function simply returns the contents of a
/////     file as a list, without parsing or cleaning the contents.
///// [T] Fix this like ReadIntoString
///// </remarks>
//private static List<string> ReadIntoList(StreamReader filePath)
//{
//var fileAsList = new List<string>();
//var fileLine = string.Empty;

//while ((fileLine = filePath.ReadLine()) != null)
//{
//fileAsList.Add(fileLine);
//}

//return fileAsList;
//}

///// <summary>
///// Reads the into string.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="cleaningRules">The cleaning rules.</param>
///// <returns></returns>
///// <remarks>
///// [*] As long as the file is passed as a StreamReader type, it doesn't  matter if the file is embedded,
///// external, or whatever. It's important to note that this function simply returns the contents of a file
///// as a list, without parsing or cleaning the contents.
///// [1] Loop through the passed file. With each pass, check the following:
/////         - Are we checking for empty lines, and is the line empty?
/////         - Are we checking for null lines, and is the line null?
/////         - Are we checking for comments, and does the line start with the comment line?
/////     As long as all three of those statements are false, add to line to the wrkString.If any of them are
/////     false, then don't add the line to the wrkString.
///// </remarks>
//private static string ReadIntoString(StreamReader filePath, Dictionary<string, string> cleaningRules)
//{
//var fileAsString = string.Empty;
//var fileLine = string.Empty;
//var emptyPassed = false;
//var nullPassed = false;
//var commentPassed = false;

//while ((fileLine = filePath.ReadLine()) != null)
//{
//emptyPassed = (cleaningRules["empties"] == "true" && AOString.CheckEmpty(fileLine, null)) ? false : true;
//nullPassed = (cleaningRules["nulls"] == "true" && AOString.CheckNull(fileLine)) ? false : true;
//commentPassed = (cleaningRules["commentChar"] != " " && AOString.CheckComment(fileLine, Convert.ToChar(cleaningRules["commentChar"]))) ? false : true;

//if (emptyPassed && nullPassed && commentPassed)
//{
//fileAsString = fileAsString + fileLine + " ";
//}
//}

//return fileAsString;
//}
//}
//}

//#### AO.cs

///* A class for AO.cs that does various things with files.
// * v00.53.04.161220
// * http://aprettycoolprogram.com/ao
// */

//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Reflection;

//namespace AO
//{
//public class AOFile
//{
///// <summary>
///// Counts the lines in a file.
///// </summary>
///// <param name="fileName">Name of the file.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <returns></returns>
///// <remarks>
///// Verify.
///// </remarks>
//public static long CountLines(string fileName, string assemblyName)
//{
//return ToList(fileName, assemblyName).Count;
//}

///// <summary>
///// Counts the characters.
///// </summary>
///// <param name="fileName">Name of the file.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <returns></returns>
///// <remarks>
///// Verify.
///// </remarks>
//public static long CountCharacters(string fileName, string assemblyName)
//{
//return 0;
//}

///// <summary>
///// Randoms the line.
///// </summary>
///// <param name="lineNumber">The line number.</param>
///// <returns></returns>
///// <remarks>
///// Verify
///// </remarks>
//public static string RandomLine(int lineNumber)
//{
////var test = ToList("Resources.Appdata.Generators.firstnames.gnr", "DUNGEON");
////return "NONE";
//}

///// <summary>
///// Convert a file to an array.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <returns></returns>
///// <remarks>
///// None.
///// </remarks>
//public static string[] ToArray(string filePath, string assemblyName)
//{
//return (assemblyName == null) ? ToList(filePath, null).ToArray() : ToList(filePath, assemblyName).ToArray();
//}

///// <summary>
///// Convert a file to a dictionary.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <param name="delimiter">The delimiter.</param>
///// <returns></returns>
///// <remarks>
///// I'm not sure how this works, exactly!
///// </remarks>
//public static Dictionary<string, string> ToDictionary(string filePath, string assemblyName, char delimiter)
//{
//return ToArray(filePath, assemblyName).Select(l => l.Split(delimiter)).ToDictionary(a => a[0], a => a[1]);
//}

///// <summary>
///// To the dictionaries.
///// </summary>
///// <param name="fileNames">The file names.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <param name="delimeter">The delimeter.</param>
///// <returns></returns>
///// <remarks>
///// None.
///// </remarks>
//public static List<Dictionary<string, string>> ToDictionaries(List<string> fileNames, string assemblyName, char delimeter)
//{
//var wrkList = new List<Dictionary<string, string>>();

//foreach (var fileName in fileNames)
//{
//wrkList.Add(ToDictionary(fileName, assemblyName, delimeter));
//}

//return wrkList;
//}

///// <summary>
///// To the list.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="assembly">The assembly.</param>
///// <returns></returns>
///// <remarks>
///// [1] If the passed assembly name is "null", then the file is external. If an assembly name was passed, the
/////     file is embedded.Either way, read the file into a list.
///// </remarks>
//public static List<string> ToList(string filePath, string assembly)
//{
//var fileAsList = new List<string>();

//if (assembly == null) // [1]
//{
//using (StreamReader fileToRead = new StreamReader(filePath))
//{
//fileAsList = ReadIntoList(fileToRead);
//}
//}
//else
//{
//using (StreamReader fileToRead = new StreamReader(Assembly.Load(assembly).GetManifestResourceStream((string)assembly + "." + filePath)))
//{
//fileAsList = ReadIntoList(fileToRead);
//}
//}

//return fileAsList;
//}

///* Convert a file into a string.
// * ---
// * filePath      - the full path of the file. If this is just the file name, we'll look in the local directory.
// * assemeblyName - optional assembly name, or "null" to indicate the file is external.                        */

///// <summary>
///// Returns a <see cref="System.String" /> that represents this instance.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="assembly">The assembly.</param>
///// <param name="cleaningRules">The cleaning rules.</param>
///// <returns>
///// A <see cref="System.String" /> that represents this instance.
///// </returns>
///// <remarks>
///// [1] If the passed assembly name is "null", then the file is external. If an assembly name was passed, the
/////     file is embedded.Either way, read the file into a list.
///// </remarks>
//public static string ToString(string filePath, string assembly, Dictionary<string, string> cleaningRules)
//{
//var fileAsString = string.Empty;

//if (assembly == null) // [1]
//{
//using (StreamReader fileToRead = new StreamReader(filePath))
//{
//fileAsString = ReadIntoString(fileToRead, cleaningRules);
//}
//}
//else
//{
//using (StreamReader fileToRead = new StreamReader(Assembly.Load(assembly).GetManifestResourceStream((string)assembly + "." + filePath)))
//{
//fileAsString = ReadIntoString(fileToRead, cleaningRules);
//}
//}

//return fileAsString;
//}

///// <summary>
///// Deletes the specified file path.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <remarks>
///// None.
///// </remarks>
///public static void Delete(string filePath)
//{
//if (File.Exists(filePath))
//{
//File.Delete(filePath);
//}
//}

///* Gets the next number in an extension range.

// *

// * ---
// * directoryName -
// * filePattern   -
// * startAt       -
// */

///// <summary>
///// Gets the next ext number.
///// </summary>
///// <param name="directoryName">Name of the directory.</param>
///// <param name="filePattern">The file pattern.</param>
///// <param name="startAt">The start at.</param>
///// <returns></returns>
///// <remarks>
///// [*] This method is used in a very specific situation, when file have numeric extensions, and you want to
/////     find the next number to use.For instance, if you have the following files in a directory...
/////
/////         "file.001", "file.002", "file.003"
/////
/////     ...this method will determine the next file should be "file.004".
///// [1] This is needed to work correctly.
///// </remarks>
//public static string GetNextExtNum(string directoryName, string filePattern, int startAt)
//{
//var nextNum = startAt;

//foreach (var fName in Directory.GetFiles(directoryName))
//{
//if (Path.GetFileNameWithoutExtension(fName) == filePattern)
//{
//if (int.Parse(Path.GetFileNameWithoutExtension(fName)) > nextNum)
//{
//nextNum = int.Parse(Path.GetFileNameWithoutExtension(fName));
//}
//}
//}
//nextNum++; // [1]

//return nextNum.ToString();
//}

///// <summary>
///// Reads the into list.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <returns></returns>
///// <remarks>
///// [*] As long as the file is passed as a StreamReader type, it doesn't  matter if the file is embedded,
/////     external, or whatever. It's important to note that this function simply returns the contents of a
/////     file as a list, without parsing or cleaning the contents.
///// [T] Fix this like ReadIntoString
///// </remarks>
//private static List<string> ReadIntoList(StreamReader filePath)
//{
//var fileAsList = new List<string>();
//var fileLine = string.Empty;

//while ((fileLine = filePath.ReadLine()) != null)
//{
//fileAsList.Add(fileLine);
//}

//return fileAsList;
//}

///// <summary>
///// Reads the into string.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="cleaningRules">The cleaning rules.</param>
///// <returns></returns>
///// <remarks>
///// [*] As long as the file is passed as a StreamReader type, it doesn't  matter if the file is embedded,
///// external, or whatever. It's important to note that this function simply returns the contents of a file
///// as a list, without parsing or cleaning the contents.
///// [1] Loop through the passed file. With each pass, check the following:
/////         - Are we checking for empty lines, and is the line empty?
/////         - Are we checking for null lines, and is the line null?
/////         - Are we checking for comments, and does the line start with the comment line?
/////     As long as all three of those statements are false, add to line to the wrkString.If any of them are
/////     false, then don't add the line to the wrkString.
///// </remarks>
//private static string ReadIntoString(StreamReader filePath, Dictionary<string, string> cleaningRules)
//{
//var fileAsString = string.Empty;
//var fileLine = string.Empty;
//var emptyPassed = false;
//var nullPassed = false;
//var commentPassed = false;

//while ((fileLine = filePath.ReadLine()) != null)
//{
//emptyPassed = (cleaningRules["empties"] == "true" && AOString.CheckEmpty(fileLine, null)) ? false : true;
//nullPassed = (cleaningRules["nulls"] == "true" && AOString.CheckNull(fileLine)) ? false : true;
//commentPassed = (cleaningRules["commentChar"] != " " && AOString.CheckComment(fileLine, Convert.ToChar(cleaningRules["commentChar"]))) ? false : true;

//if (emptyPassed && nullPassed && commentPassed)
//{
//fileAsString = fileAsString + fileLine + " ";
//}
//}

//return fileAsString;
//}
//}
//}

//####### AO.51.160926

///* A class for AO.cs that does various things with files.
// * v00.51.160926
// * http://aprettycoolprogram.com/ao
// */

//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Reflection;

//namespace AO
//{
//public class AOFile
//{
///// <summary>Append text to a file.</summary>
///// <param name="filePath">The file to append the text to.</param>
///// <param name="toAppend">The text to append.</param>
///// <remarks>If the file doesn't exist, it is created.</remarks>
//public static void Append(string filePath, string toAppend)
//{
//File.AppendAllText(filePath, toAppend + Environment.NewLine);
//}

///// <summary>Convert a file to an array.</summary>
///// <param name="filePath">Name of file.</param>
///// <param name="assembly">Name of the assembly (optional) [null, name_of_assembly]</param>
///// <returns>The file as an array.</returns>
///// <remarks>
///// The file is originally converted to a list by AOFile.ReadExt, then converted to an array by this method.
///// Passing asm as "null" indicates the file to be read is external, passing a string indicates it's embedded.
///// </remarks>
//public static string[] AsArray(string filePath, string assembly)
//{
//return (assembly == null) ? ExternalAsList(filePath).ToArray() : EmbeddedAsList(filePath, assembly).ToArray();
//}

///// <summary>Convert a file to a dictionary.</summary>
///// <param name="filePath">path to file.</param>
///// <param name="delim"></param>
///// <returns>A dictionary.</returns>
///// <remarks>
///// The file is originally converted to a list by AOFile.ReadExt, then converted to a dictionary by this method.
///// Passing asm as "null" indicates the file to be read is external, passing a string indicates it's embedded.
///// </remarks>
//public static Dictionary<string, string> AsDictionary(string filePath, char delim, string assembly)
//{
//return AsArray(filePath, assembly).Select(l => l.Split(delim)).ToDictionary(a => a[0], a => a[1]); // ???
//}

///// <returns>A dictionary with all of the settings from the files.</returns>
///// <summary>Convert a list of files to a list of dictionaries.</summary>
///// <param name="fileNames">The list of filenames.</param>
///// <param name="delim">The delimiter that seperates key/value pairs [ex. "=", "-"]</param>
///// <param name="assembly">The name of the assembly.</param>
///// <returns>The file contents as a dictionary.</returns>
///// <remarks>
///// Each dictionary is sent to AOFile.AsDictionary to be converted to a dictionary, and that dictionary is then
///// Added to the list of existing dictionary list.
///// </remarks>
//public static List<Dictionary<string, string>> AsDictionaries(List<string> fileNames, char delim, string assembly)
//{
//var wrkList = new List<Dictionary<string, string>>();

//foreach (var fileName in fileNames)
//{
//wrkList.Add(AsDictionary(fileName, delim, assembly));
//}

//return wrkList;
//}

///// <summary>Convert a file to a list.</summary>
///// <param name="filePath">The path to the file.</param>
///// <param name="ignorePhrase">If the line contains this phrase, it's ignored (optional).</param>
///// <param name="clean">Flag to clean the data before counting.</param>
///// <returns>A list.</returns>
//public static List<string> AsList(string filePath, string assembly)
//{
//return (assembly == null) ? ExternalAsList(filePath) : EmbeddedAsList(filePath, assembly);
//}

///// <summary>Convert a file to a string.</summary>
///// <param name="filePath">The file to convert.</param>
///// <param name="assembly">The assembly name (optional).</param>
///// <param name="clean">Flag to clean the data before counting.</param>
///// <returns>A string.</returns>
//public static string AsString(string filePath, string assembly)
//{
//return (assembly == null) ? ExternalAsList(filePath).ToString() : EmbeddedAsList(filePath, assembly).ToString();
//}

///// <summary>Count the number of characters or lines in a file.</summary>
///// <param name="filePath">The file to count the items of</param>
///// <param name="clean">Flag to clean the data before counting.</param>
///// <param name="itemType">What to count?</param>
///// <returns>The number of characters or lines in the file.</returns>
//public static int Count(string filePath, bool clean, string itemType, string assembly)
//{
//switch (itemType)
//{
//case "char":
//return AOArray.Count(AsArray(filePath, assembly), "char"); // Move to list

//case "line":
//return AOArray.Count(AsArray(filePath, assembly), "line");

//default:
//return 0; // ERROR
//}
//}

///// <summary>Delete a file if it exists.</summary>
///// <param name="filePath">The filename to delete.</param>
///// <remarks></remarks>
//public static void Delete(string filePath)
//{
//if (File.Exists(filePath))
//{
//File.Delete(filePath);
//}
//}

///// <summary>Get the extension of a filename.</summary>
///// <param name="fileName">The filename.</param>
///// <returns>The filename extension.</returns>
///// <remarks></remarks>
//public static string GetExt(string fileName)
//{
//return Path.GetExtension(fileName).Replace(".", "");
//}

///// <summary>Get the name of a file without an extension.</summary>
///// <param name="fileName">The filename.</param>
///// <returns>The filename without the extension.</returns>
///// <remarks></remarks>
//public static string GetName(string fileName)
//{
//return Path.GetFileNameWithoutExtension(fileName);
//}

///// <summary>Gets the next number in an extension range.</summary>
///// <param name="directoryName">Directory to look at.</param>
///// <param name="filePattern">The file name base to match.</param>
///// <param name="startAt">What to start at.</param>
///// <returns>A number for the next extension.</returns>
///// <remarks>
///// This is used when files in a directory have numeric extensions (i.e. "file.1", "file.2"...), and you want to
///// find the next number (i.e. "file.3").
///// </remarks>
//public static string GetNextExtNum(string directoryName, string filePattern, int startAt)
//{
//var nextNum = startAt;

//foreach (var fName in Directory.GetFiles(directoryName))
//{
//if (AOFile.GetName(fName) == filePattern)
//{
//if (int.Parse(AOFile.GetExt(fName)) > nextNum)
//{
//nextNum = int.Parse(AOFile.GetExt(fName));
//}
//}
//}
//nextNum++; // Need this to work correctly.

//return nextNum.ToString();
//}

///// <summary>Get a random line from an embedded file.</summary>
///// <param name="fileName">The name of the embedded file.</param>
///// <param name="asm">Name of the assembly</param>
///// <param name="lineToRead">The number of the line to read.</param>
///// <returns>A random line.</returns>
//public static string RndLine(string fileName, int lineToRead, string assembly)
//{
//return AsArray(fileName, assembly)[lineToRead - 1]; // ??? Look at this.
//}

///// <summary>Puts the contents of an external file into a list.</summary>
///// <param name="filePath">Path to the file.</param>
///// <returns>The file as a list</returns>
///// <remarks>
///// This function initializes a StreamReader object for an external file, then passes that object to AOFile.Read
///// to do the heavy lifting of reading the file. It's important to note this method simply sets up the
///// StreamReader object, and doesn't do any parsing or cleaning.
///// </remarks>
//private static List<string> ExternalAsList(string filePath) // Combine w/below
//{
//var fileAsList = new List<string>();

//using (StreamReader fileToRead = new StreamReader(filePath))
//{
//fileAsList = Read(fileToRead);
//}

//return fileAsList;
//}

///// <summary>Puts the contents of an embedded file into a list.</summary>
///// <param name="filePath">Path to the file.</param>
///// <param name="assembly">The assembly name the file is a member of.</param>
///// <returns>The file as a list</returns>
///// <remarks>
///// This function initializes a StreamReader object for an embedded file, then passes that object to AOFile.Read
///// to do the heavy lifting of reading the file. It's important to note this method simply sets up the
///// StreamReader object, and doesn't do any parsing or cleaning.
///// </remarks>
//private static List<string> EmbeddedAsList(string filePath, string assembly)
//{
//var fileAsList = new List<string>();
//filePath = assembly + "." + filePath;

//using (StreamReader fileToRead = new StreamReader(Assembly.Load(assembly).GetManifestResourceStream((string)filePath)))
//{
//fileAsList = Read(fileToRead);
//}

//return fileAsList;
//}

///// <summary>Reads a file into a list.</summary>
///// <param name="filePath">Path to the file.</param>
///// <returns>The file as a list.</returns>
///// <remarks>
///// Does the heavy lifting when reading files. As long as the file is passed as a StreamReader type, it doesn't
///// matter if the file is embedded, external, or whatever. It's important to note that this function simply
///// returns the contents of a file as a list, without parsing or cleaning the contents.
///// </remarks>
//private static List<string> Read(StreamReader filePath)
//{
//var fileAsList = new List<string>();
//var fileLine = string.Empty;

//while ((fileLine = filePath.ReadLine()) != null)
//{
//fileAsList.Add(fileLine);
//}

//return fileAsList;
//}
//}
//}

//##### AO ss 8-2-16

//// ---------------------------------------------------------------------------------------------------------------------
//// Name: DoFile.cs
//// Version: 00.90.01.160731
//// Author: Christopher Banwarth (development@aprettycoolprogram.com)
//// Description: A class for AO that does various things with files.
//// More: ao.aprettycoolprogram.com OR aprettycoolprogram.github.com
//// ---------------------------------------------------------------------------------------------------------------------

//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Reflection;

//namespace AO
//{
//public class DoFile
//{
///// <summary>Append text to a file. If the file doesn't exist, it's created.</summary>
///// <param name="filePath">The file to append the text to.</param>
///// <param name="toAppend">The text to append.</param>
///// <remarks>None</remarks>
///// <build>160713</build>
//public static void Append(string filePath, string toAppend)
//{
//File.AppendAllText(filePath, toAppend + Environment.NewLine); //? Need to append a newline?
//}

///// <summary>Convert a file to an array.</summary>
///// <param name="filePath">Name of file.</param>
///// <param name="assemblyName">Assembly name (optional).</param>
///// <returns>The file as an array.</returns>
///// <remarks>None</remarks>
///// <build>160713</build>
//public static string[] ContentAsArray(string filePath, string assemblyName, bool clean)
//{
//var fileAsList = new List<string>();
//var fileLine = string.Empty;

//if (assemblyName == null)
//{
////TODO Local code will go here
//}
//else
//{ // Embedded data
//var assemblyFile = assemblyName + "." + filePath;

//using (StreamReader fileToRead = new StreamReader(Assembly.Load(assemblyName).GetManifestResourceStream(assemblyFile)))
//{
//while ((fileLine = fileToRead.ReadLine()) != null)
//{
//fileAsList.Add(fileLine);
//}
//}
//}

//var fileAsArray = fileAsList.ToArray();

//if (clean) // Optionally remove empty/comment/null lines
//{
//return DoArray.RemoveComponent(fileAsArray, "all", '#');
//}

//return fileAsArray;
//}

///// <summary>Convert a file to a dictionary.</summary>
///// <param name="filePath">path to file.</param>
///// <param name="assemblyName">Name of assembly (optional).</param>
///// <returns></returns>
///// <remarks>None</remarks>
///// <build>160713</build>
//public static Dictionary<string, string> ContentAsDictionary(string filePath, string assemblyName, bool clean, char delimiter)
//{
//var fileAsDictionary = ContentAsArray(filePath, assemblyName, clean).Select(l => l.Split(delimiter)).ToDictionary(a => a[0], a => a[1]); // Return key/values of file -> array split at delim - HOW WORKS?

//return fileAsDictionary;
//}

///// <summary>Convert a file to a list.</summary>
///// <param name="fPath">The path to the file.</param>
///// <param name="assemblyName">The assembly name (optional).</param>
///// <param name="clean">Flag to clean the data before counting.</param>
///// <returns></returns>
///// <remarks>None</remarks>
///// <build>160713</build>
//public static List<string> ContentAsList(string fPath, string assemblyName, bool clean)
//{
//return ContentAsArray(fPath, assemblyName, clean).ToList();
//}

///// <summary>Convert a file to a string.</summary>
///// <param name="fPath">The file to convert.</param>
///// <param name="assemblyName">The assembly name (optional).</param>
///// <param name="clean">Flag to clean the data before counting.</param>
///// <remarks>None</remarks>
///// <build>160713</build>
//public static string ContentAsString(string fPath, string assemblyName, bool clean)
//{
//return ContentAsArray(fPath, assemblyName, clean).ToString();
//}

///// <summary>Convert a list of files to a list of dictionaries.</summary>
///// <param name="fPaths">The list of filenames.</param>
///// <returns>A dictionary with all of the settings from the files.</returns>
///// <remarks>None</remarks>
///// <build>160713</build>
//public static List<Dictionary<string, string>> ContentsAsDictionaries(List<string> fPaths, string assemblyName, bool clean, char delim)
//{
//var listOfDictionaries = new List<Dictionary<string, string>>();

//foreach (var item in fPaths)
//{
//listOfDictionaries.Add(ContentAsDictionary(item, assemblyName, clean, delim)); // Assembly name must be the same for all dictionaries.
//}

//return listOfDictionaries;
//}

///// <summary>Count the number of characters or lines in a file.</summary>
///// <param name="fPath">The file to count the items of</param>
///// <param name="assemblyName">The name of the assembly (optional).</param>
///// <param name="clean">Flag to clean the data before counting.</param>
///// <param name="action">What to count?</param>
///// <returns>The number of characters or lines in the file.</returns>
///// <remarks>None</remarks>
///// <build>160713</build>
//public static int Count(string fPath, string assemblyName, bool clean, string action)
//{
//var toCount = ContentAsArray(fPath, assemblyName, clean);

//switch (action)
//{
//case "char":
//return DoArray.CountComponent(toCount, "char");

//case "line":
//return DoArray.CountComponent(toCount, "line");

//default:
//return 0;
//}
//}

///// <summary>Delete a file if it exists.</summary>
///// <param name="fPath">The filename to delete.</param>
///// <remarks>None</remarks>
///// <build>160713</build>
//public static void Delete(string fPath)
//{
//if (File.Exists(fPath))
//{
//File.Delete(fPath);
//}
//}

///// <summary>Get the extension of a filename.</summary>
///// <param name="fileName">The filename.</param>
///// <returns>The filename extension.</returns>
///// <remarks>None</remarks>
///// <build>160725</build>
//public static string GetExtension(string fileName)
//{
//return Path.GetExtension(fileName).Replace(".", "");
//}

///// <summary>Get the name of a file without an extension.</summary>
///// <param name="fileName">The filename.</param>
///// <returns>The filename without the extension.</returns>
///// <remarks>None</remarks>
///// <build>160725</build>
//public static string GetNameOnly(string fileName)
//{
//return Path.GetFileNameWithoutExtension(fileName);
//}

///// <summary>Gets the next number in an extension range.</summary>
///// <param name="directoryName">Directory to look at.</param>
///// <param name="fileNameBase">The file name base to match.</param>
///// <returns>A number for the next extension.</returns>
///// <remarks>
///// This is used when files in a directory have numeric extensions (i.e. "file.1", "file.2"...), and you want to
///// find the next number (i.e. "file.3"
///// </remarks>
///// <build>160727</build>
//public static string GetNextExtensionNumber(string directoryName, string fileNameBase, int startAt)
//{
//var nextNumber = startAt; // Start at a predetermined location

//// Loop through all files in the directory, and increment the number if the base name matches and the
//// extension is less than the current number.
//foreach (var fileName in DoDirectory.GetFileNames(directoryName))
//{
//if (DoFile.GetNameOnly(fileName) == fileNameBase)
//{
//if (int.Parse(DoFile.GetExtension(fileName)) > nextNumber)
//{
//nextNumber = int.Parse(DoFile.GetExtension(fileName));
//}
//}
//}
//nextNumber++; // Increment so we use the next number.

//return nextNumber.ToString();
//}

///// <summary>Get a random line from a file.</summary>
///// <param name="fPath">The file to append the text to.</param>
///// <returns></returns>
///// <remarks>None</remarks>
///// <build>160713</build>
//public static string RandomLine(string fPath, string assemblyName, int lineToRead)
//{
//if (assemblyName == null) // Filesystem
//{
//return "ERROR: This code does not exist"; //! LOCAL FILESYSTEM CODE
//}
//else // Embedded
//{
//var liner = lineToRead - 1;
//return DoFile.ContentAsArray(fPath, assemblyName, false)[liner];
////return File.ReadLines(asm + "." + path).Skip(liner).Take(1).First();                                          //? Needed?
//}
//}
//}
//}

//// CHANGELOG
//// =========
//// 00.90.00.160717: Initial release
//// 00.90.01.160731: Code and comment cleanup

//// ROADMAP
//// =======
//// * Proper error handling

//// NOTES
//// =====

//##### AO 12-21-16

///* A class for AO.cs that does various things with files.
//* v00.53.04.161220
//* http://aprettycoolprogram.com/ao
//*/

//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Reflection;

//namespace AO
//{
//public class AOFile
//{
///// <summary>
///// Counts the lines in a file.
///// </summary>
///// <param name="fileName">Name of the file.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <returns></returns>
///// <remarks>
///// Verify.
///// </remarks>
//public static long CountLines(string fileName, string assemblyName)
//{
//return ToList(fileName, assemblyName).Count;
//}

///// <summary>
///// Counts the characters.
///// </summary>
///// <param name="fileName">Name of the file.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <returns></returns>
///// <remarks>
///// Verify.
///// </remarks>
//public static long CountCharacters(string fileName, string assemblyName)
//{
//return 0;
//}

///// <summary>
///// Randoms the line.
///// </summary>
///// <param name="lineNumber">The line number.</param>
///// <returns></returns>
///// <remarks>
///// Verify
///// </remarks>
//public static string RandomLine(int lineNumber)
//{
////var test = ToList("Resources.Appdata.Generators.firstnames.gnr", "DUNGEON");
////return "NONE";
//}

///// <summary>
///// Convert a file to an array.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <returns></returns>
///// <remarks>
///// None.
///// </remarks>
//public static string[] ToArray(string filePath, string assemblyName)
//{
//return (assemblyName == null) ? ToList(filePath, null).ToArray() : ToList(filePath, assemblyName).ToArray();
//}

///// <summary>
///// Convert a file to a dictionary.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <param name="delimiter">The delimiter.</param>
///// <returns></returns>
///// <remarks>
///// I'm not sure how this works, exactly!
///// </remarks>
//public static Dictionary<string, string> ToDictionary(string filePath, string assemblyName, char delimiter)
//{
//return ToArray(filePath, assemblyName).Select(l => l.Split(delimiter)).ToDictionary(a => a[0], a => a[1]);
//}

///// <summary>
///// To the dictionaries.
///// </summary>
///// <param name="fileNames">The file names.</param>
///// <param name="assemblyName">Name of the assembly.</param>
///// <param name="delimeter">The delimeter.</param>
///// <returns></returns>
///// <remarks>
///// None.
///// </remarks>
//public static List<Dictionary<string, string>> ToDictionaries(List<string> fileNames, string assemblyName, char delimeter)
//{
//var wrkList = new List<Dictionary<string, string>>();

//foreach (var fileName in fileNames)
//{
//wrkList.Add(ToDictionary(fileName, assemblyName, delimeter));
//}

//return wrkList;
//}

///// <summary>
///// To the list.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="assembly">The assembly.</param>
///// <returns></returns>
///// <remarks>
///// [1] If the passed assembly name is "null", then the file is external. If an assembly name was passed, the
/////     file is embedded.Either way, read the file into a list.
///// </remarks>
//public static List<string> ToList(string filePath, string assembly)
//{
//var fileAsList = new List<string>();

//if (assembly == null) // [1]
//{
//using (StreamReader fileToRead = new StreamReader(filePath))
//{
//fileAsList = ReadIntoList(fileToRead);
//}
//}
//else
//{
//using (StreamReader fileToRead = new StreamReader(Assembly.Load(assembly).GetManifestResourceStream((string)assembly + "." + filePath)))
//{
//fileAsList = ReadIntoList(fileToRead);
//}
//}

//return fileAsList;
//}

///* Convert a file into a string.
// * ---
// * filePath      - the full path of the file. If this is just the file name, we'll look in the local directory.
// * assemeblyName - optional assembly name, or "null" to indicate the file is external.                        */

///// <summary>
///// Returns a <see cref="System.String" /> that represents this instance.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="assembly">The assembly.</param>
///// <param name="cleaningRules">The cleaning rules.</param>
///// <returns>
///// A <see cref="System.String" /> that represents this instance.
///// </returns>
///// <remarks>
///// [1] If the passed assembly name is "null", then the file is external. If an assembly name was passed, the
/////     file is embedded.Either way, read the file into a list.
///// </remarks>
//public static string ToString(string filePath, string assembly, Dictionary<string, string> cleaningRules)
//{
//var fileAsString = string.Empty;

//if (assembly == null) // [1]
//{
//using (StreamReader fileToRead = new StreamReader(filePath))
//{
//fileAsString = ReadIntoString(fileToRead, cleaningRules);
//}
//}
//else
//{
//using (StreamReader fileToRead = new StreamReader(Assembly.Load(assembly).GetManifestResourceStream((string)assembly + "." + filePath)))
//{
//fileAsString = ReadIntoString(fileToRead, cleaningRules);
//}
//}

//return fileAsString;
//}

///// <summary>
///// Deletes the specified file path.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <remarks>
///// None.
///// </remarks>
///public static void Delete(string filePath)
//{
//if (File.Exists(filePath))
//{
//File.Delete(filePath);
//}
//}

///* Gets the next number in an extension range.

// *

// * ---
// * directoryName -
// * filePattern   -
// * startAt       -
// */

///// <summary>
///// Gets the next ext number.
///// </summary>
///// <param name="directoryName">Name of the directory.</param>
///// <param name="filePattern">The file pattern.</param>
///// <param name="startAt">The start at.</param>
///// <returns></returns>
///// <remarks>
///// [*] This method is used in a very specific situation, when file have numeric extensions, and you want to
/////     find the next number to use.For instance, if you have the following files in a directory...
/////
/////         "file.001", "file.002", "file.003"
/////
/////     ...this method will determine the next file should be "file.004".
///// [1] This is needed to work correctly.
///// </remarks>
//public static string GetNextExtNum(string directoryName, string filePattern, int startAt)
//{
//var nextNum = startAt;

//foreach (var fName in Directory.GetFiles(directoryName))
//{
//if (Path.GetFileNameWithoutExtension(fName) == filePattern)
//{
//if (int.Parse(Path.GetFileNameWithoutExtension(fName)) > nextNum)
//{
//nextNum = int.Parse(Path.GetFileNameWithoutExtension(fName));
//}
//}
//}
//nextNum++; // [1]

//return nextNum.ToString();
//}

///// <summary>
///// Reads the into list.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <returns></returns>
///// <remarks>
///// [*] As long as the file is passed as a StreamReader type, it doesn't  matter if the file is embedded,
/////     external, or whatever. It's important to note that this function simply returns the contents of a
/////     file as a list, without parsing or cleaning the contents.
///// [T] Fix this like ReadIntoString
///// </remarks>
//private static List<string> ReadIntoList(StreamReader filePath)
//{
//var fileAsList = new List<string>();
//var fileLine = string.Empty;

//while ((fileLine = filePath.ReadLine()) != null)
//{
//fileAsList.Add(fileLine);
//}

//return fileAsList;
//}

///// <summary>
///// Reads the into string.
///// </summary>
///// <param name="filePath">The file path.</param>
///// <param name="cleaningRules">The cleaning rules.</param>
///// <returns></returns>
///// <remarks>
///// [*] As long as the file is passed as a StreamReader type, it doesn't  matter if the file is embedded,
///// external, or whatever. It's important to note that this function simply returns the contents of a file
///// as a list, without parsing or cleaning the contents.
///// [1] Loop through the passed file. With each pass, check the following:
/////         - Are we checking for empty lines, and is the line empty?
/////         - Are we checking for null lines, and is the line null?
/////         - Are we checking for comments, and does the line start with the comment line?
/////     As long as all three of those statements are false, add to line to the wrkString.If any of them are
/////     false, then don't add the line to the wrkString.
///// </remarks>
//private static string ReadIntoString(StreamReader filePath, Dictionary<string, string> cleaningRules)
//{
//var fileAsString = string.Empty;
//var fileLine = string.Empty;
//var emptyPassed = false;
//var nullPassed = false;
//var commentPassed = false;

//while ((fileLine = filePath.ReadLine()) != null)
//{
//emptyPassed = (cleaningRules["empties"] == "true" && AOString.CheckEmpty(fileLine, null)) ? false : true;
//nullPassed = (cleaningRules["nulls"] == "true" && AOString.CheckNull(fileLine)) ? false : true;
//commentPassed = (cleaningRules["commentChar"] != " " && AOString.CheckComment(fileLine, Convert.ToChar(cleaningRules["commentChar"]))) ? false : true;

//if (emptyPassed && nullPassed && commentPassed)
//{
//fileAsString = fileAsString + fileLine + " ";
//}
//}

//return fileAsString;
//}
//}
//}

//*/
