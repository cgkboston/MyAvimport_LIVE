//  PROJECT: Du
// FILENAME: DuLabel.cs
//    BUILD: 170327
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Du
{
    public class DuLabel
    {
        /// <summary>Creates a new label collection.</summary>
        /// <param name="formName">Name of the form.</param>
        /// <param name="lblTemplate">The button template.</param>
        /// <param name="collectionDefinition">The collection definition.</param>
        /// <param name="listOfLblNames">The list of label names.</param>
        /// <returns>A collection of labels.</returns>
        public static Label[] CreateCollection(Form formName, Label lblTemplate, DuControl collectionDefinition, List<string> listOfLblNames)
        {
            // Initialize the array, row, and column counters at their minimum, then set the initial location.
            var currentLabel  = 0;
            var currentRow    = 1;
            var currentColumn = 1;
            var location = new Point(lblTemplate.Location.X, lblTemplate.Location.Y);

            // Get the true maximum rows and columns by checking to see if the collection definition maximum is greater
            // than what the form can handle. If it is, then the maximum rows/columns should equal the what the form
            // can handle.
            var maximumFormRows = DuControl.GetMaxFormRows(formName, lblTemplate.Height, collectionDefinition.SpacerY);
            var maximumRows     = (collectionDefinition.MaximumRows > maximumFormRows)
            ? maximumFormRows
            : collectionDefinition.MaximumRows;

            var maximumFormColumns = DuControl.GetMaxFormColumns(formName, lblTemplate.Width, collectionDefinition.SpacerX);
            var maximumColumns     = (collectionDefinition.MaximumRows > maximumFormRows)
            ? maximumFormColumns
            : collectionDefinition.MaximumColumns;

            // Create the label array, and loop through all of the label names to create individual labels.
            var lblArray  = new Label[listOfLblNames.Count];

            foreach (var lblName in listOfLblNames)
            {
                // Create a new label and put it in the label array. If any of the following properties are not passed,
                // they will be set as the default label value.
                lblArray[currentLabel] = new Label()
                {
                    Name        = lblTemplate.Name + lblName.Replace(" ", ""),
                    BackColor   = lblTemplate.BackColor,
                    BorderStyle = lblTemplate.BorderStyle,
                    ForeColor   = lblTemplate.ForeColor,
                    Location    = new Point(location.X, location.Y),
                    Size        = lblTemplate.Size,
                    Text        = Convert.ToString(currentLabel) // TESTING
                };

                // Move to the next label, then check to see if we've done all of the labels, and if so, break.
                currentLabel++;
                if (currentLabel == listOfLblNames.Count)
                break;

                // Direction.
                switch (collectionDefinition.BuildDirection)
                {
                    case "down":
                    if (currentColumn > maximumColumns)
                    {
                        // If the current column IS GREATER than the maximum allowed columns, then set the row
                        // counter to the next row, move the location to the next row, reset the column to the first
                        // column and reset the column location to the original template value.
                        currentRow++;
                        location.Y    = location.Y + collectionDefinition.SpacerY;
                        currentColumn = 1;
                        location.X    = lblTemplate.Location.X;
                    }
                    else
                    {
                        // If the current column is LESS THAN the maximum allowed columns, and the current x-axis
                        // location IS NOT "1", then set the x-axis location to be the current location plus the 
                        // spacer value. If the current column is NOT LESS THAN the maximum allowed columns, and the
                        // current x-axis location IS "1", the x-axis location stays where it is. Either way, 
                        location.X = (currentColumn != 1)
                        ? location.X += collectionDefinition.SpacerX
                        : location.X;
                        currentColumn++;
                    }
                    break;
                    default:
                    break;
                    }
                    }

                    return lblArray;
                    }
    }
}

/*

CHANGELOG
=========
b170324  - Initial release

ROADMAP
=======

OLD CODE SNIPPITS
=================

 */
