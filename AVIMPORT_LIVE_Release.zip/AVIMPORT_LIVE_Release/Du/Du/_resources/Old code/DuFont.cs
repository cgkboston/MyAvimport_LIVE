using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Du
{
    class DuFont
    {
    }
}

/*
   * This is older code that should be reviewed.

    public static void Load(string fontName)
        {
            // This doesn't do anything yet.

            //string filename = @"C:\lady.gaga";
            //File.WriteAllBytes(filename, Resources.KBREINDEERGAMES);
            //PrivateFontCollection pfc = new PrivateFontCollection();
            //pfc.AddFontFile(filename);

            //Label label = new Label();
            //label.AutoSize = true;
            //label.Font = new Font(pfc.Families[0], 16);
            //label.Text = "hello world";
            //Controls.Add(label);
        }

    */
