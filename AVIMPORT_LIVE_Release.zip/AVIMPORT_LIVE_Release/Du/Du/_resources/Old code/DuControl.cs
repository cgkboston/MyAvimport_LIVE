//  PROJECT: Du
// FILENAME: DuControl.cs
//    BUILD: 170327
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Du
{
    public class DuControl
    {
        // These properties are for control packages.
        public int    SpacerX { get; set; }
        public int    SpacerY { get; set; }
        public string BuildDirection { get; set; }
        public int    PaddingX { get; set; }
        public int    PaddingY { get; set; }
        public int    MaximumRows { get; set; }
        public int    MaximumColumns { get; set; }

        /// <summary>
        ///
        /// </summary>
        /// <param name="formName"></param>
        /// <param name="controlHeight"></param>
        /// <param name="spacerY"></param>
        /// <returns></returns>
        public static int GetMaxFormRows(Form formName, int controlHeight, int spacerY)
        {
            return formName.Height / (controlHeight + spacerY);
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="formName"></param>
        /// <param name="controlWidth"></param>
        /// <param name="spacerX"></param>
        /// <returns></returns>
        public static int GetMaxFormColumns(Form formName, int controlWidth, int spacerX)
        {
            return formName.Width / (controlWidth + spacerX);
        }

        /// <summary>Sets control background image and layout</summary>
        /// <param name="controlName">Name of the control.</param>
        /// <param name="fileName">Filename of the background image.</param>
        /// <param name="imageLayout">Background layout (null = ignore).</param>
        public static void SetBackgroundImageFromFile (Control controlName, string fileName, ImageLayout imageLayout)
        {
            // Tested with:
            controlName.BackgroundImage       = Image.FromFile(fileName);
            controlName.BackgroundImageLayout = imageLayout;
        }

        public static void SwapEnabled(Control firstControl, Control secondControl)
        {
            /* In order for this to work, we need to store the original value of each controls state prior to
             * calling this method.The easiest way to do this is to make sure the states are set when the form is
             * initialized.
             */
            // Tested with:
            var originalStateOfFirstControl  = Convert.ToBoolean(firstControl.GetType().GetProperty("Enabled").GetValue(firstControl));
            var originalStateOfSecondControl = Convert.ToBoolean(secondControl.GetType().GetProperty("Enabled").GetValue(secondControl));

            firstControl.GetType().GetProperty("Enabled").SetValue(firstControl, originalStateOfSecondControl);
            secondControl.GetType().GetProperty("Enabled").SetValue(secondControl, originalStateOfFirstControl);
        }

        public static void SwapVisibility(Control firstControl, Control secondControl)
        {
            /* In order for this to work, we need to store the original value of each controls state prior to
             * calling this method.The easiest way to do this is to make sure the states are set when the form is
             * initialized.
             */
            // Tested with:
            var originalStateOfFirstControl  = Convert.ToBoolean(firstControl.GetType().GetProperty("Visible").GetValue(firstControl));
            var originalStateOfSecondControl = Convert.ToBoolean(secondControl.GetType().GetProperty("Visible").GetValue(secondControl));

            firstControl.GetType().GetProperty("Visible").SetValue(firstControl, originalStateOfSecondControl);
            secondControl.GetType().GetProperty("Visible").SetValue(secondControl, originalStateOfFirstControl);
        }

        public static void ToggleBackgroundColor(Control controlName, Color colorOne, Color colorTwo)
        {
            // Tested with:
            controlName.ForeColor = controlName.ForeColor == colorOne
                ? colorTwo
                : colorOne;
        }

        public static void LabelToggleBorder(Label labelName, BorderStyle borderStyleOne, BorderStyle borderStyleTwo)
        {
            // Tested with:
            labelName.BorderStyle = (labelName.BorderStyle == borderStyleOne)
                ? borderStyleTwo
                : borderStyleOne;
        }

        public static void ToggleForegroundColor(Control controlName, Color colorOne, Color colorTwo)
        {
            // Tested with:
            controlName.ForeColor = controlName.ForeColor == colorOne
                ? colorTwo
                : colorOne;
        }
    }
}
