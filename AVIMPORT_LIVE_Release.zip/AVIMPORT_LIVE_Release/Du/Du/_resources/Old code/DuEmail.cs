//  PROJECT: Du
// FILENAME: DuEmail.cs
//    BUILD: 170310
//
// Copyright 2017 A Pretty Cool Program
//
// Du is licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in
// compliance with the License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
// an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under the License.
//
// For more information about Du, please visit http://aprettycoolprogram.com/Du.
//

using System.Collections.Generic;
using System.Net.Mail;
using System.Net.Mime;

namespace Du
{
    /*  This class does various things with arrays.
     */
    public class DuEmail
    {
        public string From { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string AccountUserName { get; set; }
        public string AccountPassword { get; set; }
        public string SMTPHost { get; set; }
        public int SMTPPort { get; set; }
        public bool RequiresSSL { get; set; }

        public class Add
        {
            /// <summary>Adds attachments to an email message.</summary>
            /// <param name="message">The message.</param>
            /// <param name="attachments">The attachments.</param>
            /// <returns></returns>
            public static MailMessage Attachments(MailMessage message, List<string> attachments)
            {
                if (attachments != null)
                {
                    foreach (var attachment in attachments)
                    {
                        var attachedFile = new Attachment(attachment, MediaTypeNames.Application.Octet);
                        message.Attachments.Add(attachedFile);
                    }
                }

                return message;
            }
        }

        public class Check
        {
            /// <summary>Determines whether the specified mail message has attachments.</summary>
            /// <param name="message">The mail message.</param>
            /// <returns>
            ///   <c>true</c> if the specified mail message has attachments; otherwise, <c>false</c>.
            /// </returns>
            public static bool HasAttachments(MailMessage message)
            {
                return (message.Attachments.Count > 0) ? true : false;
            }
        }

        public class Create
        {
            /// <summary>Creates a mail message</summary>
            /// <param name="recipients">The recipients.</param>
            /// <param name="package">The package.</param>
            /// <returns></returns>
            public static MailMessage Message(List<string> recipients, DuEmail package)
            {
                var message = new MailMessage
                {
                    From = new MailAddress(package.From),
                    Subject = package.Subject,
                    Body = package.Body
                };

                foreach (var item in recipients)
                    message.To.Add(item);

                return message;
            }

            /// <summary>Creates a new SMTP client</summary>
            /// <param name="package">The package.</param>
            /// <returns></returns>
            public static SmtpClient SMTPClient(DuEmail package)
            {
                return new SmtpClient
                {
                    Host = package.SMTPHost,
                    Port = package.SMTPPort,
                    Credentials = new System.Net.NetworkCredential(package.AccountUserName, package.AccountPassword),
                    EnableSsl = package.RequiresSSL
                };
            }
        }

        public class Package
        {
            /// <summary>Builds a new DuEmail package.</summary>
            /// <param name="from">From.</param>
            /// <param name="subject">The subject.</param>
            /// <param name="body">The body.</param>
            /// <param name="userName">Name of the user.</param>
            /// <param name="password">The password.</param>
            /// <param name="host">The SMTP host.</param>
            /// <param name="port">The SMTP port.</param>
            /// <param name="requireSSL">if set to <c>true</c> [require SSL].</param>
            /// <returns></returns>
            public static DuEmail Build(string from, string subject, string body, string userName, string password, string host, int port, bool requireSSL)
            {
                return new DuEmail
                {
                    From = from,
                    Subject = subject,
                    Body = body,
                    AccountUserName = userName,
                    AccountPassword = password,
                    SMTPHost = host,
                    SMTPPort = port,
                    RequiresSSL = requireSSL
                };
            }

            public class Remove
            {
                /// <summary>Removes attachments from a sent email.</summary>
                /// <param name="mailMessage">The mail message.</param>
                public static void Attachments(MailMessage mailMessage)
                {
                    foreach (var attachment in mailMessage.Attachments)
                        attachment.Dispose();

                    mailMessage.Attachments.Dispose();
                }
            }

            public class Send
            {
                /// <summary>Sends an email.</summary>
                /// <param name="recipients">To addresses.</param>
                /// <param name="attachments">The attachments.</param>
                /// <param name="package">The email package.</param>
                public static void Email(SmtpClient client, MailMessage message)
                {
                    client.Send(message);

                    if (Check.HasAttachments(message))
                        Remove.Attachments(message);

                    // recipients.Clear(); // Clean up recipients - MOVE TO DOLIST
                }
            }
        }

    }
}
