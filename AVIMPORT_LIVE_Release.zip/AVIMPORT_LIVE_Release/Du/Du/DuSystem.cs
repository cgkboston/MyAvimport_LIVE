#region HEADER
//   PROJECT: Du
//  FILENAME: DuSystem.cs
//     BUILD: 171228
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2017 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/Du
#endregion

#region CLASS_DESCRIPTION
// Does things with system functions.
#endregion

// v0.10.0-alpha

using System.Diagnostics;
using System.Threading;

namespace Du
{
    public class DuSystem
    {
        /// <summary>
        /// Executes a Windows CLI command.
        /// </summary>
        /// <param name="command">   The command to execute (i.e. "ping").</param>
        /// <param name="arguments"> Optional command arguments (i.e. "-n4 192.168.1.1").</param>
        /// <returns>The results of the command.</returns>
        public static string ExecuteCommand(string command, string arguments)
        {
            /*  Executes a CLI command.
             */
            var commandProcess = new Process();

            var processInfo = new ProcessStartInfo
            {
                WindowStyle            = ProcessWindowStyle.Hidden,
                RedirectStandardOutput = true,
                UseShellExecute        = false,
                CreateNoWindow         = false,
                FileName               = command,
                Arguments              = arguments
            };

            commandProcess.StartInfo = processInfo;
            commandProcess.Start();

            return commandProcess.StandardOutput.ReadToEnd();
        }

        /// <summary>
        /// Inserts a pause.
        /// </summary>
        /// <param name="milliseconds"> Number of milliseconds to pause.</param>
        public static void Pause(int milliseconds)
        {
            /*  Inserts a pause of X milliseconds.
             */
            Thread.Sleep(milliseconds);
        }
    }
}
