#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: DuMessageBox.cs
//   VERSION: x.y.z[-stage]
//     BUILD: 170203
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2017 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region USING
using System.Windows.Forms;
#endregion

namespace Du
{
    public class DuMessageBox
    {
        /*  Displays a standard MessageBox control with an "OK" button.
         */
        public static void Display(string msgHeader, string msgBody)
        {
            MessageBox.Show(msgHeader, msgBody);
        }
    }
}
