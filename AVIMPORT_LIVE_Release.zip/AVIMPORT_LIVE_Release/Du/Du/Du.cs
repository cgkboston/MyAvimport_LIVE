#region PROJECT_HEADER
//   PROJECT: Du
//  FILENAME: Du.cs
//     BUILD: 171228
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2017 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/DropHub
#endregion

#region PROJECT_DESCRIPTION
// Du: a C# class library.
//
// Requirements:
//  * None.
#endregion

#region PROJECT_ACKNOWLEDGEMENTS
// All icons are from icons8.com [https://www.icons8.com]
#endregion

// v0.10.0-alpha+b171228

namespace Du
{
    public class Du
    {
        /*  This file is just a placeholder.
         */
    }
}
