#region HEADER
//   PROJECT: Du
//  FILENAME: DuString.cs
//     BUILD: 171228
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2017 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/Du
#endregion

#region CLASS_DESCRIPTION
// Does things with strings.
#endregion

// v0.10.0-alpha

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Du
{
    public class DuString
    {
        /// <summary>
        /// Checks to see if a string is blank.
        /// </summary>
        /// <param name="toCheck"> The string to check.</param>
        /// <returns>If the string is blank [true/false].</returns>
        public static bool IsBlank(string toCheck)
        {
            /*  Check if a string is empty, a single space, or null/empty
             */
            return toCheck == "" || toCheck == " " || string.IsNullOrEmpty(toCheck);
        }

        /// <summary>
        /// Checks to see if a string starts with a specific character.
        /// </summary>
        /// <param name="toCheck">   The string to check.</param>
        /// <param name="character"> The character that starts a comment string.</param>
        /// <returns></returns>
        public static bool StartsWith(string toCheck, char character)
        {
            /*  Check if a string starts with a specific character.
             */
            return toCheck.StartsWith(character.ToString());
        }

        /// <summary>
        /// Converts a string to an array.
        /// </summary>
        /// <param name="toConvert">The string to convert.</param>
        /// <param name="delimiter">The delimiter to use (i.e. '=', or "null" for newlines).</param>
        /// <returns>The string as an array.</returns>
        public static string[] ToArray(string toConvert, char? delimiter)
        {
            /*  Info here!
             */
            return delimiter != null
                ? toConvert.Split(delimiter.Value)
                : toConvert.Split(new[] {Environment.NewLine}, StringSplitOptions.None);
        }

        /// <summary>
        /// onverts a string to a file.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="stringToWrite"></param>
        // TODO Replace w/StringWriter or something?
        public static void ToFile(string fileName, string stringToWrite)
        {
            /*  Info here!
             */
            File.WriteAllText(fileName, stringToWrite);
        }


        /// <summary>Add content to the beginning of a string</summary>
        /// <param name="stringToAddTo">The string to add to.</param>
        /// <param name="contentToAdd">The content to add.</param>
        /// <returns>A new string with the content at the beginning.</returns>
        public static string Prepend(string contentToAdd, string stringToAddTo)
        {
            return contentToAdd + stringToAddTo;
        }


        /// <summary>
        /// Convert a string to a list.
        /// </summary>
        /// <param name="toConvert">The string to convert.</param>
        /// <param name="delimiter">The delimiter to use (i.e. '=', or "null" for newlines).</param>
        /// <returns>The string as a list.</returns>
        public static List<string> ToList(string toConvert, char? delimiter)
        {
            /*  Info here!
             */
            return delimiter != null
                ? toConvert.Split(delimiter.Value).ToList()
                : toConvert.Split(new[] { Environment.NewLine }, StringSplitOptions.None).ToList();
        }

        /// <summary>
        /// Removes specified content from the beginning of a string.
        /// </summary>
        /// <param name="toModify">The string to remove from.</param>
        /// <param name="content">The content to remove.</param>
        /// <returns>The string with the content removed from the beginning.</returns>
        public static string RemoveLeadingContent(string toModify, string content)
        {
            return toModify.Substring(content.Length);
        }

        /// <summary>
        /// Removes leading and trailing whitespace from a string.
        /// </summary>
        /// <param name="toModify">The string to modify.</param>
        /// <returns>The string without leading or trailin whitespace.</returns>
        public static string RemoveBookendWhitespace(string toModify)
        {
            /*  Remove leading and trailing whitespace from a string.
             */
            return toModify.Trim();
        }

        /// <summary>
        /// Removes leading whitespace from a string.
        /// </summary>
        /// <param name="toModify"> The string to modify.</param>
        /// <returns>The string without leading whitespace.</returns>
        public static string RemoveLeadingWhitespace(string toModify)
        {
            /*  Remove leading whitespace from a string.
             */
            return toModify.TrimStart();
        }

        /// <summary>
        /// Removes trailing whitespace from a string.
        /// </summary>
        /// <param name="stringToModify">The string to modify.</param>
        /// <returns>The string without trailing whitespace.</returns>
        public static string RemoveTrailingWhitespace(string stringToModify)
        {
            return stringToModify.TrimEnd();
        }
    }
}
