#region PROJECT_HEADER
//   PROJECT: myAvatool
//  FILENAME: DuInputBox.cs
//     BUILD: 171017
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2017 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvatool
#endregion

#region CLASS_DESCRIPTION
// Displays a popup that requests user input.
#endregion

// v0.10.0-alpha

using System;
using System.Windows.Forms;

namespace Du
{
    /// <summary>Entry point.</summary>
    public partial class frmDuInputBox : Form
    {
        public frmDuInputBox()
        {
            InitializeComponent();
        }

        /// <summary>Initialize the popup with the provided messages.</summary>
        /// <param name="whatever"></param>
        public frmDuInputBox(string whatever)
        {
            InitializeComponent();
            lblMessage.Text = whatever;
        }

        /// <summary>User clicks the OK button.</summary>
        private void btnOK_Click(object sender, EventArgs e)
        {
            Tag = tbxUserResponse.Text;
            Hide();
        }

        /// <summary>User clicks the Cancel button.</summary>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Hide();
        }

        /// <summary>The text in the tbxUserInput control is changed.</summary>
        private void tbxUserResponse_TextChanged(object sender, EventArgs e)
        {
            /*  Whenever the user modifies the contents of the response control, check to see if the control is empty.
             *  If the control is empty, disable the "OK" button.
             */
            btnOK.Enabled = tbxUserResponse.Text != string.Empty;
        }
    }
}
