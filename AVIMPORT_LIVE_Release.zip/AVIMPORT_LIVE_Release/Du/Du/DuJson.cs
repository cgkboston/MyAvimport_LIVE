#region PROJECT_HEADER
//   PROJECT: Du
//  FILENAME: DuJson.cs
//     BUILD: 171228
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2017 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/Du
#endregion

#region CLASS_DESCRIPTION
// Does things with JSON-formatted data.
#endregion

// v0.10.0-alpha


namespace Du
{
    public class DuJson
    {
    }
}
