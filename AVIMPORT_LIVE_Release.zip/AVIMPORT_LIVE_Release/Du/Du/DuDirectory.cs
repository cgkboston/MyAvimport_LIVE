#region PROJECT_HEADER
//   PROJECT: Sobchak
//  FILENAME: DuDirectory.cs
//     BUILD: 171228
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2017 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/Sobchak
#endregion

#region CLASS_DESCRIPTION
// Does things with directories.
#endregion

// v0.10.0-alpha

using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Du
{
    public class DuDirectory
    {

        /// <summary>
        ///
        /// </summary>
        /// <param name="parent"></param>
        /// <returns></returns>
        public static List<string> GetSubdirectoryNames(string parent)
        {
            var subdirectoryNames = new List<string>();

            foreach (var subdirectory in Directory.GetDirectories(parent))
            {
                var pathInfo = new DirectoryInfo(subdirectory);
                subdirectoryNames.Add(pathInfo.Name);
            }

            return subdirectoryNames;
        }


        /// <summary>
        ///
        /// </summary>
        /// <param name="parent"></param>
        /// <returns></returns>
        public static List<string> GetSubdirectoryPaths(string parent)
        {
            return Directory.GetDirectories(parent).ToList();
        }
    }
}
