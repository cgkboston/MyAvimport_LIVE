namespace myAvimport
{
    partial class MyAvimport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlDataImport = new System.Windows.Forms.Panel();
            this.pnlHeaderMyAvimport = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblDataImportHeader = new System.Windows.Forms.Label();
            this.pnlLogin = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnLogin = new System.Windows.Forms.Button();
            this.TbxPassword = new System.Windows.Forms.TextBox();
            this.TbxUsername = new System.Windows.Forms.TextBox();
            this.pnlLoggedIn = new System.Windows.Forms.Panel();
            this.lblLoggedInStatus = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TbxPreview = new System.Windows.Forms.TextBox();
            this.CbxThrottleImport = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.CbxTestMode = new System.Windows.Forms.CheckBox();
            this.btnCancelImport = new System.Windows.Forms.Button();
            this.lblIndicatorResolve = new System.Windows.Forms.Label();
            this.lblResolve = new System.Windows.Forms.Label();
            this.lblIndicatorErrors = new System.Windows.Forms.Label();
            this.lblIndicatorPreview = new System.Windows.Forms.Label();
            this.lblImport = new System.Windows.Forms.Label();
            this.lblIndicatorImport = new System.Windows.Forms.Label();
            this.lblIndicatorLoadData = new System.Windows.Forms.Label();
            this.lblIndicatorCredentials = new System.Windows.Forms.Label();
            this.lblIndicatorChooseEnvironment = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.RdoSBOX = new System.Windows.Forms.RadioButton();
            this.RdoUAT = new System.Windows.Forms.RadioButton();
            this.RdoLIVE = new System.Windows.Forms.RadioButton();
            this.lblChooseEnvironment = new System.Windows.Forms.Label();
            this.lblLoadData = new System.Windows.Forms.Label();
            this.lblCredentials = new System.Windows.Forms.Label();
            this.btnImport = new System.Windows.Forms.Button();
            this.BtnLoadClientDemographicsData = new System.Windows.Forms.Button();
            this.BtnLoadCrossEpisodeFinancialEligibilityData = new System.Windows.Forms.Button();
            this.lblDescriptionDataPreview = new System.Windows.Forms.Label();
            this.lblPreview = new System.Windows.Forms.Label();
            this.BtnPreviousRecord = new System.Windows.Forms.Button();
            this.lblClientRecordDisplay = new System.Windows.Forms.Label();
            this.BtnNextRecord = new System.Windows.Forms.Button();
            this.lblErrors = new System.Windows.Forms.Label();
            this.TbxErrors = new System.Windows.Forms.TextBox();
            this.BtnAcceptErrors = new System.Windows.Forms.Button();
            this.ofdFileToConvert = new System.Windows.Forms.OpenFileDialog();
            this.pnlDataImport.SuspendLayout();
            this.pnlHeaderMyAvimport.SuspendLayout();
            this.pnlLogin.SuspendLayout();
            this.pnlLoggedIn.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlDataImport
            // 
            this.pnlDataImport.BackColor = System.Drawing.Color.White;
            this.pnlDataImport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDataImport.Controls.Add(this.pnlHeaderMyAvimport);
            this.pnlDataImport.Controls.Add(this.pnlLogin);
            this.pnlDataImport.Controls.Add(this.pnlLoggedIn);
            this.pnlDataImport.Controls.Add(this.panel1);
            this.pnlDataImport.Controls.Add(this.CbxThrottleImport);
            this.pnlDataImport.Controls.Add(this.label15);
            this.pnlDataImport.Controls.Add(this.CbxTestMode);
            this.pnlDataImport.Controls.Add(this.btnCancelImport);
            this.pnlDataImport.Controls.Add(this.lblIndicatorResolve);
            this.pnlDataImport.Controls.Add(this.lblResolve);
            this.pnlDataImport.Controls.Add(this.lblIndicatorErrors);
            this.pnlDataImport.Controls.Add(this.lblIndicatorPreview);
            this.pnlDataImport.Controls.Add(this.lblImport);
            this.pnlDataImport.Controls.Add(this.lblIndicatorImport);
            this.pnlDataImport.Controls.Add(this.lblIndicatorLoadData);
            this.pnlDataImport.Controls.Add(this.lblIndicatorCredentials);
            this.pnlDataImport.Controls.Add(this.lblIndicatorChooseEnvironment);
            this.pnlDataImport.Controls.Add(this.panel2);
            this.pnlDataImport.Controls.Add(this.lblChooseEnvironment);
            this.pnlDataImport.Controls.Add(this.lblLoadData);
            this.pnlDataImport.Controls.Add(this.lblCredentials);
            this.pnlDataImport.Controls.Add(this.btnImport);
            this.pnlDataImport.Controls.Add(this.BtnLoadClientDemographicsData);
            this.pnlDataImport.Controls.Add(this.BtnLoadCrossEpisodeFinancialEligibilityData);
            this.pnlDataImport.Controls.Add(this.lblDescriptionDataPreview);
            this.pnlDataImport.Controls.Add(this.lblPreview);
            this.pnlDataImport.Controls.Add(this.BtnPreviousRecord);
            this.pnlDataImport.Controls.Add(this.lblClientRecordDisplay);
            this.pnlDataImport.Controls.Add(this.BtnNextRecord);
            this.pnlDataImport.Controls.Add(this.lblErrors);
            this.pnlDataImport.Controls.Add(this.TbxErrors);
            this.pnlDataImport.Controls.Add(this.BtnAcceptErrors);
            this.pnlDataImport.ForeColor = System.Drawing.Color.Black;
            this.pnlDataImport.Location = new System.Drawing.Point(8, 8);
            this.pnlDataImport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlDataImport.Name = "pnlDataImport";
            this.pnlDataImport.Size = new System.Drawing.Size(6010, 3002);
            this.pnlDataImport.TabIndex = 40;
            this.pnlDataImport.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlDataImport_Paint);
            // 
            // pnlHeaderMyAvimport
            // 
            this.pnlHeaderMyAvimport.BackColor = System.Drawing.Color.LightCoral;
            this.pnlHeaderMyAvimport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlHeaderMyAvimport.Controls.Add(this.label2);
            this.pnlHeaderMyAvimport.Controls.Add(this.label4);
            this.pnlHeaderMyAvimport.Controls.Add(this.lblDataImportHeader);
            this.pnlHeaderMyAvimport.Location = new System.Drawing.Point(30, 31);
            this.pnlHeaderMyAvimport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlHeaderMyAvimport.Name = "pnlHeaderMyAvimport";
            this.pnlHeaderMyAvimport.Size = new System.Drawing.Size(412, 231);
            this.pnlHeaderMyAvimport.TabIndex = 78;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.LightCoral;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkRed;
            this.label2.Location = new System.Drawing.Point(17, 95);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(375, 114);
            this.label2.TabIndex = 80;
            this.label2.Text = "LIVE";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.LightCoral;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Firebrick;
            this.label4.Location = new System.Drawing.Point(37, 15);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 26);
            this.label4.TabIndex = 79;
            this.label4.Text = "myAVATOOL";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDataImportHeader
            // 
            this.lblDataImportHeader.BackColor = System.Drawing.Color.LightCoral;
            this.lblDataImportHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataImportHeader.ForeColor = System.Drawing.Color.Firebrick;
            this.lblDataImportHeader.Location = new System.Drawing.Point(17, 39);
            this.lblDataImportHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDataImportHeader.Name = "lblDataImportHeader";
            this.lblDataImportHeader.Size = new System.Drawing.Size(375, 58);
            this.lblDataImportHeader.TabIndex = 44;
            this.lblDataImportHeader.Text = "myAvimport";
            this.lblDataImportHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDataImportHeader.Click += new System.EventHandler(this.lblDataImportHeader_Click);
            // 
            // pnlLogin
            // 
            this.pnlLogin.Controls.Add(this.label1);
            this.pnlLogin.Controls.Add(this.label3);
            this.pnlLogin.Controls.Add(this.BtnLogin);
            this.pnlLogin.Controls.Add(this.TbxPassword);
            this.pnlLogin.Controls.Add(this.TbxUsername);
            this.pnlLogin.Location = new System.Drawing.Point(30, 334);
            this.pnlLogin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlLogin.Name = "pnlLogin";
            this.pnlLogin.Size = new System.Drawing.Size(413, 138);
            this.pnlLogin.TabIndex = 100;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 25);
            this.label1.TabIndex = 67;
            this.label1.Text = "Username";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(46, 69);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 25);
            this.label3.TabIndex = 68;
            this.label3.Text = "Password";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BtnLogin
            // 
            this.BtnLogin.BackColor = System.Drawing.Color.Transparent;
            this.BtnLogin.BackgroundImage = global::myAvimport.Properties.Resources.icons8_login_32_grey;
            this.BtnLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnLogin.Enabled = false;
            this.BtnLogin.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BtnLogin.FlatAppearance.BorderSize = 0;
            this.BtnLogin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BtnLogin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BtnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLogin.ForeColor = System.Drawing.Color.Transparent;
            this.BtnLogin.Location = new System.Drawing.Point(334, 98);
            this.BtnLogin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnLogin.Name = "BtnLogin";
            this.BtnLogin.Size = new System.Drawing.Size(33, 34);
            this.BtnLogin.TabIndex = 71;
            this.BtnLogin.TabStop = false;
            this.BtnLogin.UseVisualStyleBackColor = false;
            this.BtnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // TbxPassword
            // 
            this.TbxPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbxPassword.Enabled = false;
            this.TbxPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxPassword.Location = new System.Drawing.Point(50, 98);
            this.TbxPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TbxPassword.Name = "TbxPassword";
            this.TbxPassword.Size = new System.Drawing.Size(275, 30);
            this.TbxPassword.TabIndex = 65;
            this.TbxPassword.UseSystemPasswordChar = true;
            this.TbxPassword.TextChanged += new System.EventHandler(this.TbxPassword_TextChanged);
            // 
            // TbxUsername
            // 
            this.TbxUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbxUsername.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TbxUsername.Enabled = false;
            this.TbxUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxUsername.ForeColor = System.Drawing.Color.Black;
            this.TbxUsername.Location = new System.Drawing.Point(50, 32);
            this.TbxUsername.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TbxUsername.Name = "TbxUsername";
            this.TbxUsername.Size = new System.Drawing.Size(275, 30);
            this.TbxUsername.TabIndex = 64;
            this.TbxUsername.TextChanged += new System.EventHandler(this.TbxUsername_TextChanged);
            // 
            // pnlLoggedIn
            // 
            this.pnlLoggedIn.Controls.Add(this.lblLoggedInStatus);
            this.pnlLoggedIn.Location = new System.Drawing.Point(30, 334);
            this.pnlLoggedIn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlLoggedIn.Name = "pnlLoggedIn";
            this.pnlLoggedIn.Size = new System.Drawing.Size(413, 138);
            this.pnlLoggedIn.TabIndex = 101;
            // 
            // lblLoggedInStatus
            // 
            this.lblLoggedInStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoggedInStatus.Location = new System.Drawing.Point(4, 52);
            this.lblLoggedInStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLoggedInStatus.Name = "lblLoggedInStatus";
            this.lblLoggedInStatus.Size = new System.Drawing.Size(404, 35);
            this.lblLoggedInStatus.TabIndex = 0;
            this.lblLoggedInStatus.Text = "You are logged into LIVE as USERNAME";
            this.lblLoggedInStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.TbxPreview);
            this.panel1.Location = new System.Drawing.Point(858, 82);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(425, 884);
            this.panel1.TabIndex = 99;
            // 
            // TbxPreview
            // 
            this.TbxPreview.BackColor = System.Drawing.Color.White;
            this.TbxPreview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TbxPreview.Enabled = false;
            this.TbxPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxPreview.ForeColor = System.Drawing.Color.Black;
            this.TbxPreview.Location = new System.Drawing.Point(9, 1);
            this.TbxPreview.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TbxPreview.Multiline = true;
            this.TbxPreview.Name = "TbxPreview";
            this.TbxPreview.Size = new System.Drawing.Size(447, 880);
            this.TbxPreview.TabIndex = 20;
            // 
            // CbxThrottleImport
            // 
            this.CbxThrottleImport.AutoSize = true;
            this.CbxThrottleImport.Checked = true;
            this.CbxThrottleImport.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CbxThrottleImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbxThrottleImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CbxThrottleImport.Location = new System.Drawing.Point(35, 758);
            this.CbxThrottleImport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CbxThrottleImport.Name = "CbxThrottleImport";
            this.CbxThrottleImport.Size = new System.Drawing.Size(157, 29);
            this.CbxThrottleImport.TabIndex = 98;
            this.CbxThrottleImport.Text = "Throttle import";
            this.CbxThrottleImport.UseVisualStyleBackColor = true;
            this.CbxThrottleImport.CheckedChanged += new System.EventHandler(this.CbxThrottleImport_CheckedChanged);
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.SteelBlue;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(26, 677);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(412, 37);
            this.label15.TabIndex = 97;
            this.label15.Text = "Other settings";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CbxTestMode
            // 
            this.CbxTestMode.AutoSize = true;
            this.CbxTestMode.Checked = true;
            this.CbxTestMode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CbxTestMode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CbxTestMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CbxTestMode.Location = new System.Drawing.Point(35, 721);
            this.CbxTestMode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CbxTestMode.Name = "CbxTestMode";
            this.CbxTestMode.Size = new System.Drawing.Size(127, 29);
            this.CbxTestMode.TabIndex = 96;
            this.CbxTestMode.Text = "Test Mode";
            this.CbxTestMode.UseVisualStyleBackColor = true;
            this.CbxTestMode.CheckedChanged += new System.EventHandler(this.CbxTestMode_CheckedChanged);
            // 
            // btnCancelImport
            // 
            this.btnCancelImport.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnCancelImport.Enabled = false;
            this.btnCancelImport.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnCancelImport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnCancelImport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnCancelImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelImport.ForeColor = System.Drawing.Color.Black;
            this.btnCancelImport.Location = new System.Drawing.Point(1365, 595);
            this.btnCancelImport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCancelImport.Name = "btnCancelImport";
            this.btnCancelImport.Size = new System.Drawing.Size(361, 54);
            this.btnCancelImport.TabIndex = 95;
            this.btnCancelImport.TabStop = false;
            this.btnCancelImport.Text = "Cancel data import";
            this.btnCancelImport.UseVisualStyleBackColor = false;
            this.btnCancelImport.Click += new System.EventHandler(this.BtnCancelImport_Click);
            // 
            // lblIndicatorResolve
            // 
            this.lblIndicatorResolve.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorResolve.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorResolve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorResolve.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorResolve.Location = new System.Drawing.Point(1305, 592);
            this.lblIndicatorResolve.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndicatorResolve.Name = "lblIndicatorResolve";
            this.lblIndicatorResolve.Size = new System.Drawing.Size(52, 53);
            this.lblIndicatorResolve.TabIndex = 93;
            this.lblIndicatorResolve.Text = "6";
            this.lblIndicatorResolve.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblResolve
            // 
            this.lblResolve.BackColor = System.Drawing.Color.SteelBlue;
            this.lblResolve.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResolve.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResolve.ForeColor = System.Drawing.Color.White;
            this.lblResolve.Location = new System.Drawing.Point(1365, 475);
            this.lblResolve.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResolve.Name = "lblResolve";
            this.lblResolve.Size = new System.Drawing.Size(361, 53);
            this.lblResolve.TabIndex = 92;
            this.lblResolve.Text = "Resolve errors";
            this.lblResolve.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorErrors
            // 
            this.lblIndicatorErrors.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorErrors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorErrors.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorErrors.Location = new System.Drawing.Point(1314, 31);
            this.lblIndicatorErrors.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndicatorErrors.Name = "lblIndicatorErrors";
            this.lblIndicatorErrors.Size = new System.Drawing.Size(52, 53);
            this.lblIndicatorErrors.TabIndex = 89;
            this.lblIndicatorErrors.Text = "5";
            this.lblIndicatorErrors.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorPreview
            // 
            this.lblIndicatorPreview.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorPreview.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorPreview.Location = new System.Drawing.Point(474, 31);
            this.lblIndicatorPreview.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndicatorPreview.Name = "lblIndicatorPreview";
            this.lblIndicatorPreview.Size = new System.Drawing.Size(52, 53);
            this.lblIndicatorPreview.TabIndex = 88;
            this.lblIndicatorPreview.Text = "4";
            this.lblIndicatorPreview.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblImport
            // 
            this.lblImport.BackColor = System.Drawing.Color.SteelBlue;
            this.lblImport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImport.ForeColor = System.Drawing.Color.White;
            this.lblImport.Location = new System.Drawing.Point(1365, 661);
            this.lblImport.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblImport.Name = "lblImport";
            this.lblImport.Size = new System.Drawing.Size(361, 53);
            this.lblImport.TabIndex = 85;
            this.lblImport.Text = "Import data into myAvatar";
            this.lblImport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorImport
            // 
            this.lblIndicatorImport.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorImport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorImport.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorImport.Location = new System.Drawing.Point(1305, 722);
            this.lblIndicatorImport.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndicatorImport.Name = "lblIndicatorImport";
            this.lblIndicatorImport.Size = new System.Drawing.Size(52, 53);
            this.lblIndicatorImport.TabIndex = 84;
            this.lblIndicatorImport.Text = "7";
            this.lblIndicatorImport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorLoadData
            // 
            this.lblIndicatorLoadData.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorLoadData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorLoadData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorLoadData.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorLoadData.Location = new System.Drawing.Point(30, 475);
            this.lblIndicatorLoadData.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndicatorLoadData.Name = "lblIndicatorLoadData";
            this.lblIndicatorLoadData.Size = new System.Drawing.Size(52, 53);
            this.lblIndicatorLoadData.TabIndex = 83;
            this.lblIndicatorLoadData.Text = "3";
            this.lblIndicatorLoadData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorCredentials
            // 
            this.lblIndicatorCredentials.BackColor = System.Drawing.Color.LightSteelBlue;
            this.lblIndicatorCredentials.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorCredentials.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorCredentials.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorCredentials.Location = new System.Drawing.Point(30, 275);
            this.lblIndicatorCredentials.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndicatorCredentials.Name = "lblIndicatorCredentials";
            this.lblIndicatorCredentials.Size = new System.Drawing.Size(52, 53);
            this.lblIndicatorCredentials.TabIndex = 82;
            this.lblIndicatorCredentials.Text = "2";
            this.lblIndicatorCredentials.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndicatorChooseEnvironment
            // 
            this.lblIndicatorChooseEnvironment.BackColor = System.Drawing.Color.LightGreen;
            this.lblIndicatorChooseEnvironment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIndicatorChooseEnvironment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndicatorChooseEnvironment.ForeColor = System.Drawing.Color.Black;
            this.lblIndicatorChooseEnvironment.Location = new System.Drawing.Point(30, 151);
            this.lblIndicatorChooseEnvironment.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndicatorChooseEnvironment.Name = "lblIndicatorChooseEnvironment";
            this.lblIndicatorChooseEnvironment.Size = new System.Drawing.Size(52, 53);
            this.lblIndicatorChooseEnvironment.TabIndex = 81;
            this.lblIndicatorChooseEnvironment.Text = "1";
            this.lblIndicatorChooseEnvironment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.RdoSBOX);
            this.panel2.Controls.Add(this.RdoUAT);
            this.panel2.Controls.Add(this.RdoLIVE);
            this.panel2.Location = new System.Drawing.Point(81, 212);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(361, 51);
            this.panel2.TabIndex = 80;
            // 
            // RdoSBOX
            // 
            this.RdoSBOX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RdoSBOX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RdoSBOX.Location = new System.Drawing.Point(18, 6);
            this.RdoSBOX.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RdoSBOX.Name = "RdoSBOX";
            this.RdoSBOX.Size = new System.Drawing.Size(98, 39);
            this.RdoSBOX.TabIndex = 0;
            this.RdoSBOX.Text = "SBOX";
            this.RdoSBOX.UseVisualStyleBackColor = true;
            this.RdoSBOX.CheckedChanged += new System.EventHandler(this.RdoSBOX_CheckedChanged);
            // 
            // RdoUAT
            // 
            this.RdoUAT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RdoUAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RdoUAT.Location = new System.Drawing.Point(231, 6);
            this.RdoUAT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RdoUAT.Name = "RdoUAT";
            this.RdoUAT.Size = new System.Drawing.Size(98, 39);
            this.RdoUAT.TabIndex = 1;
            this.RdoUAT.Text = "UAT";
            this.RdoUAT.UseVisualStyleBackColor = true;
            this.RdoUAT.CheckedChanged += new System.EventHandler(this.RdoUAT_CheckedChanged);
            // 
            // RdoLIVE
            // 
            this.RdoLIVE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RdoLIVE.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RdoLIVE.Location = new System.Drawing.Point(125, 6);
            this.RdoLIVE.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RdoLIVE.Name = "RdoLIVE";
            this.RdoLIVE.Size = new System.Drawing.Size(98, 39);
            this.RdoLIVE.TabIndex = 2;
            this.RdoLIVE.Text = "LIVE";
            this.RdoLIVE.CheckedChanged += new System.EventHandler(this.RdoLIVE_CheckedChanged);
            // 
            // lblChooseEnvironment
            // 
            this.lblChooseEnvironment.BackColor = System.Drawing.Color.SteelBlue;
            this.lblChooseEnvironment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblChooseEnvironment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChooseEnvironment.ForeColor = System.Drawing.Color.White;
            this.lblChooseEnvironment.Location = new System.Drawing.Point(81, 151);
            this.lblChooseEnvironment.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblChooseEnvironment.Name = "lblChooseEnvironment";
            this.lblChooseEnvironment.Size = new System.Drawing.Size(361, 53);
            this.lblChooseEnvironment.TabIndex = 72;
            this.lblChooseEnvironment.Text = "Choose an Avatar environment";
            this.lblChooseEnvironment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLoadData
            // 
            this.lblLoadData.BackColor = System.Drawing.Color.SteelBlue;
            this.lblLoadData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLoadData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoadData.ForeColor = System.Drawing.Color.White;
            this.lblLoadData.Location = new System.Drawing.Point(81, 475);
            this.lblLoadData.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLoadData.Name = "lblLoadData";
            this.lblLoadData.Size = new System.Drawing.Size(361, 53);
            this.lblLoadData.TabIndex = 70;
            this.lblLoadData.Text = "Load data to import";
            this.lblLoadData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCredentials
            // 
            this.lblCredentials.BackColor = System.Drawing.Color.SteelBlue;
            this.lblCredentials.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCredentials.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCredentials.ForeColor = System.Drawing.Color.White;
            this.lblCredentials.Location = new System.Drawing.Point(81, 275);
            this.lblCredentials.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCredentials.Name = "lblCredentials";
            this.lblCredentials.Size = new System.Drawing.Size(361, 53);
            this.lblCredentials.TabIndex = 63;
            this.lblCredentials.Text = "Enter your myAvatar credentials";
            this.lblCredentials.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnImport
            // 
            this.btnImport.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnImport.Enabled = false;
            this.btnImport.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnImport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnImport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImport.ForeColor = System.Drawing.Color.Black;
            this.btnImport.Location = new System.Drawing.Point(1365, 722);
            this.btnImport.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(361, 54);
            this.btnImport.TabIndex = 62;
            this.btnImport.TabStop = false;
            this.btnImport.Text = "Import data";
            this.btnImport.UseVisualStyleBackColor = false;
            this.btnImport.Click += new System.EventHandler(this.BtnImport_Click);
            // 
            // BtnLoadClientDemographicsData
            // 
            this.BtnLoadClientDemographicsData.BackColor = System.Drawing.Color.LightSteelBlue;
            this.BtnLoadClientDemographicsData.Enabled = false;
            this.BtnLoadClientDemographicsData.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BtnLoadClientDemographicsData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.BtnLoadClientDemographicsData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.BtnLoadClientDemographicsData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnLoadClientDemographicsData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLoadClientDemographicsData.ForeColor = System.Drawing.Color.Black;
            this.BtnLoadClientDemographicsData.Location = new System.Drawing.Point(81, 538);
            this.BtnLoadClientDemographicsData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnLoadClientDemographicsData.Name = "BtnLoadClientDemographicsData";
            this.BtnLoadClientDemographicsData.Size = new System.Drawing.Size(361, 54);
            this.BtnLoadClientDemographicsData.TabIndex = 59;
            this.BtnLoadClientDemographicsData.TabStop = false;
            this.BtnLoadClientDemographicsData.Text = "Client Demographics";
            this.BtnLoadClientDemographicsData.UseVisualStyleBackColor = false;
            this.BtnLoadClientDemographicsData.Click += new System.EventHandler(this.BtnLoadClientDemographicsData_Click);
            // 
            // BtnLoadCrossEpisodeFinancialEligibilityData
            // 
            this.BtnLoadCrossEpisodeFinancialEligibilityData.BackColor = System.Drawing.Color.LightSteelBlue;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.Enabled = false;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLoadCrossEpisodeFinancialEligibilityData.ForeColor = System.Drawing.Color.Black;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.Location = new System.Drawing.Point(81, 595);
            this.BtnLoadCrossEpisodeFinancialEligibilityData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnLoadCrossEpisodeFinancialEligibilityData.Name = "BtnLoadCrossEpisodeFinancialEligibilityData";
            this.BtnLoadCrossEpisodeFinancialEligibilityData.Size = new System.Drawing.Size(361, 54);
            this.BtnLoadCrossEpisodeFinancialEligibilityData.TabIndex = 42;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.TabStop = false;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.Text = "Cross Episode Financial Eligibility";
            this.BtnLoadCrossEpisodeFinancialEligibilityData.UseVisualStyleBackColor = false;
            this.BtnLoadCrossEpisodeFinancialEligibilityData.Click += new System.EventHandler(this.BtnLoadCrossEpisodeFinancialEligibilityData_Click);
            // 
            // lblDescriptionDataPreview
            // 
            this.lblDescriptionDataPreview.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblDescriptionDataPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDescriptionDataPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescriptionDataPreview.ForeColor = System.Drawing.Color.Black;
            this.lblDescriptionDataPreview.Location = new System.Drawing.Point(474, 82);
            this.lblDescriptionDataPreview.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescriptionDataPreview.Name = "lblDescriptionDataPreview";
            this.lblDescriptionDataPreview.Size = new System.Drawing.Size(386, 884);
            this.lblDescriptionDataPreview.TabIndex = 45;
            this.lblDescriptionDataPreview.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblPreview
            // 
            this.lblPreview.BackColor = System.Drawing.Color.SteelBlue;
            this.lblPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreview.ForeColor = System.Drawing.Color.White;
            this.lblPreview.Location = new System.Drawing.Point(525, 31);
            this.lblPreview.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPreview.Name = "lblPreview";
            this.lblPreview.Size = new System.Drawing.Size(299, 53);
            this.lblPreview.TabIndex = 49;
            this.lblPreview.Text = "Preview data";
            this.lblPreview.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnPreviousRecord
            // 
            this.BtnPreviousRecord.BackColor = System.Drawing.Color.White;
            this.BtnPreviousRecord.BackgroundImage = global::myAvimport.Properties.Resources.icons8_back_32;
            this.BtnPreviousRecord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnPreviousRecord.FlatAppearance.BorderSize = 0;
            this.BtnPreviousRecord.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BtnPreviousRecord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BtnPreviousRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPreviousRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPreviousRecord.ForeColor = System.Drawing.Color.Black;
            this.BtnPreviousRecord.Location = new System.Drawing.Point(915, 38);
            this.BtnPreviousRecord.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnPreviousRecord.Name = "BtnPreviousRecord";
            this.BtnPreviousRecord.Size = new System.Drawing.Size(36, 38);
            this.BtnPreviousRecord.TabIndex = 21;
            this.BtnPreviousRecord.UseVisualStyleBackColor = false;
            this.BtnPreviousRecord.Click += new System.EventHandler(this.BtnPreviousRecord_Click);
            // 
            // lblClientRecordDisplay
            // 
            this.lblClientRecordDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientRecordDisplay.ForeColor = System.Drawing.Color.Black;
            this.lblClientRecordDisplay.Location = new System.Drawing.Point(955, 39);
            this.lblClientRecordDisplay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblClientRecordDisplay.Name = "lblClientRecordDisplay";
            this.lblClientRecordDisplay.Size = new System.Drawing.Size(198, 35);
            this.lblClientRecordDisplay.TabIndex = 43;
            this.lblClientRecordDisplay.Text = "Record 1 of ???";
            this.lblClientRecordDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnNextRecord
            // 
            this.BtnNextRecord.BackColor = System.Drawing.Color.White;
            this.BtnNextRecord.BackgroundImage = global::myAvimport.Properties.Resources.icons8_forward_32;
            this.BtnNextRecord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnNextRecord.FlatAppearance.BorderSize = 0;
            this.BtnNextRecord.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BtnNextRecord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BtnNextRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnNextRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnNextRecord.ForeColor = System.Drawing.Color.Black;
            this.BtnNextRecord.Location = new System.Drawing.Point(1158, 39);
            this.BtnNextRecord.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnNextRecord.Name = "BtnNextRecord";
            this.BtnNextRecord.Size = new System.Drawing.Size(36, 38);
            this.BtnNextRecord.TabIndex = 37;
            this.BtnNextRecord.UseVisualStyleBackColor = false;
            this.BtnNextRecord.Click += new System.EventHandler(this.BtnNextRecord_Click);
            // 
            // lblErrors
            // 
            this.lblErrors.BackColor = System.Drawing.Color.SteelBlue;
            this.lblErrors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrors.ForeColor = System.Drawing.Color.White;
            this.lblErrors.Location = new System.Drawing.Point(1365, 31);
            this.lblErrors.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblErrors.Name = "lblErrors";
            this.lblErrors.Size = new System.Drawing.Size(361, 53);
            this.lblErrors.TabIndex = 51;
            this.lblErrors.Text = "Review errors";
            this.lblErrors.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TbxErrors
            // 
            this.TbxErrors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbxErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbxErrors.Location = new System.Drawing.Point(1314, 84);
            this.TbxErrors.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TbxErrors.Multiline = true;
            this.TbxErrors.Name = "TbxErrors";
            this.TbxErrors.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TbxErrors.Size = new System.Drawing.Size(412, 378);
            this.TbxErrors.TabIndex = 46;
            // 
            // BtnAcceptErrors
            // 
            this.BtnAcceptErrors.BackColor = System.Drawing.Color.LightSteelBlue;
            this.BtnAcceptErrors.Enabled = false;
            this.BtnAcceptErrors.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BtnAcceptErrors.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.BtnAcceptErrors.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.BtnAcceptErrors.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAcceptErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAcceptErrors.ForeColor = System.Drawing.Color.Black;
            this.BtnAcceptErrors.Location = new System.Drawing.Point(1365, 536);
            this.BtnAcceptErrors.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnAcceptErrors.Name = "BtnAcceptErrors";
            this.BtnAcceptErrors.Size = new System.Drawing.Size(361, 54);
            this.BtnAcceptErrors.TabIndex = 47;
            this.BtnAcceptErrors.TabStop = false;
            this.BtnAcceptErrors.Text = "Accept errors";
            this.BtnAcceptErrors.UseVisualStyleBackColor = false;
            this.BtnAcceptErrors.Click += new System.EventHandler(this.BtnAcceptErrors_Click);
            // 
            // ofdFileToConvert
            // 
            this.ofdFileToConvert.FileName = "openFileDialog1";
            // 
            // MyAvimport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1776, 1019);
            this.Controls.Add(this.pnlDataImport);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MyAvimport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "myAvimport - LIVE";
            this.Load += new System.EventHandler(this.MyAvimport_Load);
            this.pnlDataImport.ResumeLayout(false);
            this.pnlDataImport.PerformLayout();
            this.pnlHeaderMyAvimport.ResumeLayout(false);
            this.pnlLogin.ResumeLayout(false);
            this.pnlLogin.PerformLayout();
            this.pnlLoggedIn.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlDataImport;
        private System.Windows.Forms.Label lblDataImportHeader;
        private System.Windows.Forms.Label lblDescriptionDataPreview;
        private System.Windows.Forms.Label lblPreview;
        private System.Windows.Forms.TextBox TbxPreview;
        private System.Windows.Forms.Button BtnPreviousRecord;
        private System.Windows.Forms.Label lblClientRecordDisplay;
        private System.Windows.Forms.Button BtnNextRecord;
        private System.Windows.Forms.Label lblErrors;
        private System.Windows.Forms.TextBox TbxErrors;
        private System.Windows.Forms.Button BtnAcceptErrors;
        private System.Windows.Forms.OpenFileDialog ofdFileToConvert;
        private System.Windows.Forms.Button btnImport;
        private System.Windows.Forms.Label lblLoadData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TbxPassword;
        private System.Windows.Forms.TextBox TbxUsername;
        private System.Windows.Forms.Label lblCredentials;
        private System.Windows.Forms.Button BtnLoadClientDemographicsData;
        private System.Windows.Forms.Button BtnLoadCrossEpisodeFinancialEligibilityData;
        private System.Windows.Forms.Button BtnLogin;
        private System.Windows.Forms.Label lblChooseEnvironment;
        private System.Windows.Forms.Panel pnlHeaderMyAvimport;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblImport;
        private System.Windows.Forms.Label lblIndicatorImport;
        private System.Windows.Forms.Label lblIndicatorLoadData;
        private System.Windows.Forms.Label lblIndicatorCredentials;
        private System.Windows.Forms.Label lblIndicatorChooseEnvironment;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton RdoSBOX;
        private System.Windows.Forms.RadioButton RdoUAT;
        private System.Windows.Forms.RadioButton RdoLIVE;
        private System.Windows.Forms.Button btnCancelImport;
        private System.Windows.Forms.Label lblIndicatorResolve;
        private System.Windows.Forms.Label lblResolve;
        private System.Windows.Forms.Label lblIndicatorErrors;
        private System.Windows.Forms.Label lblIndicatorPreview;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox CbxTestMode;
        private System.Windows.Forms.CheckBox CbxThrottleImport;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlLogin;
        private System.Windows.Forms.Panel pnlLoggedIn;
        private System.Windows.Forms.Label lblLoggedInStatus;
        private System.Windows.Forms.Label label2;
    }
}









