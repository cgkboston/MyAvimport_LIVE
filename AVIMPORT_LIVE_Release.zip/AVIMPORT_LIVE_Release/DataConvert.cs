#region PROJECT_HEADER
//   PROJECT: myAvimport
//  FILENAME: DataConvert.cs
//   VERSION: x.y.z[-stage]
//     BUILD: 170207
//   AUTHORS: development@aprettycoolprogram.com
// COPYRIGHT: 2020 A Pretty Cool Program
//   LICENSE: Apache License, Version 2.0 [http://www.apache.org/licenses/LICENSE-2.0]
// MORE INFO: http://aprettycoolprogram.com/myAvimport
#endregion

#region CLASS_DESCRIPTION
/* Data import logic.
 */
#endregion

#region USING
using Du;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
#endregion

namespace myAvimport
{
    public class DataConvert
    {
        private static void UpdateStatusBox(frmDuStatusBox statusBox, Color border, Color bkgrd, string header, string status, bool buttonEnabled, string buttonText)
        {
            statusBox.SetBorder(border);
            statusBox.SetBackground(bkgrd);
            statusBox.SetHeader(header);
            statusBox.SetStatus(status);
            statusBox.ButtonEnabled(buttonEnabled);
            statusBox.ButtonText(buttonText);
            statusBox.Refresh();
        }

        /// <summary> Convert file contents. </summary>
        /// <param name = "dataToConvert"> The data to convert </param>
        /// <returns> The contents of a file in a format that can be imported into myAvatar. </returns>
        public static List<string>[] FromFile(string dataToConvert)
        {
            var statusBox = new frmDuStatusBox();
            statusBox.Show();
            UpdateStatusBox(statusBox, Color.Black, Color.LightGray, "Conversion in progress...working...", "Checking file...", false, "Done");

            var        convertedRecords = new List<string>[0];
            var        totalRecords     = 0;
            var        currentRecord    = 0;
            var        fileline         = string.Empty;
            const char delimiter        = '~';

            using (var filelines = new StringReader(dataToConvert))
            {
                while ((fileline = filelines.ReadLine()) != null)
                {
                    if (!fileline.Contains(delimiter.ToString()))
                    {
                        UpdateStatusBox(statusBox, Color.Black, Color.LightCoral, "myAvimport error...", "This file does not seem to be a valid import file.", true, "Exit");

                        return convertedRecords;
                    }
                    else
                    {
                        /* Resize array to fit the data to convert */
                        if (convertedRecords.Length == 0)
                        {
                            totalRecords = dataToConvert.Split('\n').Length;
                            --totalRecords; // cgk 8/24/18.  To account for the blank line at the end of file.
                            Array.Resize(ref convertedRecords, totalRecords);
                        }

                        var wrkString = new StringBuilder();
                        var wrkList = new List<string>();
                        foreach (var character in fileline)
                        {
                            if (character != delimiter)
                            {
                                wrkString = wrkString.Append(character);
                            }
                            else
                            {
                                wrkList.Add(DuString.RemoveBookendWhitespace(wrkString.ToString()));
                                wrkString.Clear();
                            }
                        }
                        /* Get the last bit of information */
                        wrkList.Add(wrkString.ToString());
                        convertedRecords[currentRecord] = wrkList;

                        UpdateStatusBox(statusBox, Color.Black, Color.LightBlue, "Conversion in progress...working...", "Converted record " + (currentRecord + 1) + " of " + totalRecords, false, "Done");

                        /*  TODO Do we even need this, or will the EOF handle this? */

                        if (currentRecord < totalRecords)
                        {
                            currentRecord++;
                        }
                        else
                        {
                            break;
                        }
                    }
                }

                UpdateStatusBox(statusBox, Color.Black, Color.LightGreen, "Conversion complete!", "Click \"Continue\"", true, "Continue");

                return convertedRecords;
            }
        }
    }
}







